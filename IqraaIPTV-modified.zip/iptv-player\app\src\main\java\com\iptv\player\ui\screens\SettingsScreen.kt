package com.iptv.player.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.iptv.player.data.Graph
import com.iptv.player.ui.AppMode
import com.iptv.player.ui.theme.Bg
import com.iptv.player.ui.theme.BrandBright
import com.iptv.player.ui.theme.BrandPrimary
import com.iptv.player.ui.theme.Muted
import com.iptv.player.ui.theme.Surface2

@Composable
fun SettingsScreen(nav: NavHostController) {
    val s = Graph.session
    var mode by remember { mutableStateOf(s.displayMode) }
    var refresh by remember { mutableIntStateOf(s.refreshInterval) }
    var autoPlay by remember { mutableStateOf(s.autoPlayNext) }

    Column(Modifier.fillMaxSize().background(Bg)) {
        TopBar(nav, "Settings")
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)) {
            SectionTitle("Device mode")
            Row {
                OptChip("Auto", mode == "auto") {
                    mode = "auto"
                    s.setMode("auto")
                    AppMode.isTv = isTvAuto()
                }
                OptChip("Phone", mode == "phone") {
                    mode = "phone"
                    s.setMode("phone")
                    AppMode.isTv = false
                }
                OptChip("TV", mode == "tv") {
                    mode = "tv"
                    s.setMode("tv")
                    AppMode.isTv = true
                }
            }

            Spacer(Modifier.height(20.dp))
            SectionTitle("Auto refresh")
            Row {
                listOf(0, 15, 30, 60).forEach { minutes ->
                    OptChip(if (minutes == 0) "Off" else "${minutes}m", refresh == minutes) {
                        refresh = minutes
                        s.setRefreshInterval(minutes)
                    }
                    Spacer(Modifier.width(8.dp))
                }
            }

            Spacer(Modifier.height(20.dp))
            SectionTitle("Play next episode automatically")
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(
                    checked = autoPlay,
                    onCheckedChange = {
                        autoPlay = it
                        s.setAutoPlay(it)
                    },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = BrandBright,
                        checkedTrackColor = BrandPrimary
                    )
                )
                Spacer(Modifier.width(10.dp))
                Text(if (autoPlay) "On" else "Off", color = Color.White)
            }

            Spacer(Modifier.height(28.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF3A1530))
                    .clickable {
                        Graph.session.logout()
                        nav.navigate("login") { popUpTo(nav.graph.id) { inclusive = true } }
                    }
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("Logout", color = Color(0xFFFF8A8A))
            }
        }
    }
}

private fun isTvAuto(): Boolean = AppMode.isTv

@Composable
private fun SectionTitle(text: String) {
    Text(text, color = Muted, fontSize = 13.sp, modifier = Modifier.padding(bottom = 10.dp))
}

@Composable
private fun OptChip(text: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .padding(end = 10.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(if (selected) BrandPrimary else Surface2)
            .clickable { onClick() }
            .tvFocusBorder(RoundedCornerShape(20.dp))
            .padding(horizontal = 18.dp, vertical = 10.dp)
    ) {
        Text(text, color = Color.White)
    }
}
