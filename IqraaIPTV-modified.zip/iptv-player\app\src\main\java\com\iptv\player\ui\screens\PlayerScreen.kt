package com.iptv.player.ui.screens

import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import androidx.navigation.NavHostController
import com.iptv.player.data.Graph
import com.iptv.player.data.ResumeEntity
import com.iptv.player.ui.PlayInfo
import com.iptv.player.ui.Selection
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(nav: NavHostController) {
    val context = LocalContext.current
    val dao = Graph.db.dao()
    val scope = rememberCoroutineScope()
    val playlist = remember { Selection.playlist.ifEmpty { listOf(Selection.play) } }
    val indexState = remember { mutableIntStateOf(Selection.index.coerceIn(0, playlist.lastIndex)) }
    val index = indexState.intValue
    val info: PlayInfo = playlist[index]

    val resizeModes = remember {
        listOf(
            AspectRatioFrameLayout.RESIZE_MODE_FIT,
            AspectRatioFrameLayout.RESIZE_MODE_ZOOM,
            AspectRatioFrameLayout.RESIZE_MODE_FILL
        )
    }
    val resizeLabels = listOf("Fit", "Zoom", "Fill")
    var resizeIdx by remember { mutableIntStateOf(0) }
    var fallbackUrl by remember { mutableStateOf<String?>(null) }

    val player = remember { PlayerFactory.build(context) }

    LaunchedEffect(index) {
        val cur = playlist[index]
        fallbackUrl = if (cur.type == "live") liveFallbackUrl(cur.url) else null
        player.setMediaItem(MediaItem.fromUri(cur.url))
        player.prepare()
        player.playWhenReady = true
        if (cur.type != "live" && cur.itemId.isNotBlank()) {
            val pos = runCatching { dao.resumePos(cur.type, cur.itemId) }.getOrNull() ?: 0L
            if (pos > 3000) player.seekTo(pos)
        }
    }

    LaunchedEffect(index) {
        val cur = playlist[index]
        if (cur.type != "live") {
            while (true) {
                delay(10000)
                val position = player.currentPosition
                val duration = player.duration
                if (position > 0 && duration > 0) {
                    runCatching {
                        dao.saveResume(
                            ResumeEntity(
                                cur.type,
                                cur.itemId,
                                cur.title,
                                cur.logo,
                                position,
                                duration,
                                System.currentTimeMillis()
                            )
                        )
                    }
                }
            }
        }
    }

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                val fallback = fallbackUrl
                if (fallback != null) {
                    fallbackUrl = null
                    player.setMediaItem(MediaItem.fromUri(fallback))
                    player.prepare()
                    player.playWhenReady = true
                }
            }

            override fun onPlaybackStateChanged(state: Int) {
                val cur = playlist[indexState.intValue]
                if (
                    state == Player.STATE_ENDED &&
                    Graph.session.autoPlayNext &&
                    cur.type == "series" &&
                    indexState.intValue < playlist.lastIndex
                ) {
                    indexState.intValue = indexState.intValue + 1
                }
            }
        }
        player.addListener(listener)
        onDispose {
            player.removeListener(listener)
            player.release()
        }
    }

    BackHandler { nav.popBackStack() }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                PlayerView(ctx).apply {
                    this.player = player
                    useController = true
                    keepScreenOn = true
                    setShowSubtitleButton(true)
                    setShowNextButton(false)
                    setShowPreviousButton(false)
                    resizeMode = resizeModes[0]
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                }
            },
            update = { it.resizeMode = resizeModes[resizeIdx] }
        )

        Row(
            Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 22.dp)
                .clip(RoundedCornerShape(28.dp))
                .background(Color(0xAA1A0F30))
                .padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (playlist.size > 1) {
                CtrlIcon(Icons.Filled.SkipPrevious, "Previous") {
                    if (index > 0) indexState.intValue = index - 1
                }
            }
            CtrlIcon(Icons.Filled.AspectRatio, resizeLabels[resizeIdx]) {
                resizeIdx = (resizeIdx + 1) % resizeModes.size
            }
            if (info.type == "series") {
                CtrlIcon(Icons.Filled.VideoLibrary, "Episodes") { nav.popBackStack() }
            }
            CtrlIcon(Icons.Filled.Download, if (info.type == "live") "Record" else "Download") {
                val download = Graph.downloader.enqueue(info.url, info.title, info.type, info.logo)
                scope.launch { runCatching { dao.addDownload(download) } }
                Toast.makeText(
                    context,
                    if (info.type == "live") "Recording started" else "Download started",
                    Toast.LENGTH_SHORT
                ).show()
            }
            if (playlist.size > 1) {
                CtrlIcon(Icons.Filled.SkipNext, "Next") {
                    if (index < playlist.lastIndex) indexState.intValue = index + 1
                }
            }
        }
    }
}

@Composable
private fun CtrlIcon(icon: ImageVector, label: String, onClick: () -> Unit) {
    Column(
        Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .tvFocusBorder(RoundedCornerShape(12.dp))
            .padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, label, tint = Color.White, modifier = Modifier.size(26.dp))
        Text(label, color = Color.White, fontSize = 10.sp)
    }
}

private fun liveFallbackUrl(url: String): String? {
    val clean = url.substringBefore('?')
    val query = url.substringAfter('?', "")
    val suffix = if (query.isBlank()) "" else "?$query"
    return when {
        clean.endsWith(".ts", ignoreCase = true) -> clean.dropLast(3) + ".m3u8" + suffix
        clean.endsWith(".m3u8", ignoreCase = true) -> clean.dropLast(5) + ".ts" + suffix
        else -> null
    }
}
