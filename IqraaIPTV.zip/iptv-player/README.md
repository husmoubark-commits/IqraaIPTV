# Iqraa IPTV

مشغّل IPTV أصلي للأندرويد (Kotlin + Jetpack Compose + Media3 ExoPlayer).
يدعم Xtream Codes و M3U، مع أقسام: قنوات مباشرة، أفلام، مسلسلات، EPG (الآن/التالي)،
مفضلة، واستكمال المشاهدة. الثيم بنفسجي متناسق مع لوجو Iqraa.

## طريقة البناء (من الموبايل عبر GitHub Actions)
1. اعمل Repository جديد على GitHub وارفع كل ملفات المشروع دي فيه.
2. ملف `.github/workflows/build.yml` بيشتغل تلقائيًا عند الـ push (أو شغّله يدوي من تبويب Actions → Build APK → Run workflow).
3. بعد ما يخلص، افتح الـ run → قسم Artifacts → نزّل **IqraaIPTV-debug-apk**.
4. فك الضغط وركّب `app-debug.apk` على التليفون أو جهاز الأندرويد.

## تسجيل الدخول
- **Xtream Codes:** رابط السيرفر (مثال `http://host:port`) + اسم المستخدم + كلمة المرور.
- **M3U:** رابط قائمة الـ M3U.

## تغيير الاسم أو اللوجو
- الاسم: عدّل `app/src/main/res/values/strings.xml` (`app_name`).
- اللوجو داخل التطبيق: استبدل `app/src/main/res/drawable-nodpi/logo.png`.
- أيقونة التطبيق: استبدل الصور في مجلدات `mipmap-*/ic_launcher.png`.
- الألوان: في `app/src/main/java/com/iptv/player/ui/theme/Theme.kt`.

## ملاحظات النسخة 1.0
- البناء Debug (مش موقّع بمفتاح إصدار) — كافي للتجربة والتركيب المباشر.
- M3U بيتعرض كقنوات مباشرة (لأن صيغة M3U مسطّحة). أقسام الأفلام والمسلسلات تتعبّى بالكامل مع Xtream.
- تحسينات قادمة ممكن نضيفها: تحكّم D-pad كامل للتليفزيون، Multi-Screen، Catch-up، EPG كامل (XMLTV).

> اللوجو والعلامة بتاعتك. التوزيع والوظائف أنماط قياسية لتطبيقات IPTV.
