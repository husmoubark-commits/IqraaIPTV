package com.iptv.player.data

import retrofit2.http.GET
import retrofit2.http.Query

interface XtreamApi {

    @GET("player_api.php")
    suspend fun liveCategories(
        @Query("username") u: String, @Query("password") p: String,
        @Query("action") a: String = "get_live_categories"
    ): List<CategoryDto>

    @GET("player_api.php")
    suspend fun liveStreams(
        @Query("username") u: String, @Query("password") p: String,
        @Query("category_id") cat: String? = null,
        @Query("action") a: String = "get_live_streams"
    ): List<LiveStreamDto>

    @GET("player_api.php")
    suspend fun vodCategories(
        @Query("username") u: String, @Query("password") p: String,
        @Query("action") a: String = "get_vod_categories"
    ): List<CategoryDto>

    @GET("player_api.php")
    suspend fun vodStreams(
        @Query("username") u: String, @Query("password") p: String,
        @Query("category_id") cat: String? = null,
        @Query("action") a: String = "get_vod_streams"
    ): List<VodStreamDto>

    @GET("player_api.php")
    suspend fun vodInfo(
        @Query("username") u: String, @Query("password") p: String,
        @Query("vod_id") id: String,
        @Query("action") a: String = "get_vod_info"
    ): VodInfoDto

    @GET("player_api.php")
    suspend fun seriesCategories(
        @Query("username") u: String, @Query("password") p: String,
        @Query("action") a: String = "get_series_categories"
    ): List<CategoryDto>

    @GET("player_api.php")
    suspend fun series(
        @Query("username") u: String, @Query("password") p: String,
        @Query("category_id") cat: String? = null,
        @Query("action") a: String = "get_series"
    ): List<SeriesDto>

    @GET("player_api.php")
    suspend fun seriesInfo(
        @Query("username") u: String, @Query("password") p: String,
        @Query("series_id") id: String,
        @Query("action") a: String = "get_series_info"
    ): SeriesInfoDto

    @GET("player_api.php")
    suspend fun accountInfo(
        @Query("username") u: String, @Query("password") p: String
    ): AccountInfoDto

    @GET("player_api.php")
    suspend fun shortEpg(
        @Query("username") u: String, @Query("password") p: String,
        @Query("stream_id") id: String, @Query("limit") limit: Int = 2,
        @Query("action") a: String = "get_short_epg"
    ): ShortEpgDto
}
