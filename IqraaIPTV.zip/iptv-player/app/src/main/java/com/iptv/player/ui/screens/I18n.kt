package com.iptv.player.ui.screens

import com.iptv.player.data.Graph

private val EN: Map<String, String> = mapOf(
    // ---- general / status ----
    "بدون انتهاء" to "No expiry",
    "التحميلات" to "Downloads",
    "لا يوجد تحميلات بعد" to "No downloads yet",
    "جاهز" to "Ready",
    "فشل" to "Failed",
    "متوقف" to "Paused",
    "تم التحديث" to "Refreshed",
    "جاري التحديث..." to "Refreshing...",
    "جارٍ التحميل" to "Loading",
    "جارٍ التحميل..." to "Loading...",
    "قناة" to "channels",
    "الآن" to "Now",
    "بدأ تحميل" to "Download started",

    // ---- live / channels ----
    "القنوات والدليل" to "Channels & Guide",
    "تحديث" to "Refresh",
    "ابحث عن قناة" to "Search channel",
    "اضغط على قناة لتشغيلها" to "Tap a channel to play",
    "اضغط على الشاشة للتكبير" to "Tap screen to expand",

    // ---- login / profile edit ----
    "تعديل البروفايل" to "Edit Profile",
    "أدخل بيانات الاشتراك" to "Enter subscription details",
    "رابط M3U" to "M3U URL",
    "اسم البروفايل (اختياري)" to "Profile name (optional)",
    "رابط السيرفر  http://host:port" to "Server URL  http://host:port",
    "اسم المستخدم" to "Username",
    "كلمة المرور" to "Password",
    "رابط قائمة M3U" to "M3U playlist URL",
    "املأ السيرفر واسم المستخدم وكلمة المرور" to "Fill in server, username and password",
    "أدخل رابط M3U" to "Enter the M3U URL",
    "حفظ" to "Save",
    "تسجيل الدخول" to "Login",

    // ---- movies / series ----
    "ابحث باسم الفيلم" to "Search by movie name",
    "ابحث باسم المسلسل" to "Search by series name",
    "لا توجد حلقات متاحة" to "No episodes available",

    // ---- player ----
    "تشغيل عبر" to "Play via",
    "● مباشر" to "● LIVE",
    "السابق" to "Previous",
    "السابقة" to "Previous",
    "الحلقات" to "Episodes",
    "الأبعاد" to "Aspect",
    "ترجمة" to "Subtitles",
    "بدون" to "Off",
    "تحميل" to "Download",
    "بدأ التحميل" to "Download started",
    "التالي" to "Next",
    "التالية" to "Next",

    // ---- profiles ----
    "البروفايلات والإعدادات" to "Profiles & Settings",
    "البروفايلات" to "Profiles",
    "إضافة بروفايل جديد" to "Add new profile",
    "وضع العرض" to "Display Mode",
    "تلقائي" to "Auto",
    "تلفون" to "Phone",
    "تشغيل الحلقة التالية تلقائيًا" to "Autoplay next episode",
    "تحديث تلقائي كل" to "Auto refresh every",
    "مغلق" to "Off",
    "15د" to "15m",
    "30د" to "30m",
    "60د" to "60m",
    "تسجيل الخروج" to "Logout",

    // ---- settings hub tiles ----
    "إعدادات عامة" to "General Settings",
    "صيغة البث" to "Stream Format",
    "وضع الجهاز" to "Device Mode",
    "المشغّل" to "Player",
    "مشغّل خارجي" to "External Player",
    "التشغيل التلقائي" to "Autoplay",
    "التحديث التلقائي" to "Auto Refresh",
    "تنسيق الوقت" to "Time Format",
    "معلومات الحساب" to "Account Info",
    "الملفات الشخصية" to "Profiles",
    "مسح الذاكرة المؤقتة" to "Clear Cache",
    "حول التطبيق" to "About",
    "الإعدادات" to "Settings",
    "تم" to "Done",

    // ---- settings dialogs ----
    "صيغة البث للقنوات المباشرة" to "Live channels stream format",
    "لو القنوات مش شغّالة جرّب صيغة تانية" to "If channels don't work, try another format",
    "ارجع وافتح القناة من جديد بعد التغيير" to "Reopen the channel after changing",
    "موبايل" to "Mobile",
    "تلفزيون" to "TV",
    "يفضّل إعادة فتح التطبيق بعد التغيير" to "Restart the app after changing",
    "إعدادات المشغّل" to "Player Settings",
    "مشغّل خارجي (VLC / MX)" to "External player (VLC / MX)",
    "تشغيل الحلقة التالية تلقائياً" to "Autoplay next episode",
    "المشغّل الخارجي" to "External Player",
    "عند التفعيل، القنوات والأفلام تفتح في تطبيق خارجي مثل VLC أو MX Player" to "When enabled, channels and movies open in an external app like VLC or MX Player",
    "استخدام مشغّل خارجي" to "Use external player",
    "التحديث التلقائي للمحتوى" to "Auto content refresh",
    "إيقاف" to "Off",
    "كل 15 دقيقة" to "Every 15 minutes",
    "كل 30 دقيقة" to "Every 30 minutes",
    "كل 60 دقيقة" to "Every 60 minutes",
    "كل 12 ساعة" to "Every 12 hours",
    "كل 24 ساعة" to "Every 24 hours",
    "كل 48 ساعة" to "Every 48 hours",
    "12 ساعة (AM/PM)" to "12-hour (AM/PM)",
    "24 ساعة" to "24-hour",

    // ---- account info ----
    "غير متاح لهذا النوع من الاشتراك (M3U) أو تعذّر الاتصال" to "Not available for this subscription type (M3U), or connection failed",
    "الاسم" to "Name",
    "الحالة" to "Status",
    "نشط" to "Active",
    "تاريخ الانتهاء" to "Expiry date",
    "الاتصالات" to "Connections",
    "تجريبي" to "Trial",
    "نعم" to "Yes",
    "لا" to "No",

    // ---- cache / general settings dialog ----
    "سيتم إعادة تحميل القنوات والأفلام والمسلسلات من جديد" to "Channels, movies and series will be reloaded",
    "تم مسح الذاكرة" to "Cache cleared",
    "مسح الآن" to "Clear now",
    "تفعيل الترجمة افتراضياً" to "Enable subtitles by default",
    "عرض الدليل (EPG) في المباشر" to "Show EPG in live",
    "مسح الذاكرة تلقائياً عند الفتح" to "Auto clear cache on start",
    "حد سجل القنوات (المتابعة)" to "Channels history limit",
    "اللغة" to "Language",
    "لا يوجد محتوى" to "No content",
    "آخر تحديث" to "Last update",
    "تشغيل" to "Play",
    "البطولة" to "Cast",
    "المخرج" to "Director",
    "لا توجد معلومات إضافية" to "No additional info",

    // ---- about ----
    "الإصدار 2.9" to "Version 2.9",
    "مشغّل IPTV يدعم Xtream Codes و M3U — قنوات مباشرة، أفلام، مسلسلات." to "IPTV player supporting Xtream Codes and M3U — live channels, movies and series."
)

/** Translate an Arabic UI string to the active language. Falls back to the original if no mapping. */
fun tr(ar: String): String =
    if (Graph.session.language == "en") (EN[ar] ?: ar) else ar
