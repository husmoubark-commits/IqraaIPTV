package com.iptv.player.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// Brand palette (Voltix — electric blue + gold)
val BrandPrimary = Color(0xFF1FA2FF)
val BrandBright = Color(0xFF4FC3FF)
val BrandDeep = Color(0xFF0D47A1)
val Indigo = Color(0xFF2962FF)
val Gold = Color(0xFFFFC400)

val Bg = Color(0xFF0A0E1A)
val Surface1 = Color(0xFF121826)
val Surface2 = Color(0xFF1B2436)
val OnBg = Color(0xFFEAF2FF)
val Muted = Color(0xFF9DB0CC)

private val scheme = darkColorScheme(
    primary = BrandPrimary,
    onPrimary = Color.White,
    secondary = Gold,
    background = Bg,
    onBackground = OnBg,
    surface = Surface1,
    onSurface = OnBg,
    surfaceVariant = Surface2,
    onSurfaceVariant = Muted,
    outline = Color(0xFF25405F)
)

val LiveGradient = Brush.linearGradient(listOf(Color(0xFF1FA2FF), Color(0xFF0B57C2)))
val MoviesGradient = Brush.linearGradient(listOf(Color(0xFFF2A60C), Color(0xFFB45A06)))
val SeriesGradient = Brush.linearGradient(listOf(Color(0xFF3D7BFF), Color(0xFF15246E)))

@Composable
fun IqraaTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, typography = Typography(), content = content)
}
