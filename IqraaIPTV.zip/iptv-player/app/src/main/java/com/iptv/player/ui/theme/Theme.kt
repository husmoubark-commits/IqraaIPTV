package com.iptv.player.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// Brand palette (matched to the Iqraa purple logo)
val BrandPrimary = Color(0xFFA435E0)
val BrandBright = Color(0xFFC44DF0)
val BrandDeep = Color(0xFF6A1B9A)
val Indigo = Color(0xFF7C4DFF)

val Bg = Color(0xFF120A1F)
val Surface1 = Color(0xFF1E1233)
val Surface2 = Color(0xFF2A1A45)
val OnBg = Color(0xFFF3ECFA)
val Muted = Color(0xFFB9A9D6)

private val scheme = darkColorScheme(
    primary = BrandPrimary,
    onPrimary = Color.White,
    secondary = BrandBright,
    background = Bg,
    onBackground = OnBg,
    surface = Surface1,
    onSurface = OnBg,
    surfaceVariant = Surface2,
    onSurfaceVariant = Muted,
    outline = Color(0xFF4A2E70)
)

val LiveGradient = Brush.linearGradient(listOf(Color(0xFF7B2FF7), Color(0xFF4A1FB8)))
val MoviesGradient = Brush.linearGradient(listOf(Color(0xFFC840E8), Color(0xFF7A1FA2)))
val SeriesGradient = Brush.linearGradient(listOf(Color(0xFF9B3FE0), Color(0xFF532A8F)))

@Composable
fun IqraaTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, typography = Typography(), content = content)
}
