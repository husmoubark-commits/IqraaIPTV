package com.iptv.player

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class DownloadClickReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val open = Intent(context, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra("route", "downloads")
        }
        context.startActivity(open)
    }
}
