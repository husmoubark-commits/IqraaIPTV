package com.iptv.player.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.iptv.player.data.Graph
import com.iptv.player.ui.AppMode
import com.iptv.player.ui.Refresh
import com.iptv.player.ui.Selection
import com.iptv.player.ui.theme.*

@Composable
fun ProfilesScreen(nav: NavHostController) {
    val s = Graph.session
    var current by remember { mutableIntStateOf(s.currentIndex) }
    var mode by remember { mutableStateOf(s.displayMode) }
    var autoplay by remember { mutableStateOf(s.autoPlayNext) }
    var refresh by remember { mutableIntStateOf(s.refreshInterval) }
    var tick by remember { mutableIntStateOf(0) }

    Column(Modifier.fillMaxSize().background(Bg)) {
        TopBar(nav, tr("البروفايلات والإعدادات"))
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {

            Text(tr("البروفايلات"), color = Color.White, fontSize = 16.sp)
            Spacer(Modifier.height(8.dp))
            s.profiles.forEachIndexed { i, acc ->
                key(tick, i) {
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 5.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (i == current) BrandPrimary else Surface1)
                            .tvFocusBorder(RoundedCornerShape(12.dp))
                            .clickable { s.switchTo(i); Graph.repo.clearCache(); Refresh.tick++; nav.navigate("home") { popUpTo("home") { inclusive = true } } }
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(acc.name, color = Color.White, fontSize = 15.sp)
                            Text(if (acc.type.name == "M3U") "M3U" else acc.server, color = Color(0xCCFFFFFF), fontSize = 11.sp, maxLines = 1)
                        }
                        IconButton(onClick = {
                            Selection.editProfile = acc; Selection.editIndex = i; nav.navigate("login")
                        }) { Icon(Icons.Filled.Edit, "edit", tint = Color.White) }
                        IconButton(onClick = {
                            s.deleteProfile(i); current = s.currentIndex; tick++
                        }) { Icon(Icons.Filled.Delete, "delete", tint = Color.White) }
                    }
                }
            }

            Spacer(Modifier.height(8.dp))
            Row(
                Modifier.clip(RoundedCornerShape(12.dp)).background(Surface2)
                    .tvFocusBorder()
                    .clickable { Selection.editProfile = null; Selection.editIndex = null; nav.navigate("login") }.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Filled.Add, null, tint = BrandBright)
                Spacer(Modifier.width(8.dp))
                Text(tr("إضافة بروفايل جديد"), color = Color.White)
            }

            Spacer(Modifier.height(24.dp))
            HorizontalDivider(color = Surface2)
            Spacer(Modifier.height(16.dp))

            Text(tr("وضع العرض"), color = Color.White, fontSize = 16.sp)
            Spacer(Modifier.height(8.dp))
            Row {
                ModeChip(tr("تلقائي"), mode == "auto") { mode = "auto"; s.setMode("auto"); AppMode.isTv = autoDetectTv() }
                Spacer(Modifier.width(8.dp))
                ModeChip(tr("تلفون"), mode == "phone") { mode = "phone"; s.setMode("phone"); AppMode.isTv = false }
                Spacer(Modifier.width(8.dp))
                ModeChip("TV", mode == "tv") { mode = "tv"; s.setMode("tv"); AppMode.isTv = true }
            }

            Spacer(Modifier.height(20.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(tr("تشغيل الحلقة التالية تلقائيًا"), color = Color.White, modifier = Modifier.weight(1f))
                Switch(checked = autoplay, onCheckedChange = { autoplay = it; s.setAutoPlay(it) })
            }

            Spacer(Modifier.height(20.dp))
            Text(tr("تحديث تلقائي كل"), color = Color.White, fontSize = 16.sp)
            Spacer(Modifier.height(8.dp))
            Row {
                RefreshChip(tr("مغلق"), refresh == 0) { refresh = 0; s.setRefreshInterval(0) }
                Spacer(Modifier.width(8.dp))
                RefreshChip(tr("15د"), refresh == 15) { refresh = 15; s.setRefreshInterval(15) }
                Spacer(Modifier.width(8.dp))
                RefreshChip(tr("30د"), refresh == 30) { refresh = 30; s.setRefreshInterval(30) }
                Spacer(Modifier.width(8.dp))
                RefreshChip(tr("60د"), refresh == 60) { refresh = 60; s.setRefreshInterval(60) }
            }

            Spacer(Modifier.height(28.dp))
            Row(
                Modifier.clip(RoundedCornerShape(12.dp)).background(Color(0x33FF5252))
                    .tvFocusBorder()
                    .clickable { s.logout(); nav.navigate("login") { popUpTo("home") { inclusive = true } } }.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Filled.Logout, null, tint = Color(0xFFFF6B6B))
                Spacer(Modifier.width(8.dp))
                Text(tr("تسجيل الخروج"), color = Color(0xFFFF6B6B))
            }
            Spacer(Modifier.height(30.dp))
        }
    }
}

private fun autoDetectTv(): Boolean = AppMode.isTv  // keep current detection until restart

@Composable
private fun ModeChip(text: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.clip(RoundedCornerShape(10.dp)).background(if (selected) BrandPrimary else Surface1)
            .tvFocusBorder().clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 10.dp)
    ) { Text(text, color = if (selected) Color.White else Muted) }
}

@Composable
private fun RefreshChip(text: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.clip(RoundedCornerShape(10.dp)).background(if (selected) BrandPrimary else Surface1)
            .tvFocusBorder().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 9.dp)
    ) { Text(text, color = if (selected) Color.White else Muted) }
}
