package com.iptv.player.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.iptv.player.data.Account
import com.iptv.player.data.AccountType
import com.iptv.player.data.Graph
import com.iptv.player.ui.Selection
import com.iptv.player.ui.theme.*

@Composable
fun LoginScreen(nav: NavHostController) {
    val editing = Selection.editProfile
    val editIndex = Selection.editIndex

    var xtream by remember { mutableStateOf(editing?.type != AccountType.M3U) }
    var server by remember { mutableStateOf(editing?.server ?: "") }
    var user by remember { mutableStateOf(editing?.username ?: "") }
    var pass by remember { mutableStateOf(editing?.password ?: "") }
    var name by remember { mutableStateOf(editing?.name?.takeIf { it != "User" } ?: "") }
    var m3u by remember { mutableStateOf(editing?.m3uUrl ?: "") }
    var error by remember { mutableStateOf<String?>(null) }

    Column(
        Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(16.dp))
        BrandLogo(96.dp)
        Spacer(Modifier.height(8.dp))
        Text("Iqraa IPTV", color = Color.White, style = MaterialTheme.typography.headlineSmall)
        Text(if (editIndex != null) "تعديل البروفايل" else "أدخل بيانات الاشتراك", color = Muted)
        Spacer(Modifier.height(20.dp))

        Row(Modifier.clip(RoundedCornerShape(12.dp)).background(Surface1).padding(4.dp)) {
            ToggleChip("Xtream Codes", xtream) { xtream = true }
            ToggleChip("رابط M3U", !xtream) { xtream = false }
        }
        Spacer(Modifier.height(18.dp))

        Field(name, { name = it }, "اسم البروفايل (اختياري)")
        if (xtream) {
            Field(server, { server = it }, "رابط السيرفر  http://host:port")
            Field(user, { user = it }, "اسم المستخدم")
            Field(pass, { pass = it }, "كلمة المرور", password = true)
        } else {
            Field(m3u, { m3u = it }, "رابط قائمة M3U")
        }

        error?.let { Spacer(Modifier.height(8.dp)); Text(it, color = Color(0xFFFF6B6B)) }

        Spacer(Modifier.height(18.dp))
        Button(
            onClick = {
                val acc = if (xtream) {
                    val srv = normalize(server)
                    if (srv.isBlank() || user.isBlank() || pass.isBlank()) { error = "املأ السيرفر واسم المستخدم وكلمة المرور"; return@Button }
                    Account(AccountType.XTREAM, srv, user.trim(), pass.trim(), name = name.ifBlank { "User" })
                } else {
                    if (m3u.isBlank()) { error = "أدخل رابط M3U"; return@Button }
                    Account(AccountType.M3U, m3uUrl = m3u.trim(), name = name.ifBlank { "User" })
                }
                if (editIndex != null) { Graph.session.updateProfile(editIndex, acc); Graph.session.switchTo(editIndex) }
                else Graph.session.addProfile(acc)
                Selection.editProfile = null; Selection.editIndex = null
                Graph.repo.clearCache()
                nav.navigate("home") { popUpTo(nav.graph.id) { inclusive = true } }
            },
            modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = BrandPrimary)
        ) { Text(if (editIndex != null) "حفظ" else "تسجيل الدخول", color = Color.White) }
        Spacer(Modifier.height(30.dp))
    }
}

private fun normalize(server: String): String {
    val s = server.trim()
    if (s.isBlank()) return ""
    return if (s.startsWith("http://") || s.startsWith("https://")) s.trimEnd('/') else "http://${s.trimEnd('/')}"
}

@Composable
private fun ToggleChip(text: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.clip(RoundedCornerShape(10.dp)).background(if (selected) BrandPrimary else Color.Transparent)
            .clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 10.dp)
    ) { Text(text, color = if (selected) Color.White else Muted) }
}

@Composable
private fun Field(value: String, onChange: (String) -> Unit, hint: String, password: Boolean = false) {
    OutlinedTextField(
        value = value, onValueChange = onChange,
        placeholder = { Text(hint, color = Muted) }, singleLine = true,
        visualTransformation = if (password) PasswordVisualTransformation() else VisualTransformation.None,
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = BrandPrimary, unfocusedBorderColor = Surface2,
            focusedTextColor = Color.White, unfocusedTextColor = Color.White,
            focusedContainerColor = Surface1, unfocusedContainerColor = Surface1
        )
    )
}
