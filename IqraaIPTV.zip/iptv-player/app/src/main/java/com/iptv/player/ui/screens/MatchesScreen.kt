package com.iptv.player.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import coil.compose.AsyncImage
import com.iptv.player.data.MatchItem
import com.iptv.player.data.MatchesApi
import com.iptv.player.data.MatchesResponse
import com.iptv.player.ui.Refresh
import com.iptv.player.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

@Composable
fun MatchesScreen(nav: NavHostController) {
    var loading by remember { mutableStateOf(true) }
    var data by remember { mutableStateOf(MatchesResponse()) }

    LaunchedEffect(Refresh.tick) {
        loading = true
        data = MatchesApi.fetch()
        loading = false
    }

    val today = remember {
        SimpleDateFormat("yyyy-MM-dd", Locale.US)
            .apply { timeZone = TimeZone.getTimeZone("Africa/Cairo") }.format(Date())
    }

    Column(Modifier.fillMaxSize().background(Bg)) {
        // شريط علوي
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.clip(RoundedCornerShape(10.dp)).tvFocusBorder(RoundedCornerShape(10.dp))
                .clickable { nav.popBackStack() }.padding(6.dp)) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "back", tint = Color.White, modifier = Modifier.size(26.dp))
            }
            Spacer(Modifier.width(10.dp))
            BrandLogo(34.dp)
            Spacer(Modifier.width(10.dp))
            Text(tr("مواعيد المباريات"), color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            Box(Modifier.clip(RoundedCornerShape(10.dp)).background(Surface2)
                .tvFocusBorder(RoundedCornerShape(10.dp)).clickable { Refresh.tick++ }.padding(8.dp)) {
                Icon(Icons.Filled.Refresh, "refresh", tint = BrandBright, modifier = Modifier.size(24.dp))
            }
        }

        when {
            loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { LoadingBox() }
            data.matches.isEmpty() -> Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                Text(
                    if (!data.ok && data.error != null) "${tr("تعذّر تحميل المباريات")}\n${data.error}" else tr("لا مباريات في المواعيد القريبة"),
                    color = Muted, fontSize = 14.sp, textAlign = TextAlign.Center
                )
            }
            else -> {
                val byDate = data.matches.groupBy { it.date }.toSortedMap()
                LazyColumn(
                    Modifier.fillMaxSize().padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 20.dp)
                ) {
                    byDate.forEach { (date, list) ->
                        item(key = "h_$date") {
                            Text(
                                dateLabel(date, today),
                                color = BrandBright, fontSize = 15.sp, fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(top = 10.dp, bottom = 2.dp)
                            )
                        }
                        items(list.sortedBy { it.time }, key = { it.id.ifEmpty { it.teamA + it.time } }) { m ->
                            MatchRow(m)
                        }
                    }
                }
            }
        }
    }
}

private fun dateLabel(date: String, today: String): String {
    if (date == today) return "اليوم"
    return date
}

@Composable
private fun MatchRow(m: MatchItem) {
    val ended = m.status == "انتهت" && (m.scoreA.isNotEmpty() || m.scoreB.isNotEmpty())
    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Surface1).padding(12.dp)) {
        Column(Modifier.fillMaxWidth()) {
            // البطولة + القناة
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(m.competition, color = Muted, fontSize = 12.sp, maxLines = 1,
                    overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                if (m.channel.isNotEmpty()) {
                    Row(
                        Modifier.clip(RoundedCornerShape(8.dp)).background(BrandPrimary)
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.LiveTv, null, tint = Color.White, modifier = Modifier.size(13.dp))
                        Spacer(Modifier.width(5.dp))
                        Text(m.channel, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium, maxLines = 1)
                    }
                }
            }

            Spacer(Modifier.height(10.dp))

            // الفريقين + الوقت/النتيجة
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                // فريق أ
                Row(Modifier.weight(1f), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
                    Text(m.teamA, color = Color.White, fontSize = 14.sp, maxLines = 1,
                        overflow = TextOverflow.Ellipsis, textAlign = TextAlign.End, modifier = Modifier.weight(1f, false))
                    Spacer(Modifier.width(8.dp))
                    AsyncImage(m.logoA, m.teamA, Modifier.size(30.dp))
                }
                // الوسط: وقت أو نتيجة
                Column(Modifier.width(88.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    if (ended) {
                        Text("${m.scoreA} - ${m.scoreB}", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    } else {
                        Text(m.time.ifEmpty { "—" }, color = BrandBright, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    }
                    Text(m.status, color = Muted, fontSize = 11.sp, maxLines = 1)
                }
                // فريق ب
                Row(Modifier.weight(1f), horizontalArrangement = Arrangement.Start, verticalAlignment = Alignment.CenterVertically) {
                    AsyncImage(m.logoB, m.teamB, Modifier.size(30.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(m.teamB, color = Color.White, fontSize = 14.sp, maxLines = 1,
                        overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, false))
                }
            }
        }
    }
}
