package com.iptv.player.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlinx.coroutines.delay
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.iptv.player.R
import com.iptv.player.data.Category
import com.iptv.player.ui.theme.*

fun Modifier.tvFocusBorder(shape: Shape = RoundedCornerShape(8.dp)): Modifier = composed {
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (focused) 1.07f else 1f, label = "focusScale")
    this
        .scale(scale)
        .border(if (focused) 3.dp else 0.dp, if (focused) Color.White else Color.Transparent, shape)
        .onFocusChanged { focused = it.isFocused }
}

@Composable
fun BrandLogo(height: Dp, modifier: Modifier = Modifier) {
    Image(
        painter = painterResource(R.drawable.logo),
        contentDescription = "Voltix IPTV Player",
        modifier = modifier.height(height),
        contentScale = ContentScale.Fit
    )
}

@Composable
fun LoadingBox(modifier: Modifier = Modifier) {
    Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        CircularProgressIndicator(color = BrandPrimary)
    }
}

@Composable
fun CategorySidebar(
    categories: List<Category>,
    selectedId: String?,
    onSelect: (Category) -> Unit,
    modifier: Modifier = Modifier
) {
    var query by remember { mutableStateOf("") }
    val filtered = remember(categories, query) {
        if (query.isBlank()) categories else categories.filter { it.name.contains(query, true) }
    }
    val firstFocus = remember { FocusRequester() }
    val listState = rememberLazyListState()
    var focusDone by remember { mutableStateOf(false) }
    val selIdx = remember(filtered, selectedId) {
        filtered.indexOfFirst { it.id == selectedId }.coerceAtLeast(0)
    }
    LaunchedEffect(filtered.size) {
        if (!focusDone && filtered.isNotEmpty()) {
            if (selIdx > 0) runCatching { listState.scrollToItem(selIdx) }
            delay(160); runCatching { firstFocus.requestFocus() }; focusDone = true
        }
    }
    Column(modifier.background(Color(0xFF160C28))) {
        OutlinedTextField(
            value = query, onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth().padding(8.dp),
            placeholder = { Text("Search", color = Muted, fontSize = 13.sp) },
            leadingIcon = { Icon(Icons.Filled.Search, null, tint = Muted) },
            singleLine = true, textStyle = androidx.compose.ui.text.TextStyle(fontSize = 13.sp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = BrandPrimary, unfocusedBorderColor = Surface2,
                focusedTextColor = Color.White, unfocusedTextColor = Color.White
            )
        )
        LazyColumn(Modifier.fillMaxSize(), state = listState) {
            itemsIndexed(filtered) { i, cat ->
                val selected = cat.id == selectedId
                Row(
                    Modifier.fillMaxWidth()
                        .then(if (i == selIdx) Modifier.focusRequester(firstFocus) else Modifier)
                        .background(if (selected) BrandPrimary else Color.Transparent)
                        .tvFocusBorder()
                        .clickable { onSelect(cat) }
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        cat.name,
                        color = if (selected) Color.White else Color(0xFFDDD2EE),
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                        fontSize = 13.sp, lineHeight = 16.sp, maxLines = 2,
                        modifier = Modifier.weight(1f)
                    )
                    if (cat.count > 0) Text(cat.count.toString(), color = if (selected) Color.White else Muted, fontSize = 11.sp)
                }
                HorizontalDivider(color = Color(0x18FFFFFF))
            }
        }
    }
}

@Composable
fun PosterCard(
    title: String,
    image: String?,
    modifier: Modifier = Modifier,
    onDownload: (() -> Unit)? = null,
    onClick: () -> Unit
) {
    Column(modifier.width(132.dp).tvFocusBorder(RoundedCornerShape(10.dp)).clickable { onClick() }.padding(6.dp)) {
        Box(Modifier.fillMaxWidth().height(186.dp).clip(RoundedCornerShape(10.dp)).background(Surface1)) {
            AsyncImage(image, title, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            if (onDownload != null) {
                Box(
                    Modifier.align(Alignment.TopEnd).padding(6.dp).size(30.dp)
                        .clip(CircleShape).background(Color(0xCC1A0F30)).clickable { onDownload() },
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Filled.Download, "download", tint = BrandBright, modifier = Modifier.size(18.dp)) }
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(title, color = Color.White, fontSize = 12.sp, maxLines = 2)
    }
}

@Composable
fun DownloadIconButton(onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier.size(34.dp).clip(CircleShape).background(Surface2).tvFocusBorder(CircleShape).clickable { onClick() },
        contentAlignment = Alignment.Center
    ) { Icon(Icons.Filled.Download, "download", tint = BrandBright, modifier = Modifier.size(18.dp)) }
}

@Composable
fun ItemSearchBar(query: String, onChange: (String) -> Unit, hint: String, modifier: Modifier = Modifier) {
    OutlinedTextField(
        value = query, onValueChange = onChange,
        modifier = modifier.fillMaxWidth().padding(8.dp),
        placeholder = { Text(hint, color = Muted, fontSize = 13.sp) },
        leadingIcon = { Icon(Icons.Filled.Search, null, tint = Muted) },
        singleLine = true,
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = BrandPrimary, unfocusedBorderColor = Surface2,
            focusedTextColor = Color.White, unfocusedTextColor = Color.White,
            focusedContainerColor = Surface1, unfocusedContainerColor = Surface1
        )
    )
}
