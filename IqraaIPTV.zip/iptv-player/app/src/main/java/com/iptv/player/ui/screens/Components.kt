package com.iptv.player.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.iptv.player.R
import com.iptv.player.data.Category
import com.iptv.player.ui.theme.BrandPrimary
import com.iptv.player.ui.theme.Muted
import com.iptv.player.ui.theme.Surface1
import com.iptv.player.ui.theme.Surface2

@Composable
fun BrandLogo(height: Dp, modifier: Modifier = Modifier) {
    Image(
        painter = painterResource(R.drawable.logo),
        contentDescription = "Iqraa IPTV",
        modifier = modifier.height(height),
        contentScale = ContentScale.Fit
    )
}

@Composable
fun LoadingBox(modifier: Modifier = Modifier) {
    Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        CircularProgressIndicator(color = BrandPrimary)
    }
}

@Composable
fun CategorySidebar(
    categories: List<Category>,
    selectedId: String?,
    onSelect: (Category) -> Unit,
    modifier: Modifier = Modifier
) {
    var query by remember { mutableStateOf("") }
    val filtered = remember(categories, query) {
        if (query.isBlank()) categories
        else categories.filter { it.name.contains(query, ignoreCase = true) }
    }
    Column(modifier.background(Color(0xFF160C28))) {
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth().padding(10.dp),
            placeholder = { Text("Search in categories", color = Muted) },
            leadingIcon = { Icon(Icons.Filled.Search, null, tint = Muted) },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = BrandPrimary,
                unfocusedBorderColor = Surface2,
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White
            )
        )
        LazyColumn(Modifier.fillMaxSize()) {
            items(filtered) { cat ->
                val selected = cat.id == selectedId
                Row(
                    Modifier
                        .fillMaxWidth()
                        .background(if (selected) BrandPrimary else Color.Transparent)
                        .clickable { onSelect(cat) }
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        cat.name,
                        color = if (selected) Color.White else Color(0xFFDDD2EE),
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    if (cat.count > 0) {
                        Text(cat.count.toString(), color = if (selected) Color.White else Muted, fontSize = 13.sp)
                    }
                }
                HorizontalDivider(color = Color(0x22FFFFFF))
            }
        }
    }
}

@Composable
fun PosterCard(
    title: String,
    image: String?,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Column(
        modifier
            .width(132.dp)
            .clickable { onClick() }
            .padding(6.dp)
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(186.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Surface1)
        ) {
            AsyncImage(
                model = image,
                contentDescription = title,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        }
        Spacer(Modifier.height(6.dp))
        Text(
            title,
            color = Color.White,
            fontSize = 12.sp,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
    }
}
