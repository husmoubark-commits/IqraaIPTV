package com.iptv.player.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.iptv.player.data.Graph
import com.iptv.player.data.Season
import com.iptv.player.ui.PlayInfo
import com.iptv.player.ui.Selection
import com.iptv.player.ui.theme.*

@Composable
fun SeriesDetailScreen(nav: NavHostController) {
    val repo = Graph.repo
    val series = Selection.series
    var seasons by remember { mutableStateOf<List<Season>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var selectedSeason by remember { mutableStateOf(0) }

    LaunchedEffect(series?.id) {
        if (series != null) {
            seasons = runCatching { repo.seriesInfo(series.id) }.getOrDefault(emptyList())
            selectedSeason = seasons.firstOrNull()?.number ?: 0
        }
        loading = false
    }

    Column(Modifier.fillMaxSize().background(Bg)) {
        TopBar(nav, series?.name ?: "Series")
        if (loading) { LoadingBox(); return@Column }
        if (series == null || seasons.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("لا توجد حلقات متاحة", color = Muted)
            }
            return@Column
        }

        // season chips
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(12.dp)) {
            seasons.forEach { s ->
                val sel = s.number == selectedSeason
                Box(
                    Modifier.padding(end = 8.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(if (sel) BrandPrimary else Surface2)
                        .clickable { selectedSeason = s.number }
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) { Text("S${s.number}", color = Color.White) }
            }
        }

        val episodes = seasons.firstOrNull { it.number == selectedSeason }?.episodes ?: emptyList()
        LazyColumn(Modifier.fillMaxSize()) {
            items(episodes) { ep ->
                Row(
                    Modifier.fillMaxWidth()
                        .clickable {
                            Selection.play = PlayInfo(
                                repo.seriesUrl(ep.id, ep.extension),
                                "${series.name} S%02dE%02d".format(ep.season, ep.episodeNum),
                                "series", ep.id, ep.cover ?: series.cover
                            )
                            nav.navigate("player")
                        }
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(34.dp).clip(RoundedCornerShape(8.dp)).background(Surface2), contentAlignment = Alignment.Center) {
                        Icon(Icons.Filled.PlayArrow, null, tint = BrandBright)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("E${ep.episodeNum} • ${ep.title}", color = Color.White, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (!ep.plot.isNullOrBlank()) {
                            Text(ep.plot, color = Muted, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
                HorizontalDivider(color = Color(0x14FFFFFF))
            }
        }
    }
}
