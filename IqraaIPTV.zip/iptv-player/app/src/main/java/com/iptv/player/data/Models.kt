package com.iptv.player.data

import com.google.gson.annotations.SerializedName

enum class AccountType { XTREAM, M3U }

data class Account(
    val type: AccountType,
    val server: String = "",
    val username: String = "",
    val password: String = "",
    val m3uUrl: String = "",
    val name: String = "User"
)

// ---------- clean UI models ----------
data class Category(val id: String, val name: String, val count: Int = 0)

data class LiveChannel(
    val id: String,
    val name: String,
    val logo: String?,
    val epgChannelId: String?,
    val categoryId: String?
)

data class VodItem(
    val id: String,
    val name: String,
    val poster: String?,
    val categoryId: String?,
    val rating: String?,
    val extension: String?
)

data class SeriesItem(
    val id: String,
    val name: String,
    val cover: String?,
    val plot: String?,
    val categoryId: String?,
    val rating: String?
)

data class Season(val number: Int, val name: String, val episodes: List<Episode>)

data class Episode(
    val id: String,
    val title: String,
    val season: Int,
    val episodeNum: Int,
    val extension: String?,
    val cover: String?,
    val plot: String?
)

data class EpgEntry(val title: String, val description: String)

// ---------- Xtream DTOs ----------
data class CategoryDto(
    @SerializedName("category_id") val categoryId: String?,
    @SerializedName("category_name") val categoryName: String?
)

data class LiveStreamDto(
    @SerializedName("name") val name: String?,
    @SerializedName("stream_id") val streamId: String?,
    @SerializedName("stream_icon") val streamIcon: String?,
    @SerializedName("epg_channel_id") val epgChannelId: String?,
    @SerializedName("category_id") val categoryId: String?
)

data class VodStreamDto(
    @SerializedName("name") val name: String?,
    @SerializedName("stream_id") val streamId: String?,
    @SerializedName("stream_icon") val streamIcon: String?,
    @SerializedName("rating") val rating: String?,
    @SerializedName("category_id") val categoryId: String?,
    @SerializedName("container_extension") val containerExtension: String?
)

data class SeriesDto(
    @SerializedName("series_id") val seriesId: String?,
    @SerializedName("name") val name: String?,
    @SerializedName("cover") val cover: String?,
    @SerializedName("plot") val plot: String?,
    @SerializedName("rating") val rating: String?,
    @SerializedName("category_id") val categoryId: String?
)

data class SeriesInfoDto(
    @SerializedName("episodes") val episodes: Map<String, List<EpisodeDto>>?
)

data class EpisodeDto(
    @SerializedName("id") val id: String?,
    @SerializedName("episode_num") val episodeNum: String?,
    @SerializedName("title") val title: String?,
    @SerializedName("container_extension") val containerExtension: String?,
    @SerializedName("season") val season: String?,
    @SerializedName("info") val info: EpisodeInfoDto?
)

data class EpisodeInfoDto(
    @SerializedName("movie_image") val movieImage: String?,
    @SerializedName("plot") val plot: String?
)

data class ShortEpgDto(@SerializedName("epg_listings") val listings: List<EpgListingDto>?)
data class EpgListingDto(
    @SerializedName("title") val title: String?,
    @SerializedName("description") val description: String?
)

// ---------- Account info ----------
data class AccountInfo(
    val status: String, val expiry: String, val activeCons: String,
    val maxCons: String, val trial: Boolean
)

data class AccountInfoDto(
    @SerializedName("user_info") val userInfo: UserInfoDto?
)
data class UserInfoDto(
    @SerializedName("status") val status: String?,
    @SerializedName("exp_date") val expDate: String?,
    @SerializedName("active_cons") val activeCons: String?,
    @SerializedName("max_connections") val maxConnections: String?,
    @SerializedName("is_trial") val isTrial: String?
)

// ---------- VOD (movie) info ----------
data class MovieInfo(
    val plot: String?, val genre: String?, val cast: String?,
    val director: String?, val releaseDate: String?, val duration: String?,
    val rating: String?, val poster: String?
)
data class VodInfoDto(@SerializedName("info") val info: VodInfoInner?)
data class VodInfoInner(
    @SerializedName("plot") val plot: String?,
    @SerializedName("genre") val genre: String?,
    @SerializedName("cast") val cast: String?,
    @SerializedName("director") val director: String?,
    @SerializedName("releasedate") val releaseDate: String?,
    @SerializedName("duration") val duration: String?,
    @SerializedName("rating") val rating: String?,
    @SerializedName("movie_image") val movieImage: String?
)
