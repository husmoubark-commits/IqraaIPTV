package com.iptv.player

import android.app.Application
import com.iptv.player.data.Graph

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Graph.init(this)
    }
}
