package com.iptv.player.data

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class Session(context: Context) {
    private val prefs = context.getSharedPreferences("iqraa_iptv", Context.MODE_PRIVATE)
    private val gson = Gson()

    val profiles: MutableList<Account> = loadProfiles()
    var currentIndex: Int = prefs.getInt("current", 0); private set
    var displayMode: String = prefs.getString("mode", "auto") ?: "auto"; private set  // auto|phone|tv
    var autoPlayNext: Boolean = prefs.getBoolean("autoplay", true); private set
    var refreshInterval: Int = prefs.getInt("refresh", 0); private set               // minutes, 0=off
    var lastRefresh: Long = prefs.getLong("lastRefresh", 0L); private set
    var streamFormat: String = prefs.getString("streamFmt", "hls") ?: "hls"; private set   // default|mpegts|hls
    var useExternalPlayer: Boolean = prefs.getBoolean("extPlayer", false); private set
    var timeFormat: String = prefs.getString("timeFmt", "12") ?: "12"; private set        // 12|24
    var activeSubtitle: Boolean = prefs.getBoolean("activeSub", true); private set         // default subtitles on
    var showEpg: Boolean = prefs.getBoolean("showEpg", true); private set                   // show EPG in live
    var autoClearCache: Boolean = prefs.getBoolean("autoClear", false); private set         // clear cache on start
    var channelsHistoryLimit: Int = prefs.getInt("histLimit", 10); private set              // continue-watching live count
    var language: String = prefs.getString("lang", "ar") ?: "ar"; private set            // ar|en
    var aspectMode: Int = prefs.getInt("aspectMode", 0); private set                       // 0=fit 1=zoom 2=fill

    val account: Account? get() = profiles.getOrNull(currentIndex)

    private fun loadProfiles(): MutableList<Account> {
        val json = prefs.getString("profiles", null)
        if (json != null) {
            return runCatching {
                gson.fromJson<MutableList<Account>>(json, object : TypeToken<MutableList<Account>>() {}.type)
            }.getOrNull() ?: mutableListOf()
        }
        val type = prefs.getString("type", null)
        if (type != null) {
            return mutableListOf(
                Account(
                    AccountType.valueOf(type),
                    prefs.getString("server", "") ?: "",
                    prefs.getString("user", "") ?: "",
                    prefs.getString("pass", "") ?: "",
                    prefs.getString("m3u", "") ?: "",
                    prefs.getString("name", "User") ?: "User"
                )
            )
        }
        return mutableListOf()
    }

    private fun persist() {
        prefs.edit()
            .putString("profiles", gson.toJson(profiles))
            .putInt("current", currentIndex)
            .putString("mode", displayMode)
            .putBoolean("autoplay", autoPlayNext)
            .putInt("refresh", refreshInterval)
            .putLong("lastRefresh", lastRefresh)
            .putString("streamFmt", streamFormat)
            .putBoolean("extPlayer", useExternalPlayer)
            .putString("timeFmt", timeFormat)
            .putBoolean("activeSub", activeSubtitle)
            .putBoolean("showEpg", showEpg)
            .putBoolean("autoClear", autoClearCache)
            .putInt("histLimit", channelsHistoryLimit)
            .putString("lang", language)
            .putInt("aspectMode", aspectMode)
            .apply()
    }

    fun addProfile(a: Account) { profiles.add(a); currentIndex = profiles.lastIndex; persist() }
    fun updateProfile(index: Int, a: Account) { if (index in profiles.indices) { profiles[index] = a; persist() } }
    fun switchTo(index: Int) { if (index in profiles.indices) { currentIndex = index; persist() } }
    fun deleteProfile(index: Int) {
        if (index in profiles.indices) {
            profiles.removeAt(index)
            if (currentIndex >= profiles.size) currentIndex = (profiles.size - 1).coerceAtLeast(0)
            persist()
        }
    }
    fun setMode(m: String) { displayMode = m; persist() }
    fun setAutoPlay(b: Boolean) { autoPlayNext = b; persist() }
    fun setRefreshInterval(m: Int) { refreshInterval = m; persist() }
    fun markRefreshed() { lastRefresh = System.currentTimeMillis(); persist() }
    fun setStreamFormat(v: String) { streamFormat = v; persist() }
    fun setExternalPlayer(b: Boolean) { useExternalPlayer = b; persist() }
    fun setTimeFormat(v: String) { timeFormat = v; persist() }
    fun setActiveSubtitle(b: Boolean) { activeSubtitle = b; persist() }
    fun setShowEpg(b: Boolean) { showEpg = b; persist() }
    fun setAutoClearCache(b: Boolean) { autoClearCache = b; persist() }
    fun setChannelsHistoryLimit(n: Int) { channelsHistoryLimit = n; persist() }
    fun setLanguage(v: String) { language = v; persist() }
    fun setAspectMode(n: Int) { aspectMode = n; persist() }
    fun liveExtension(): String = if (streamFormat == "hls") "m3u8" else "ts"

    fun logout() { profiles.clear(); currentIndex = 0; prefs.edit().clear().apply() }
}
