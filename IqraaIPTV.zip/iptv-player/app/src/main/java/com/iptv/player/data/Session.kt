package com.iptv.player.data

import android.content.Context

class Session(context: Context) {
    private val prefs = context.getSharedPreferences("iqraa_iptv", Context.MODE_PRIVATE)

    var account: Account? = load()
        private set

    private fun load(): Account? {
        val type = prefs.getString("type", null) ?: return null
        return Account(
            type = AccountType.valueOf(type),
            server = prefs.getString("server", "") ?: "",
            username = prefs.getString("user", "") ?: "",
            password = prefs.getString("pass", "") ?: "",
            m3uUrl = prefs.getString("m3u", "") ?: "",
            name = prefs.getString("name", "User") ?: "User"
        )
    }

    fun save(a: Account) {
        prefs.edit()
            .putString("type", a.type.name)
            .putString("server", a.server)
            .putString("user", a.username)
            .putString("pass", a.password)
            .putString("m3u", a.m3uUrl)
            .putString("name", a.name)
            .apply()
        account = a
    }

    fun logout() {
        prefs.edit().clear().apply()
        account = null
    }
}
