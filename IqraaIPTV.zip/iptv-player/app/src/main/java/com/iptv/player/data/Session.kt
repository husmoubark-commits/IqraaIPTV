package com.iptv.player.data

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.io.File

class Session(context: Context) {
    private val prefs = context.getSharedPreferences("iqraa_iptv", Context.MODE_PRIVATE)
    private val gson = Gson()
    val contentCacheDir: File = File(context.filesDir, "content_cache")

    val profiles: MutableList<Account> = loadProfiles()
    var currentIndex: Int = prefs.getInt("current", 0); private set
    var displayMode: String = prefs.getString("mode", "auto") ?: "auto"; private set  // auto|phone|tv
    var autoPlayNext: Boolean = prefs.getBoolean("autoplay", true); private set
    var refreshInterval: Int = prefs.getInt("refresh", 0); private set               // minutes, 0=off
    var lastRefresh: Long = prefs.getLong("lastRefresh", 0L); private set
    var streamFormat: String = prefs.getString("streamFmt", "hls") ?: "hls"; private set   // default|mpegts|hls
    var useExternalPlayer: Boolean = prefs.getBoolean("extPlayer", false); private set
    var timeFormat: String = prefs.getString("timeFmt", "12") ?: "12"; private set        // 12|24
    var activeSubtitle: Boolean = prefs.getBoolean("activeSub", true); private set         // default subtitles on
    var showEpg: Boolean = prefs.getBoolean("showEpg", true); private set                   // show EPG in live
    var autoClearCache: Boolean = prefs.getBoolean("autoClear", false); private set         // clear cache on start
    var channelsHistoryLimit: Int = prefs.getInt("histLimit", 10); private set              // continue-watching live count
    var language: String = prefs.getString("lang", "ar") ?: "ar"; private set            // ar|en
    var aspectMode: Int = prefs.getInt("aspectMode", 0); private set                       // 0=fit 1=zoom 2=fill
    var liveUpdatedAt: Long = prefs.getLong("upLive", 0L); private set
    var vodUpdatedAt: Long = prefs.getLong("upVod", 0L); private set
    var seriesUpdatedAt: Long = prefs.getLong("upSeries", 0L); private set
    var liveCat: String = prefs.getString("catLive", "__all__") ?: "__all__"; private set
    var vodCat: String = prefs.getString("catVod", "__all__") ?: "__all__"; private set
    var seriesCat: String = prefs.getString("catSeries", "__all__") ?: "__all__"; private set
    var matchLang: String = prefs.getString("matchLang", "auto") ?: "auto"; private set   // auto|ar|en

    // Last selected season for each series. The key includes the account so
    // two profiles with overlapping series IDs do not overwrite each other.
    private var seriesSeasons: MutableMap<String, Int> = loadSeriesSeasons()

    val account: Account? get() = profiles.getOrNull(currentIndex)

    private fun loadProfiles(): MutableList<Account> {
        val json = prefs.getString("profiles", null)
        if (json != null) {
            return runCatching {
                gson.fromJson<MutableList<Account>>(json, object : TypeToken<MutableList<Account>>() {}.type)
            }.getOrNull() ?: mutableListOf()
        }
        val type = prefs.getString("type", null)
        if (type != null) {
            return mutableListOf(
                Account(
                    AccountType.valueOf(type),
                    prefs.getString("server", "") ?: "",
                    prefs.getString("user", "") ?: "",
                    prefs.getString("pass", "") ?: "",
                    prefs.getString("m3u", "") ?: "",
                    prefs.getString("name", "User") ?: "User"
                )
            )
        }
        return mutableListOf()
    }

    private fun loadSeriesSeasons(): MutableMap<String, Int> {
        val json = prefs.getString("seriesSeasons", null) ?: return mutableMapOf()
        return runCatching {
            gson.fromJson<MutableMap<String, Int>>(json, object : TypeToken<MutableMap<String, Int>>() {}.type)
        }.getOrNull() ?: mutableMapOf()
    }

    private fun seriesSeasonKey(seriesId: String): String {
        val a = account
        val accountKey = if (a == null) {
            "default"
        } else {
            // Do not store the password in the preference key.
            "${a.type}|${a.server.trimEnd('/')}|${a.username}|${a.m3uUrl}"
        }
        return "$accountKey|$seriesId"
    }

    private fun persist() {
        prefs.edit()
            .putString("profiles", gson.toJson(profiles))
            .putInt("current", currentIndex)
            .putString("mode", displayMode)
            .putBoolean("autoplay", autoPlayNext)
            .putInt("refresh", refreshInterval)
            .putLong("lastRefresh", lastRefresh)
            .putString("streamFmt", streamFormat)
            .putBoolean("extPlayer", useExternalPlayer)
            .putString("timeFmt", timeFormat)
            .putBoolean("activeSub", activeSubtitle)
            .putBoolean("showEpg", showEpg)
            .putBoolean("autoClear", autoClearCache)
            .putInt("histLimit", channelsHistoryLimit)
            .putLong("upLive", liveUpdatedAt)
            .putLong("upVod", vodUpdatedAt)
            .putLong("upSeries", seriesUpdatedAt)
            .putString("catLive", liveCat)
            .putString("catVod", vodCat)
            .putString("catSeries", seriesCat)
            .putString("matchLang", matchLang)
            .putString("lang", language)
            .putInt("aspectMode", aspectMode)
            .putString("seriesSeasons", gson.toJson(seriesSeasons))
            .apply()
    }

    fun addProfile(a: Account) { profiles.add(a); currentIndex = profiles.lastIndex; persist() }
    fun updateProfile(index: Int, a: Account) { if (index in profiles.indices) { profiles[index] = a; persist() } }
    fun switchTo(index: Int) { if (index in profiles.indices) { currentIndex = index; persist() } }
    fun deleteProfile(index: Int) {
        if (index in profiles.indices) {
            profiles.removeAt(index)
            if (currentIndex >= profiles.size) currentIndex = (profiles.size - 1).coerceAtLeast(0)
            persist()
        }
    }
    fun setMode(m: String) { displayMode = m; persist() }
    fun setAutoPlay(b: Boolean) { autoPlayNext = b; persist() }
    fun setRefreshInterval(m: Int) { refreshInterval = m; persist() }
    fun markRefreshed() { lastRefresh = System.currentTimeMillis(); persist() }
    fun markSection(section: String) {
        val t = System.currentTimeMillis()
        when (section) { "live" -> liveUpdatedAt = t; "vod" -> vodUpdatedAt = t; "series" -> seriesUpdatedAt = t }
        persist()
    }
    fun sectionTime(section: String): Long = when (section) {
        "live" -> liveUpdatedAt; "vod" -> vodUpdatedAt; "series" -> seriesUpdatedAt; else -> 0L
    }
    fun setCat(section: String, cat: String) {
        when (section) { "live" -> liveCat = cat; "vod" -> vodCat = cat; "series" -> seriesCat = cat }
        persist()
    }
    fun lastCat(section: String): String = when (section) {
        "live" -> liveCat; "vod" -> vodCat; "series" -> seriesCat; else -> "__all__"
    }
    fun lastSeriesSeason(seriesId: String): Int? = seriesSeasons[seriesSeasonKey(seriesId)]
    fun setSeriesSeason(seriesId: String, season: Int) {
        seriesSeasons[seriesSeasonKey(seriesId)] = season
        persist()
    }
    fun setMatchLang(v: String) { matchLang = v; persist() }
    fun setStreamFormat(v: String) { streamFormat = v; persist() }
    fun setExternalPlayer(b: Boolean) { useExternalPlayer = b; persist() }
    fun setTimeFormat(v: String) { timeFormat = v; persist() }
    fun setActiveSubtitle(b: Boolean) { activeSubtitle = b; persist() }
    fun setShowEpg(b: Boolean) { showEpg = b; persist() }
    fun setAutoClearCache(b: Boolean) { autoClearCache = b; persist() }
    fun setChannelsHistoryLimit(n: Int) { channelsHistoryLimit = n; persist() }
    fun setLanguage(v: String) { language = v; persist() }
    fun setAspectMode(n: Int) { aspectMode = n; persist() }
    fun liveExtension(): String = if (streamFormat == "hls") "m3u8" else "ts"

    fun logout() {
        profiles.clear()
        seriesSeasons.clear()
        currentIndex = 0
        prefs.edit().clear().apply()
    }
}
