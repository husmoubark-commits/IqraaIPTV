package com.iptv.player.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.iptv.player.data.Graph
import com.iptv.player.ui.AppMode
import com.iptv.player.ui.theme.*

@Composable
fun SettingsScreen(nav: NavHostController) {
    val s = Graph.session
    var mode by remember { mutableStateOf(s.displayMode) }
    var refresh by remember { mutableStateOf(s.autoRefreshMinutes) }
    var autoplay by remember { mutableStateOf(s.autoplayNext) }

    Column(Modifier.fillMaxSize().background(Bg)) {
        TopBar(nav, "الإعدادات")
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)) {

            SectionTitle("وضع الجهاز")
            Row {
                OptChip("تلقائي", mode == "auto") { mode = "auto"; s.setMode("auto"); AppMode.isTv = isTvAuto() }
                OptChip("تلفون", mode == "phone") { mode = "phone"; s.setMode("phone"); AppMode.isTv = false }
                OptChip("TV", mode == "tv") { mode = "tv"; s.setMode("tv"); AppMode.isTv = true }
            }

            Spacer(Modifier.height(20.dp))
            SectionTitle("التحديث التلقائي")
            Row {
                listOf(0, 15, 30, 60).forEach { m ->
                    OptChip(if (m == 0) "إيقاف" else "$m د", refresh == m) { refresh = m; s.setAutoRefresh(m) }
                }
            }

            Spacer(Modifier.height(20.dp))
            SectionTitle("تشغيل الحلقة التالية تلقائيًا")
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(
                    checked = autoplay,
                    onCheckedChange = { autoplay = it; s.setAutoplay(it) },
                    colors = SwitchDefaults.colors(checkedThumbColor = BrandBright, checkedTrackColor = BrandPrimary)
                )
                Spacer(Modifier.width(10.dp))
                Text(if (autoplay) "مفعّل" else "موقوف", color = Color.White)
            }

            Spacer(Modifier.height(28.dp))
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color(0xFF3A1530))
                    .clickable {
                        Graph.session.logout()
                        nav.navigate("login") { popUpTo(nav.graph.id) { inclusive = true } }
                    }.padding(16.dp),
                contentAlignment = Alignment.Center
            ) { Text("تسجيل الخروج", color = Color(0xFFFF8A8A)) }
        }
    }
}

private fun isTvAuto(): Boolean = AppMode.isTv

@Composable
private fun SectionTitle(t: String) {
    Text(t, color = Muted, fontSize = 13.sp, modifier = Modifier.padding(bottom = 10.dp))
}

@Composable
private fun OptChip(text: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.padding(end = 10.dp).clip(RoundedCornerShape(20.dp))
            .background(if (selected) BrandPrimary else Surface2)
            .clickable { onClick() }.tvFocusBorder(RoundedCornerShape(20.dp))
            .padding(horizontal = 18.dp, vertical = 10.dp)
    ) { Text(text, color = Color.White) }
}
