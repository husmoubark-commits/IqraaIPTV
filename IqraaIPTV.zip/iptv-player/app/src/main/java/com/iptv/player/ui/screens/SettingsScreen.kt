package com.iptv.player.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.iptv.player.data.Graph
import com.iptv.player.ui.theme.*

@Composable
fun SettingsScreen(nav: NavHostController) {
    val s = Graph.session
    var mode by remember { mutableStateOf(s.displayMode) }
    var fmt by remember { mutableStateOf(s.streamFormat) }
    var autoplay by remember { mutableStateOf(s.autoPlayNext) }
    var refresh by remember { mutableIntStateOf(s.refreshInterval) }
    var ext by remember { mutableStateOf(s.useExternalPlayer) }

    Column(Modifier.fillMaxSize().background(Bg)) {
        TopBar(nav, "الإعدادات")
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {

            SectionCard("صيغة البث للقنوات المباشرة", "اختر الصيغة المناسبة لسيرفرك. لو القنوات مش شغّالة جرّب غيّرها") {
                RadioRow("Default (MPEGTS)", fmt == "default") { fmt = "default"; s.setStreamFormat("default") }
                RadioRow("MPEGTS (.ts)", fmt == "mpegts") { fmt = "mpegts"; s.setStreamFormat("mpegts") }
                RadioRow("HLS (.m3u8)", fmt == "hls") { fmt = "hls"; s.setStreamFormat("hls") }
                Text("بعد التغيير ارجع وافتح القناة من جديد", color = Color(0x88FFFFFF), fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
            }

            SectionCard("وضع الجهاز", "اختر الوضع المناسب لأفضل أداء") {
                Row {
                    ChoiceChip("تلقائي", mode == "auto") { mode = "auto"; s.setMode("auto") }
                    Spacer(Modifier.width(8.dp))
                    ChoiceChip("موبايل", mode == "phone") { mode = "phone"; s.setMode("phone") }
                    Spacer(Modifier.width(8.dp))
                    ChoiceChip("تلفزيون", mode == "tv") { mode = "tv"; s.setMode("tv") }
                }
            }

            SectionCard("مشغّل خارجي", "تشغيل القنوات والأفلام عبر تطبيق خارجي مثل VLC أو MX Player") {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("استخدام مشغّل خارجي", color = Color.White, fontSize = 14.sp, modifier = Modifier.weight(1f))
                    Switch(checked = ext, onCheckedChange = { ext = it; s.setExternalPlayer(it) },
                        colors = SwitchDefaults.colors(checkedTrackColor = BrandPrimary, checkedThumbColor = Color.White))
                }
            }

            SectionCard("التشغيل التلقائي", null) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("تشغيل الحلقة التالية تلقائياً", color = Color.White, fontSize = 14.sp, modifier = Modifier.weight(1f))
                    Switch(checked = autoplay, onCheckedChange = { autoplay = it; s.setAutoPlay(it) },
                        colors = SwitchDefaults.colors(checkedTrackColor = BrandPrimary, checkedThumbColor = Color.White))
                }
            }

            SectionCard("التحديث التلقائي", "تحديث المحتوى تلقائياً كل فترة") {
                Row {
                    listOf(0 to "إيقاف", 15 to "15 د", 30 to "30 د", 60 to "60 د").forEach { (v, lbl) ->
                        ChoiceChip(lbl, refresh == v) { refresh = v; s.setRefreshInterval(v) }
                        Spacer(Modifier.width(8.dp))
                    }
                }
            }

            Spacer(Modifier.height(8.dp))
            Text("Iqraa IPTV • الإصدار 1.2", color = Muted, fontSize = 12.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
        }
    }
}

@Composable
private fun SectionCard(title: String, subtitle: String?, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().padding(bottom = 14.dp).clip(RoundedCornerShape(14.dp))
            .background(Surface1).padding(16.dp)
    ) {
        Text(title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        if (subtitle != null) Text(subtitle, color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp, bottom = 8.dp))
        else Spacer(Modifier.height(8.dp))
        content()
    }
}

@Composable
private fun RadioRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).clickable { onClick() }.padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = selected, onClick = onClick,
            colors = RadioButtonDefaults.colors(selectedColor = BrandBright, unselectedColor = Muted))
        Spacer(Modifier.width(6.dp))
        Text(label, color = Color.White, fontSize = 14.sp)
    }
}

@Composable
private fun ChoiceChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.clip(RoundedCornerShape(20.dp)).background(if (selected) BrandPrimary else Surface2)
            .clickable { onClick() }.tvFocusBorder(RoundedCornerShape(20.dp))
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) { Text(label, color = Color.White, fontSize = 13.sp) }
}
