package com.iptv.player.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.iptv.player.data.AccountInfo
import com.iptv.player.data.Graph
import com.iptv.player.ui.Refresh
import com.iptv.player.ui.theme.*

private data class SettingTile(val key: String, val title: String, val icon: ImageVector)

@Composable
fun SettingsScreen(nav: NavHostController) {
    val context = LocalContext.current
    var open by remember { mutableStateOf<String?>(null) }

    val tiles = listOf(
        SettingTile("stream", "صيغة البث", Icons.Filled.LiveTv),
        SettingTile("device", "وضع الجهاز", Icons.Filled.DevicesOther),
        SettingTile("player", "المشغّل", Icons.Filled.PlayCircle),
        SettingTile("external", "مشغّل خارجي", Icons.Filled.OpenInNew),
        SettingTile("autoplay", "التشغيل التلقائي", Icons.Filled.SkipNext),
        SettingTile("refresh", "التحديث التلقائي", Icons.Filled.Autorenew),
        SettingTile("time", "تنسيق الوقت", Icons.Filled.Schedule),
        SettingTile("account", "معلومات الحساب", Icons.Filled.AccountCircle),
        SettingTile("profiles", "الملفات الشخصية", Icons.Filled.ManageAccounts),
        SettingTile("cache", "مسح الذاكرة المؤقتة", Icons.Filled.DeleteSweep),
        SettingTile("about", "حول التطبيق", Icons.Filled.Info)
    )

    Column(Modifier.fillMaxSize().background(Bg)) {
        TopBar(nav, "الإعدادات")
        LazyVerticalGrid(
            columns = GridCells.Adaptive(168.dp),
            contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(tiles) { t ->
                Column(
                    Modifier.height(120.dp).clip(RoundedCornerShape(16.dp))
                        .background(Brush.verticalGradient(listOf(Surface2, Surface1)))
                        .clickable {
                            when (t.key) {
                                "profiles" -> nav.navigate("profiles")
                                else -> open = t.key
                            }
                        }
                        .tvFocusBorder(RoundedCornerShape(16.dp)).padding(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)).background(BrandPrimary), contentAlignment = Alignment.Center) {
                        Icon(t.icon, null, tint = Color.White, modifier = Modifier.size(26.dp))
                    }
                    Spacer(Modifier.height(10.dp))
                    Text(t.title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center, maxLines = 2)
                }
            }
        }
    }

    when (open) {
        "stream" -> StreamDialog { open = null }
        "device" -> DeviceDialog { open = null }
        "player" -> PlayerDialog { open = null }
        "external" -> ExternalDialog { open = null }
        "autoplay" -> AutoplayDialog { open = null }
        "refresh" -> RefreshDialog { open = null }
        "time" -> TimeDialog { open = null }
        "account" -> AccountDialog { open = null }
        "cache" -> CacheDialog(context) { open = null }
        "about" -> AboutDialog { open = null }
    }
}

@Composable
private fun Dlg(title: String, onClose: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    AlertDialog(
        onDismissRequest = onClose,
        confirmButton = { TextButton(onClick = onClose) { Text("تم", color = BrandBright) } },
        title = { Text(title, color = Color.White, fontWeight = FontWeight.Bold) },
        text = { Column(content = content) },
        containerColor = Surface1
    )
}

@Composable
private fun RadioRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).clickable { onClick() }.padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically) {
        RadioButton(selected = selected, onClick = onClick,
            colors = RadioButtonDefaults.colors(selectedColor = BrandBright, unselectedColor = Muted))
        Spacer(Modifier.width(4.dp)); Text(label, color = Color.White, fontSize = 14.sp)
    }
}

@Composable
private fun StreamDialog(onClose: () -> Unit) {
    val s = Graph.session
    var v by remember { mutableStateOf(s.streamFormat) }
    Dlg("صيغة البث للقنوات المباشرة", onClose) {
        Text("لو القنوات مش شغّالة جرّب صيغة تانية", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(bottom = 6.dp))
        RadioRow("Default (MPEGTS)", v == "default") { v = "default"; s.setStreamFormat("default") }
        RadioRow("MPEGTS (.ts)", v == "mpegts") { v = "mpegts"; s.setStreamFormat("mpegts") }
        RadioRow("HLS (.m3u8)", v == "hls") { v = "hls"; s.setStreamFormat("hls") }
        Text("ارجع وافتح القناة من جديد بعد التغيير", color = Color(0x88FFFFFF), fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
    }
}

@Composable
private fun DeviceDialog(onClose: () -> Unit) {
    val s = Graph.session
    var v by remember { mutableStateOf(s.displayMode) }
    Dlg("وضع الجهاز", onClose) {
        RadioRow("تلقائي", v == "auto") { v = "auto"; s.setMode("auto") }
        RadioRow("موبايل", v == "phone") { v = "phone"; s.setMode("phone") }
        RadioRow("تلفزيون", v == "tv") { v = "tv"; s.setMode("tv") }
        Text("يفضّل إعادة فتح التطبيق بعد التغيير", color = Color(0x88FFFFFF), fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
    }
}

@Composable
private fun PlayerDialog(onClose: () -> Unit) {
    val s = Graph.session
    var ext by remember { mutableStateOf(s.useExternalPlayer) }
    var auto by remember { mutableStateOf(s.autoPlayNext) }
    Dlg("إعدادات المشغّل", onClose) {
        SwitchRow("مشغّل خارجي (VLC / MX)", ext) { ext = it; s.setExternalPlayer(it) }
        SwitchRow("تشغيل الحلقة التالية تلقائياً", auto) { auto = it; s.setAutoPlay(it) }
    }
}

@Composable
private fun ExternalDialog(onClose: () -> Unit) {
    val s = Graph.session
    var ext by remember { mutableStateOf(s.useExternalPlayer) }
    Dlg("المشغّل الخارجي", onClose) {
        Text("عند التفعيل، القنوات والأفلام تفتح في تطبيق خارجي مثل VLC أو MX Player", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(bottom = 8.dp))
        SwitchRow("استخدام مشغّل خارجي", ext) { ext = it; s.setExternalPlayer(it) }
    }
}

@Composable
private fun AutoplayDialog(onClose: () -> Unit) {
    val s = Graph.session
    var auto by remember { mutableStateOf(s.autoPlayNext) }
    Dlg("التشغيل التلقائي", onClose) {
        SwitchRow("تشغيل الحلقة التالية تلقائياً", auto) { auto = it; s.setAutoPlay(it) }
    }
}

@Composable
private fun RefreshDialog(onClose: () -> Unit) {
    val s = Graph.session
    var v by remember { mutableIntStateOf(s.refreshInterval) }
    Dlg("التحديث التلقائي للمحتوى", onClose) {
        Column(Modifier.verticalScroll(rememberScrollState())) {
            RadioRow("إيقاف", v == 0) { v = 0; s.setRefreshInterval(0) }
            RadioRow("كل 15 دقيقة", v == 15) { v = 15; s.setRefreshInterval(15) }
            RadioRow("كل 30 دقيقة", v == 30) { v = 30; s.setRefreshInterval(30) }
            RadioRow("كل 60 دقيقة", v == 60) { v = 60; s.setRefreshInterval(60) }
            RadioRow("كل 12 ساعة", v == 720) { v = 720; s.setRefreshInterval(720) }
            RadioRow("كل 24 ساعة", v == 1440) { v = 1440; s.setRefreshInterval(1440) }
            RadioRow("كل 48 ساعة", v == 2880) { v = 2880; s.setRefreshInterval(2880) }
        }
    }
}

@Composable
private fun TimeDialog(onClose: () -> Unit) {
    val s = Graph.session
    var v by remember { mutableStateOf(s.timeFormat) }
    Dlg("تنسيق الوقت", onClose) {
        RadioRow("12 ساعة (AM/PM)", v == "12") { v = "12"; s.setTimeFormat("12") }
        RadioRow("24 ساعة", v == "24") { v = "24"; s.setTimeFormat("24") }
    }
}

@Composable
private fun AccountDialog(onClose: () -> Unit) {
    var info by remember { mutableStateOf<AccountInfo?>(null) }
    var loading by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) { info = runCatching { Graph.repo.accountInfo() }.getOrNull(); loading = false }
    Dlg("معلومات الحساب", onClose) {
        when {
            loading -> Text("جارٍ التحميل...", color = Muted, fontSize = 13.sp)
            info == null -> Text("غير متاح لهذا النوع من الاشتراك (M3U) أو تعذّر الاتصال", color = Muted, fontSize = 13.sp)
            else -> {
                InfoRow("الاسم", Graph.session.account?.name ?: "-")
                InfoRow("الحالة", if (info!!.status.equals("Active", true)) "نشط" else info!!.status)
                InfoRow("تاريخ الانتهاء", info!!.expiry)
                InfoRow("الاتصالات", "${info!!.activeCons} / ${info!!.maxCons}")
                InfoRow("تجريبي", if (info!!.trial) "نعم" else "لا")
            }
        }
    }
}

@Composable
private fun CacheDialog(context: android.content.Context, onClose: () -> Unit) {
    Dlg("مسح الذاكرة المؤقتة", onClose) {
        Text("سيتم إعادة تحميل القنوات والأفلام والمسلسلات من جديد", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(bottom = 10.dp))
        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(BrandPrimary)
            .clickable {
                Graph.repo.clearCache(); Refresh.tick++
                Toast.makeText(context, "تم مسح الذاكرة", Toast.LENGTH_SHORT).show(); onClose()
            }.padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
            Text("مسح الآن", color = Color.White, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun AboutDialog(onClose: () -> Unit) {
    Dlg("حول التطبيق", onClose) {
        Text("Iqraa IPTV", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Spacer(Modifier.height(4.dp))
        Text("الإصدار 1.7", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(8.dp))
        Text("مشغّل IPTV يدعم Xtream Codes و M3U — قنوات مباشرة، أفلام، مسلسلات.", color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, fontSize = 14.sp, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedTrackColor = BrandPrimary, checkedThumbColor = Color.White))
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
        Text(label, color = Muted, fontSize = 13.sp, modifier = Modifier.weight(1f))
        Text(value, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}
