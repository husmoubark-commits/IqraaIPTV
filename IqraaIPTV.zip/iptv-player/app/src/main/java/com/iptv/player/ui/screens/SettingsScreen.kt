package com.iptv.player.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.iptv.player.data.AccountInfo
import com.iptv.player.data.Graph
import com.iptv.player.ui.Refresh
import com.iptv.player.ui.theme.*

private data class SettingTile(val key: String, val title: String, val icon: ImageVector)

@Composable
fun SettingsScreen(nav: NavHostController) {
    val context = LocalContext.current
    var open by remember { mutableStateOf<String?>(null) }

    val tiles = listOf(
        SettingTile("general", tr("إعدادات عامة"), Icons.Filled.Tune),
        SettingTile("stream", tr("صيغة البث"), Icons.Filled.LiveTv),
        SettingTile("device", tr("وضع الجهاز"), Icons.Filled.DevicesOther),
        SettingTile("player", tr("المشغّل"), Icons.Filled.PlayCircle),
        SettingTile("external", tr("مشغّل خارجي"), Icons.Filled.OpenInNew),
        SettingTile("autoplay", tr("التشغيل التلقائي"), Icons.Filled.SkipNext),
        SettingTile("refresh", tr("التحديث التلقائي"), Icons.Filled.Autorenew),
        SettingTile("time", tr("تنسيق الوقت"), Icons.Filled.Schedule),
        SettingTile("account", tr("معلومات الحساب"), Icons.Filled.AccountCircle),
        SettingTile("profiles", tr("الملفات الشخصية"), Icons.Filled.ManageAccounts),
        SettingTile("cache", tr("مسح الذاكرة المؤقتة"), Icons.Filled.DeleteSweep),
        SettingTile("about", tr("حول التطبيق"), Icons.Filled.Info)
    )

    Column(Modifier.fillMaxSize().background(Bg)) {
        TopBar(nav, tr("الإعدادات"))
        LazyVerticalGrid(
            columns = GridCells.Adaptive(168.dp),
            contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(tiles) { t ->
                Box(
                    Modifier.fillMaxWidth().height(120.dp)
                        .tvFocusBorder(RoundedCornerShape(16.dp))
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) {
                            when (t.key) {
                                "profiles" -> nav.navigate("profiles")
                                else -> open = t.key
                            }
                        }
                ) {
                    Column(
                        Modifier.fillMaxSize().clip(RoundedCornerShape(16.dp))
                            .background(Brush.verticalGradient(listOf(Surface2, Surface1)))
                            .padding(12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Box(Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)).background(BrandPrimary), contentAlignment = Alignment.Center) {
                            Icon(t.icon, null, tint = Color.White, modifier = Modifier.size(26.dp))
                        }
                        Spacer(Modifier.height(10.dp))
                        Text(t.title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center, maxLines = 2)
                    }
                }
            }
        }
    }

    when (open) {
        "general" -> GeneralDialog(context) { open = null }
        "stream" -> StreamDialog { open = null }
        "device" -> DeviceDialog { open = null }
        "player" -> PlayerDialog { open = null }
        "external" -> ExternalDialog { open = null }
        "autoplay" -> AutoplayDialog { open = null }
        "refresh" -> RefreshDialog { open = null }
        "time" -> TimeDialog { open = null }
        "account" -> AccountDialog { open = null }
        "cache" -> CacheDialog(context) { open = null }
        "about" -> AboutDialog { open = null }
    }
}

@Composable
private fun Dlg(title: String, onClose: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    AlertDialog(
        onDismissRequest = onClose,
        confirmButton = { TextButton(onClick = onClose) { Text(tr("تم"), color = BrandBright) } },
        title = { Text(title, color = Color.White, fontWeight = FontWeight.Bold) },
        text = { Column(content = content) },
        containerColor = Surface1
    )
}

@Composable
private fun RadioRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).clickable { onClick() }.padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically) {
        RadioButton(selected = selected, onClick = onClick,
            colors = RadioButtonDefaults.colors(selectedColor = BrandBright, unselectedColor = Muted))
        Spacer(Modifier.width(4.dp)); Text(label, color = Color.White, fontSize = 14.sp)
    }
}

@Composable
private fun StreamDialog(onClose: () -> Unit) {
    val s = Graph.session
    var v by remember { mutableStateOf(s.streamFormat) }
    Dlg(tr("صيغة البث للقنوات المباشرة"), onClose) {
        Text(tr("لو القنوات مش شغّالة جرّب صيغة تانية"), color = Muted, fontSize = 12.sp, modifier = Modifier.padding(bottom = 6.dp))
        RadioRow("Default (MPEGTS)", v == "default") { v = "default"; s.setStreamFormat("default") }
        RadioRow("MPEGTS (.ts)", v == "mpegts") { v = "mpegts"; s.setStreamFormat("mpegts") }
        RadioRow("HLS (.m3u8)", v == "hls") { v = "hls"; s.setStreamFormat("hls") }
        Text(tr("ارجع وافتح القناة من جديد بعد التغيير"), color = Color(0x88FFFFFF), fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
    }
}

@Composable
private fun DeviceDialog(onClose: () -> Unit) {
    val s = Graph.session
    var v by remember { mutableStateOf(s.displayMode) }
    Dlg(tr("وضع الجهاز"), onClose) {
        RadioRow(tr("تلقائي"), v == "auto") { v = "auto"; s.setMode("auto") }
        RadioRow(tr("موبايل"), v == "phone") { v = "phone"; s.setMode("phone") }
        RadioRow(tr("تلفزيون"), v == "tv") { v = "tv"; s.setMode("tv") }
        Text(tr("يفضّل إعادة فتح التطبيق بعد التغيير"), color = Color(0x88FFFFFF), fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
    }
}

@Composable
private fun PlayerDialog(onClose: () -> Unit) {
    val s = Graph.session
    var ext by remember { mutableStateOf(s.useExternalPlayer) }
    var auto by remember { mutableStateOf(s.autoPlayNext) }
    Dlg(tr("إعدادات المشغّل"), onClose) {
        SwitchRow(tr("مشغّل خارجي (VLC / MX)"), ext) { ext = it; s.setExternalPlayer(it) }
        SwitchRow(tr("تشغيل الحلقة التالية تلقائياً"), auto) { auto = it; s.setAutoPlay(it) }
    }
}

@Composable
private fun ExternalDialog(onClose: () -> Unit) {
    val s = Graph.session
    var ext by remember { mutableStateOf(s.useExternalPlayer) }
    Dlg(tr("المشغّل الخارجي"), onClose) {
        Text(tr("عند التفعيل، القنوات والأفلام تفتح في تطبيق خارجي مثل VLC أو MX Player"), color = Muted, fontSize = 12.sp, modifier = Modifier.padding(bottom = 8.dp))
        SwitchRow(tr("استخدام مشغّل خارجي"), ext) { ext = it; s.setExternalPlayer(it) }
    }
}

@Composable
private fun AutoplayDialog(onClose: () -> Unit) {
    val s = Graph.session
    var auto by remember { mutableStateOf(s.autoPlayNext) }
    Dlg(tr("التشغيل التلقائي"), onClose) {
        SwitchRow(tr("تشغيل الحلقة التالية تلقائياً"), auto) { auto = it; s.setAutoPlay(it) }
    }
}

@Composable
private fun RefreshDialog(onClose: () -> Unit) {
    val s = Graph.session
    var v by remember { mutableIntStateOf(s.refreshInterval) }
    Dlg(tr("التحديث التلقائي للمحتوى"), onClose) {
        Column(Modifier.verticalScroll(rememberScrollState())) {
            RadioRow(tr("إيقاف"), v == 0) { v = 0; s.setRefreshInterval(0) }
            RadioRow(tr("كل 15 دقيقة"), v == 15) { v = 15; s.setRefreshInterval(15) }
            RadioRow(tr("كل 30 دقيقة"), v == 30) { v = 30; s.setRefreshInterval(30) }
            RadioRow(tr("كل 60 دقيقة"), v == 60) { v = 60; s.setRefreshInterval(60) }
            RadioRow(tr("كل 12 ساعة"), v == 720) { v = 720; s.setRefreshInterval(720) }
            RadioRow(tr("كل 24 ساعة"), v == 1440) { v = 1440; s.setRefreshInterval(1440) }
            RadioRow(tr("كل 48 ساعة"), v == 2880) { v = 2880; s.setRefreshInterval(2880) }
        }
    }
}

@Composable
private fun TimeDialog(onClose: () -> Unit) {
    val s = Graph.session
    var v by remember { mutableStateOf(s.timeFormat) }
    Dlg(tr("تنسيق الوقت"), onClose) {
        RadioRow(tr("12 ساعة (AM/PM)"), v == "12") { v = "12"; s.setTimeFormat("12") }
        RadioRow(tr("24 ساعة"), v == "24") { v = "24"; s.setTimeFormat("24") }
    }
}

@Composable
private fun AccountDialog(onClose: () -> Unit) {
    var info by remember { mutableStateOf<AccountInfo?>(null) }
    var loading by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) { info = runCatching { Graph.repo.accountInfo() }.getOrNull(); loading = false }
    Dlg(tr("معلومات الحساب"), onClose) {
        when {
            loading -> Text(tr("جارٍ التحميل..."), color = Muted, fontSize = 13.sp)
            info == null -> Text(tr("غير متاح لهذا النوع من الاشتراك (M3U) أو تعذّر الاتصال"), color = Muted, fontSize = 13.sp)
            else -> {
                InfoRow(tr("الاسم"), Graph.session.account?.name ?: "-")
                InfoRow(tr("الحالة"), if (info!!.status.equals("Active", true)) tr("نشط") else info!!.status)
                InfoRow(tr("تاريخ الانتهاء"), tr(info!!.expiry))
                InfoRow(tr("الاتصالات"), "${info!!.activeCons} / ${info!!.maxCons}")
                InfoRow(tr("تجريبي"), if (info!!.trial) tr("نعم") else tr("لا"))
            }
        }
    }
}

@Composable
private fun CacheDialog(context: android.content.Context, onClose: () -> Unit) {
    Dlg(tr("مسح الذاكرة المؤقتة"), onClose) {
        Text(tr("سيتم إعادة تحميل القنوات والأفلام والمسلسلات من جديد"), color = Muted, fontSize = 12.sp, modifier = Modifier.padding(bottom = 10.dp))
        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(BrandPrimary)
            .clickable {
                Graph.repo.clearCache(); Refresh.tick++
                Toast.makeText(context, tr("تم مسح الذاكرة"), Toast.LENGTH_SHORT).show(); onClose()
            }.padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
            Text(tr("مسح الآن"), color = Color.White, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun GeneralDialog(context: android.content.Context, onClose: () -> Unit) {
    val s = Graph.session
    var sub by remember { mutableStateOf(s.activeSubtitle) }
    var epg by remember { mutableStateOf(s.showEpg) }
    var clear by remember { mutableStateOf(s.autoClearCache) }
    var auto by remember { mutableStateOf(s.autoPlayNext) }
    var hist by remember { mutableStateOf(s.channelsHistoryLimit) }
    var lang by remember { mutableStateOf(s.language) }
    Dlg(tr("إعدادات عامة"), onClose) {
        Column(Modifier.verticalScroll(rememberScrollState())) {
            Text(tr("اللغة"), color = Color.White, fontSize = 14.sp,
                fontWeight = FontWeight.Medium, modifier = Modifier.padding(bottom = 4.dp))
            RadioRow("English", lang == "en") {
                if (lang != "en") { lang = "en"; s.setLanguage("en"); (context as? android.app.Activity)?.recreate() }
            }
            RadioRow("العربية", lang == "ar") {
                if (lang != "ar") { lang = "ar"; s.setLanguage("ar"); (context as? android.app.Activity)?.recreate() }
            }
            Divider(color = Surface2, modifier = Modifier.padding(vertical = 8.dp))
            SwitchRow(tr("تفعيل الترجمة افتراضياً"), sub) { sub = it; s.setActiveSubtitle(it) }
            SwitchRow(tr("عرض الدليل (EPG) في المباشر"), epg) { epg = it; s.setShowEpg(it) }
            SwitchRow(tr("تشغيل الحلقة التالية تلقائياً"), auto) { auto = it; s.setAutoPlay(it) }
            Spacer(Modifier.height(4.dp))
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(tr("مسح الذاكرة تلقائياً عند الفتح"), color = Color.White, fontSize = 14.sp, modifier = Modifier.weight(1f))
                Switch(checked = clear, onCheckedChange = { clear = it; s.setAutoClearCache(it) },
                    colors = SwitchDefaults.colors(checkedTrackColor = BrandPrimary, checkedThumbColor = Color.White))
            }
            Row(Modifier.fillMaxWidth().padding(top = 2.dp, bottom = 8.dp)) {
                Spacer(Modifier.weight(1f))
                TextButton(onClick = {
                    Graph.repo.clearCache(); Refresh.tick++
                    Toast.makeText(context, tr("تم مسح الذاكرة"), Toast.LENGTH_SHORT).show()
                }) { Text(tr("مسح الآن"), color = BrandPrimary, fontWeight = FontWeight.Bold) }
            }
            Divider(color = Surface2)
            Text(tr("حد سجل القنوات (المتابعة)"), color = Color.White, fontSize = 14.sp,
                fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 8.dp, bottom = 4.dp))
            listOf(5, 10, 20, 50).forEach { n ->
                RadioRow("$n ${tr("قناة")}", hist == n) { hist = n; s.setChannelsHistoryLimit(n) }
            }
        }
    }
}

@Composable
private fun AboutDialog(onClose: () -> Unit) {
    Dlg(tr("حول التطبيق"), onClose) {
        Text("Voltix IPTV Player", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Spacer(Modifier.height(4.dp))
        Text(tr("الإصدار 3.1"), color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(8.dp))
        Text(tr("مشغّل IPTV يدعم Xtream Codes و M3U — قنوات مباشرة، أفلام، مسلسلات."), color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, fontSize = 14.sp, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedTrackColor = BrandPrimary, checkedThumbColor = Color.White))
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
        Text(label, color = Muted, fontSize = 13.sp, modifier = Modifier.weight(1f))
        Text(value, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}
