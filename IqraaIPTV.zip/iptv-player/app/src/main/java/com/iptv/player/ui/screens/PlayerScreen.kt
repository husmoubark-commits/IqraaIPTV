package com.iptv.player.ui.screens

import android.content.Intent
import android.net.Uri
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.ClosedCaption
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Forward10
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import androidx.navigation.NavHostController
import com.iptv.player.data.Graph
import com.iptv.player.data.PlayerFactory
import com.iptv.player.data.ResumeEntity
import com.iptv.player.ui.PlayInfo
import com.iptv.player.ui.Selection
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(nav: NavHostController) {
    val context = LocalContext.current
    val dao = Graph.db.dao()
    val scope = rememberCoroutineScope()
    val playlist = remember { Selection.playlist.ifEmpty { listOf(Selection.play) } }
    val indexState = remember { mutableIntStateOf(Selection.index.coerceIn(0, playlist.lastIndex)) }
    val index = indexState.intValue
    val info: PlayInfo = playlist[index]

    val external = remember { Graph.session.useExternalPlayer }
    if (external) {
        LaunchedEffect(Unit) {
            runCatching {
                val i = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(Uri.parse(info.url), "video/*"); addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(Intent.createChooser(i, tr("تشغيل عبر")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
            nav.popBackStack()
        }
        Box(Modifier.fillMaxSize().background(Color.Black)); return
    }

    val resizeModes = remember {
        listOf(
            AspectRatioFrameLayout.RESIZE_MODE_FIT,
            AspectRatioFrameLayout.RESIZE_MODE_ZOOM,
            AspectRatioFrameLayout.RESIZE_MODE_FILL
        )
    }
    var resizeIdx by remember { mutableIntStateOf(Graph.session.aspectMode.coerceIn(0, 2)) }
    val speeds = remember { listOf(0.5f, 1f, 1.25f, 1.5f, 2f) }
    var speedIdx by remember { mutableIntStateOf(1) }
    var subsOn by remember { mutableStateOf(Graph.session.activeSubtitle) }

    var controlsVisible by remember { mutableStateOf(true) }
    var interaction by remember { mutableIntStateOf(0) }
    var isPlaying by remember { mutableStateOf(true) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var dragging by remember { mutableStateOf(false) }
    var dragPos by remember { mutableFloatStateOf(0f) }

    val player = remember { PlayerFactory.build(context) }
    val isLive = info.type == "live"

    val rootFocus = remember { FocusRequester() }
    val playFocus = remember { FocusRequester() }

    LaunchedEffect(index) {
        val cur = playlist[index]
        player.setMediaItem(MediaItem.fromUri(cur.url))
        player.prepare(); player.playWhenReady = true
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, !subsOn).build()
        if (cur.type != "live" && cur.itemId.isNotBlank()) {
            val pos = runCatching { dao.resumePos(cur.type, cur.itemId) }.getOrNull() ?: 0L
            if (pos > 3000) player.seekTo(pos)
        }
        if (cur.type == "live" && cur.itemId.isNotBlank()) {
            runCatching {
                dao.saveResume(ResumeEntity("live", cur.itemId, cur.title, cur.logo, cur.url, 0L, 0L, System.currentTimeMillis()))
            }
        }
    }

    LaunchedEffect(Unit) {
        while (true) {
            if (!dragging) position = player.currentPosition.coerceAtLeast(0L)
            duration = player.duration.coerceAtLeast(0L)
            delay(500)
        }
    }

    LaunchedEffect(index) {
        val cur = playlist[index]
        if (cur.type != "live") while (true) {
            delay(10000)
            val p = player.currentPosition; val d = player.duration
            if (p > 0 && d > 0) runCatching {
                dao.saveResume(ResumeEntity(cur.type, cur.itemId, cur.title, cur.logo, cur.url, p, d, System.currentTimeMillis(), cur.seriesId))
            }
        }
    }

    LaunchedEffect(controlsVisible, interaction) {
        if (controlsVisible) { delay(5000); controlsVisible = false }
    }

    LaunchedEffect(controlsVisible) {
        delay(120)
        runCatching { if (controlsVisible) playFocus.requestFocus() else rootFocus.requestFocus() }
    }

    DisposableEffect(player) {
        val l = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) { isPlaying = playing }
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_ENDED && Graph.session.autoPlayNext &&
                    info.type == "series" && indexState.intValue < playlist.lastIndex
                ) indexState.intValue = indexState.intValue + 1
            }
        }
        player.addListener(l)
        onDispose { player.removeListener(l); player.release() }
    }

    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_PAUSE || e == Lifecycle.Event.ON_STOP) player.pause()
        }
        lifecycleOwner.lifecycle.addObserver(obs)
        onDispose { lifecycleOwner.lifecycle.removeObserver(obs) }
    }

    BackHandler { nav.popBackStack() }

    fun show() { controlsVisible = true; interaction++ }
    fun next() { if (index < playlist.lastIndex) indexState.intValue = index + 1; interaction++ }
    fun prev() { if (index > 0) indexState.intValue = index - 1; interaction++ }
    fun seekBy(ms: Long) { player.seekTo((player.currentPosition + ms).coerceAtLeast(0L)); position = player.currentPosition; show() }

    Box(
        Modifier.fillMaxSize().background(Color.Black)
            .focusRequester(rootFocus)
            .focusProperties { canFocus = !controlsVisible }
            .focusable()
            .onKeyEvent { e ->
                if (e.type == KeyEventType.KeyDown && e.key != Key.Back) {
                    if (!controlsVisible) { controlsVisible = true; true } else { interaction++; false }
                } else false
            }
    ) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                PlayerView(ctx).apply {
                    this.player = player
                    useController = false
                    keepScreenOn = true
                    resizeMode = resizeModes[resizeIdx]
                    layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                }
            },
            update = { it.resizeMode = resizeModes[resizeIdx] }
        )

        Box(Modifier.fillMaxSize().pointerInput(Unit) {
            detectTapGestures { controlsVisible = !controlsVisible }
        })

        // ===== center play moved to bottom-left bar =====

        // ===== TOP TITLE =====
        AnimatedVisibility(visible = controlsVisible, modifier = Modifier.align(Alignment.TopCenter)) {
            Row(
                Modifier.fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color(0xCC000000), Color.Transparent)))
                    .padding(horizontal = 12.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "back", tint = Color.White,
                    modifier = Modifier.clip(RoundedCornerShape(8.dp)).tvFocusBorder(RoundedCornerShape(8.dp))
                        .clickable { nav.popBackStack() }.padding(6.dp))
                Spacer(Modifier.width(10.dp))
                Text(info.title, color = Color.White, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }

        // ===== BOTTOM: seekbar + button row =====
        AnimatedVisibility(visible = controlsVisible, modifier = Modifier.align(Alignment.BottomCenter)) {
            Column(
                Modifier.fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xE6000000))))
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            ) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(52.dp).clip(CircleShape).background(Color(0x55000000))
                                .focusRequester(playFocus)
                                .onKeyEvent { e ->
                                    if (e.type == KeyEventType.KeyDown && !isLive) when (e.key) {
                                        Key.DirectionRight -> { seekBy(10000); true }
                                        Key.DirectionLeft -> { seekBy(-10000); true }
                                        else -> false
                                    } else false
                                }
                                .tvFocusBorder(CircleShape)
                                .clickable { if (isPlaying) player.pause() else player.play(); show() },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow, "playpause", tint = Color.White, modifier = Modifier.size(32.dp))
                        }
                        Spacer(Modifier.width(8.dp))
                        if (isLive || duration <= 0L) {
                            Text(tr("● مباشر"), color = Color(0xFFFF5252), fontSize = 13.sp)
                            Spacer(Modifier.weight(1f))
                        } else {
                            CircleCtrl(Icons.Filled.Replay10, 44.dp, 24.dp) { seekBy(-10000) }
                            Text(fmt(position), color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(start = 6.dp))
                            Slider(
                                value = (if (dragging) dragPos else position.toFloat()).coerceIn(0f, duration.toFloat()),
                                onValueChange = { dragging = true; dragPos = it; interaction++ },
                                onValueChangeFinished = { player.seekTo(dragPos.toLong()); position = dragPos.toLong(); dragging = false; interaction++ },
                                valueRange = 0f..duration.toFloat(),
                                colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = BrandBrightC, inactiveTrackColor = Color(0x55FFFFFF)),
                                modifier = Modifier.weight(1f).padding(horizontal = 8.dp).focusProperties { canFocus = false }
                            )
                            Text(fmt(duration), color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(end = 6.dp))
                            CircleCtrl(Icons.Filled.Forward10, 44.dp, 24.dp) { seekBy(10000) }
                        }
                    }
                }

                Spacer(Modifier.height(6.dp))

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                    if (playlist.size > 1) CtrlBtn(Icons.Filled.SkipPrevious, if (isLive) tr("السابق") else tr("السابقة")) { prev() }
                    if (info.type == "series") CtrlBtn(Icons.Filled.VideoLibrary, tr("الحلقات")) {
                        nav.navigate("seriesDetail") { launchSingleTop = true; popUpTo("player") { inclusive = true } }
                    }
                    CtrlBtn(Icons.Filled.AspectRatio, tr("الأبعاد")) { resizeIdx = (resizeIdx + 1) % resizeModes.size; Graph.session.setAspectMode(resizeIdx); show() }
                    if (!isLive) CtrlBtn(Icons.Filled.Speed, speedFmt(speeds[speedIdx])) {
                        speedIdx = (speedIdx + 1) % speeds.size; player.setPlaybackSpeed(speeds[speedIdx]); show()
                    }
                    CtrlBtn(Icons.Filled.ClosedCaption, if (subsOn) tr("ترجمة") else tr("بدون")) {
                        subsOn = !subsOn
                        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, !subsOn).build()
                        show()
                    }
                    if (info.type != "live") CtrlBtn(Icons.Filled.Download, tr("تحميل")) {
                        val d = Graph.downloader.enqueue(info.url, info.title, info.type, info.logo)
                        scope.launch { runCatching { dao.addDownload(d) } }
                        Toast.makeText(context, tr("بدأ التحميل"), Toast.LENGTH_SHORT).show(); show()
                    }
                    if (playlist.size > 1) CtrlBtn(Icons.Filled.SkipNext, if (isLive) tr("التالي") else tr("التالية")) { next() }
                }
            }
        }
    }
}

private val BrandBrightC = Color(0xFF4FC3FF)

@Composable
private fun CircleCtrl(icon: ImageVector, size: androidx.compose.ui.unit.Dp, iconSize: androidx.compose.ui.unit.Dp, onClick: () -> Unit) {
    Box(
        Modifier.size(size).clip(CircleShape).background(Color(0x55000000))
            .tvFocusBorder(CircleShape).clickable { onClick() },
        contentAlignment = Alignment.Center
    ) { Icon(icon, null, tint = Color.White, modifier = Modifier.size(iconSize)) }
}

@Composable
private fun CtrlBtn(icon: ImageVector, label: String, onClick: () -> Unit) {
    Column(
        Modifier.clip(RoundedCornerShape(10.dp)).tvFocusBorder(RoundedCornerShape(10.dp))
            .clickable { onClick() }.padding(horizontal = 10.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, label, tint = Color.White, modifier = Modifier.size(24.dp))
        Spacer(Modifier.height(3.dp))
        Text(label, color = Color.White, fontSize = 11.sp, maxLines = 1)
    }
}

private fun fmt(ms: Long): String {
    if (ms <= 0) return "00:00"
    val s = ms / 1000; val h = s / 3600; val m = (s % 3600) / 60; val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%02d:%02d".format(m, sec)
}

private fun speedFmt(v: Float): String = if (v == v.toLong().toFloat()) "${v.toLong()}x" else "${v}x"
