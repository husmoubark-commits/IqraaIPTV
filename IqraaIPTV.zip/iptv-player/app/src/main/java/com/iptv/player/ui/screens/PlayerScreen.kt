package com.iptv.player.ui.screens

import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import androidx.navigation.NavHostController
import com.iptv.player.data.Graph
import com.iptv.player.data.PlayerFactory
import com.iptv.player.data.ResumeEntity
import com.iptv.player.ui.PlayInfo
import com.iptv.player.ui.Selection
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(nav: NavHostController) {
    val context = LocalContext.current
    val dao = Graph.db.dao()
    val scope = rememberCoroutineScope()
    val playlist = remember { Selection.playlist.ifEmpty { listOf(Selection.play) } }
    val indexState = remember { mutableIntStateOf(Selection.index.coerceIn(0, playlist.lastIndex)) }
    val index = indexState.intValue
    val info: PlayInfo = playlist[index]

    val resizeModes = remember {
        listOf(
            AspectRatioFrameLayout.RESIZE_MODE_FIT,
            AspectRatioFrameLayout.RESIZE_MODE_ZOOM,
            AspectRatioFrameLayout.RESIZE_MODE_FILL
        )
    }
    val resizeLabels = listOf("احتواء", "تكبير", "ملء")
    var resizeIdx by remember { mutableIntStateOf(0) }

    val player = remember { PlayerFactory.build(context) }

    LaunchedEffect(index) {
        val cur = playlist[index]
        player.setMediaItem(MediaItem.fromUri(cur.url))
        player.prepare(); player.playWhenReady = true
        if (cur.type != "live" && cur.itemId.isNotBlank()) {
            val pos = runCatching { dao.resumePos(cur.type, cur.itemId) }.getOrNull() ?: 0L
            if (pos > 3000) player.seekTo(pos)
        }
    }

    LaunchedEffect(index) {
        val cur = playlist[index]
        if (cur.type != "live") {
            while (true) {
                delay(10000)
                val p = player.currentPosition; val d = player.duration
                if (p > 0 && d > 0) runCatching {
                    dao.saveResume(ResumeEntity(cur.type, cur.itemId, cur.title, cur.logo, p, d, System.currentTimeMillis()))
                }
            }
        }
    }

    DisposableEffect(player) {
        val l = object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_ENDED && Graph.session.autoPlayNext &&
                    info.type == "series" && indexState.intValue < playlist.lastIndex
                ) indexState.intValue = indexState.intValue + 1
            }
        }
        player.addListener(l)
        onDispose { player.removeListener(l); player.release() }
    }

    BackHandler { nav.popBackStack() }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                PlayerView(ctx).apply {
                    this.player = player
                    useController = true
                    keepScreenOn = true
                    setShowSubtitleButton(true)
                    setShowNextButton(false)
                    setShowPreviousButton(false)
                    resizeMode = resizeModes[0]
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
                    )
                }
            },
            update = { it.resizeMode = resizeModes[resizeIdx] }
        )

        Row(
            Modifier.align(Alignment.BottomCenter).padding(bottom = 22.dp)
                .clip(RoundedCornerShape(28.dp)).background(Color(0xAA1A0F30))
                .padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (playlist.size > 1) {
                CtrlIcon(Icons.Filled.SkipPrevious, "السابق") { if (index > 0) indexState.intValue = index - 1 }
            }
            CtrlIcon(Icons.Filled.AspectRatio, resizeLabels[resizeIdx]) {
                resizeIdx = (resizeIdx + 1) % resizeModes.size
            }
            if (info.type == "series") {
                CtrlIcon(Icons.Filled.VideoLibrary, "الحلقات") { nav.popBackStack() }
            }
            if (info.type != "live") {
                CtrlIcon(Icons.Filled.Download, "تحميل") {
                    val d = Graph.downloader.enqueue(info.url, info.title, info.type, info.logo)
                    scope.launch { runCatching { dao.addDownload(d) } }
                    Toast.makeText(context, "بدأ التحميل", Toast.LENGTH_SHORT).show()
                }
            }
            if (playlist.size > 1) {
                CtrlIcon(Icons.Filled.SkipNext, "التالي") { if (index < playlist.lastIndex) indexState.intValue = index + 1 }
            }
        }
    }
}

@Composable
private fun CtrlIcon(icon: ImageVector, label: String, onClick: () -> Unit) {
    Column(
        Modifier.clip(RoundedCornerShape(12.dp)).clickable { onClick() }
            .tvFocusBorder(RoundedCornerShape(12.dp)).padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, label, tint = Color.White, modifier = Modifier.size(26.dp))
        Text(label, color = Color.White, fontSize = 10.sp)
    }
}
