package com.iptv.player.ui.screens

import android.view.ViewGroup
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.navigation.NavHostController
import com.iptv.player.data.Graph
import com.iptv.player.data.ResumeEntity
import com.iptv.player.ui.Selection
import kotlinx.coroutines.delay

@androidx.annotation.OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(nav: NavHostController) {
    val context = LocalContext.current
    val info = Selection.play
    val dao = Graph.db.dao()

    val player = remember {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(info.url))
            playWhenReady = true
            prepare()
        }
    }

    LaunchedEffect(info.itemId) {
        if (info.type != "live" && info.itemId.isNotBlank()) {
            val pos = runCatching { dao.resumePos(info.type, info.itemId) }.getOrNull() ?: 0L
            if (pos > 3000) player.seekTo(pos)
            while (true) {
                delay(10000)
                val p = player.currentPosition
                val d = player.duration
                if (p > 0 && d > 0) {
                    runCatching {
                        dao.saveResume(
                            ResumeEntity(info.type, info.itemId, info.title, info.logo, p, d, System.currentTimeMillis())
                        )
                    }
                }
            }
        }
    }

    DisposableEffect(Unit) {
        onDispose { player.release() }
    }

    BackHandler { nav.popBackStack() }

    AndroidView(
        modifier = Modifier.fillMaxSize().background(Color.Black),
        factory = { ctx ->
            PlayerView(ctx).apply {
                this.player = player
                useController = true
                keepScreenOn = true
                setShowSubtitleButton(true)
                setShowNextButton(false)
                setShowPreviousButton(false)
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            }
        }
    )
}
