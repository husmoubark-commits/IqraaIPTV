package com.iptv.player.ui.screens

import android.content.Intent
import android.net.Uri
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.ClosedCaption
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import androidx.navigation.NavHostController
import com.iptv.player.data.Graph
import com.iptv.player.data.PlayerFactory
import com.iptv.player.data.ResumeEntity
import com.iptv.player.ui.PlayInfo
import com.iptv.player.ui.Selection
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(nav: NavHostController) {
    val context = LocalContext.current
    val dao = Graph.db.dao()
    val scope = rememberCoroutineScope()
    val playlist = remember { Selection.playlist.ifEmpty { listOf(Selection.play) } }
    val indexState = remember { mutableIntStateOf(Selection.index.coerceIn(0, playlist.lastIndex)) }
    val index = indexState.intValue
    val info: PlayInfo = playlist[index]

    // external player handoff
    val external = remember { Graph.session.useExternalPlayer }
    if (external) {
        LaunchedEffect(Unit) {
            runCatching {
                val i = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(Uri.parse(info.url), "video/*"); addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(Intent.createChooser(i, "تشغيل عبر").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
            nav.popBackStack()
        }
        Box(Modifier.fillMaxSize().background(Color.Black)); return
    }

    val resizeModes = remember {
        listOf(
            AspectRatioFrameLayout.RESIZE_MODE_FIT,
            AspectRatioFrameLayout.RESIZE_MODE_ZOOM,
            AspectRatioFrameLayout.RESIZE_MODE_FILL
        )
    }
    var resizeIdx by remember { mutableIntStateOf(0) }
    val speeds = remember { listOf(0.5f, 1f, 1.25f, 1.5f, 2f) }
    var speedIdx by remember { mutableIntStateOf(1) }
    var subsOn by remember { mutableStateOf(true) }

    var controlsVisible by remember { mutableStateOf(true) }
    var interaction by remember { mutableIntStateOf(0) }
    var isPlaying by remember { mutableStateOf(true) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var dragging by remember { mutableStateOf(false) }
    var dragPos by remember { mutableFloatStateOf(0f) }

    val player = remember { PlayerFactory.build(context) }
    val isLive = info.type == "live"

    LaunchedEffect(index) {
        val cur = playlist[index]
        player.setMediaItem(MediaItem.fromUri(cur.url))
        player.prepare(); player.playWhenReady = true
        if (cur.type != "live" && cur.itemId.isNotBlank()) {
            val pos = runCatching { dao.resumePos(cur.type, cur.itemId) }.getOrNull() ?: 0L
            if (pos > 3000) player.seekTo(pos)
        }
    }

    // position ticker
    LaunchedEffect(Unit) {
        while (true) {
            if (!dragging) position = player.currentPosition.coerceAtLeast(0L)
            duration = player.duration.coerceAtLeast(0L)
            delay(500)
        }
    }

    // resume save
    LaunchedEffect(index) {
        val cur = playlist[index]
        if (cur.type != "live") while (true) {
            delay(10000)
            val p = player.currentPosition; val d = player.duration
            if (p > 0 && d > 0) runCatching {
                dao.saveResume(ResumeEntity(cur.type, cur.itemId, cur.title, cur.logo, cur.url, p, d, System.currentTimeMillis()))
            }
        }
    }

    // auto-hide after 5s
    LaunchedEffect(controlsVisible, interaction) {
        if (controlsVisible) { delay(5000); controlsVisible = false }
    }

    DisposableEffect(player) {
        val l = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) { isPlaying = playing }
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_ENDED && Graph.session.autoPlayNext &&
                    info.type == "series" && indexState.intValue < playlist.lastIndex
                ) indexState.intValue = indexState.intValue + 1
            }
        }
        player.addListener(l)
        onDispose { player.removeListener(l); player.release() }
    }

    BackHandler { nav.popBackStack() }

    fun show() { controlsVisible = true; interaction++ }
    fun next() { if (index < playlist.lastIndex) indexState.intValue = index + 1; interaction++ }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                PlayerView(ctx).apply {
                    this.player = player
                    useController = false
                    keepScreenOn = true
                    resizeMode = resizeModes[0]
                    layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                }
            },
            update = { it.resizeMode = resizeModes[resizeIdx] }
        )

        // tap layer toggles controls
        Box(
            Modifier.fillMaxSize().clickable(
                interactionSource = remember { MutableInteractionSource() }, indication = null
            ) { if (controlsVisible) controlsVisible = false else show() }
        )

        // top title bar
        AnimatedVisibility(visible = controlsVisible, modifier = Modifier.align(Alignment.TopCenter)) {
            Row(
                Modifier.fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color(0xCC000000), Color.Transparent)))
                    .padding(horizontal = 12.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "back", tint = Color.White,
                    modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable { nav.popBackStack() }.padding(6.dp))
                Spacer(Modifier.width(10.dp))
                Text(info.title, color = Color.White, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }

        // bottom custom controller
        AnimatedVisibility(visible = controlsVisible, modifier = Modifier.align(Alignment.BottomCenter)) {
            Column(
                Modifier.fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xE6000000))))
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(40.dp).clip(RoundedCornerShape(20.dp)).background(Color(0x33FFFFFF))
                        .clickable { if (isPlaying) player.pause() else player.play(); show() }, contentAlignment = Alignment.Center) {
                        Icon(if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow, "playpause", tint = Color.White, modifier = Modifier.size(24.dp))
                    }
                    Spacer(Modifier.width(12.dp))
                    if (isLive || duration <= 0L) {
                        Text("● مباشر", color = Color(0xFFFF5252), fontSize = 13.sp)
                        Spacer(Modifier.weight(1f))
                    } else {
                        Text(fmt(position), color = Color.White, fontSize = 12.sp)
                        Slider(
                            value = (if (dragging) dragPos else position.toFloat()).coerceIn(0f, duration.toFloat()),
                            onValueChange = { dragging = true; dragPos = it; interaction++ },
                            onValueChangeFinished = { player.seekTo(dragPos.toLong()); position = dragPos.toLong(); dragging = false; interaction++ },
                            valueRange = 0f..duration.toFloat(),
                            colors = SliderDefaults.colors(thumbColor = BrandBrightC, activeTrackColor = BrandBrightC, inactiveTrackColor = Color(0x55FFFFFF)),
                            modifier = Modifier.weight(1f).padding(horizontal = 10.dp)
                        )
                        Text(fmt(duration), color = Color.White, fontSize = 12.sp)
                    }
                }

                Spacer(Modifier.height(6.dp))

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                    if (info.type == "series") CtrlBtn(Icons.Filled.VideoLibrary, "الحلقات") { nav.popBackStack() }
                    CtrlBtn(Icons.Filled.AspectRatio, "الأبعاد") { resizeIdx = (resizeIdx + 1) % resizeModes.size; show() }
                    if (!isLive) CtrlBtn(Icons.Filled.Speed, "السرعة ${speedFmt(speeds[speedIdx])}") {
                        speedIdx = (speedIdx + 1) % speeds.size; player.setPlaybackSpeed(speeds[speedIdx]); show()
                    }
                    CtrlBtn(Icons.Filled.ClosedCaption, if (subsOn) "ترجمة" else "بدون ترجمة") {
                        subsOn = !subsOn
                        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, !subsOn).build()
                        show()
                    }
                    if (info.type != "live") CtrlBtn(Icons.Filled.Download, "تحميل") {
                        val d = Graph.downloader.enqueue(info.url, info.title, info.type, info.logo)
                        scope.launch { runCatching { dao.addDownload(d) } }
                        Toast.makeText(context, "بدأ التحميل", Toast.LENGTH_SHORT).show(); show()
                    }
                    if (playlist.size > 1) CtrlBtn(Icons.Filled.SkipNext, if (isLive) "التالي" else "الحلقة التالية") { next() }
                }
            }
        }
    }
}

private val BrandBrightC = Color(0xFFC44DF0)

@Composable
private fun CtrlBtn(icon: ImageVector, label: String, onClick: () -> Unit) {
    Column(
        Modifier.clip(RoundedCornerShape(10.dp)).clickable { onClick() }
            .tvFocusBorder(RoundedCornerShape(10.dp)).padding(horizontal = 10.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, label, tint = Color.White, modifier = Modifier.size(24.dp))
        Spacer(Modifier.height(3.dp))
        Text(label, color = Color.White, fontSize = 11.sp, maxLines = 1)
    }
}

private fun fmt(ms: Long): String {
    if (ms <= 0) return "00:00"
    val s = ms / 1000; val h = s / 3600; val m = (s % 3600) / 60; val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%02d:%02d".format(m, sec)
}

private fun speedFmt(v: Float): String = if (v == v.toLong().toFloat()) "${v.toLong()}x" else "${v}x"
