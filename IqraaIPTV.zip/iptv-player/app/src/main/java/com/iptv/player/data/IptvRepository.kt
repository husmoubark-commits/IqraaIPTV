package com.iptv.player.data

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

class IptvRepository(private val session: Session) {

    private val http = buildTolerantClient()

    private fun buildTolerantClient(): OkHttpClient {
        // IPTV panels are often https with self-signed certs, or block requests
        // that carry no User-Agent. Build a tolerant client so any panel works.
        val trustAll = object : javax.net.ssl.X509TrustManager {
            override fun checkClientTrusted(c: Array<java.security.cert.X509Certificate>?, a: String?) {}
            override fun checkServerTrusted(c: Array<java.security.cert.X509Certificate>?, a: String?) {}
            override fun getAcceptedIssuers(): Array<java.security.cert.X509Certificate> = arrayOf()
        }
        val ssl = javax.net.ssl.SSLContext.getInstance("TLS").apply {
            init(null, arrayOf<javax.net.ssl.TrustManager>(trustAll), java.security.SecureRandom())
        }
        return OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .sslSocketFactory(ssl.socketFactory, trustAll)
            .hostnameVerifier { _, _ -> true }
            .followRedirects(true)
            .followSslRedirects(true)
            .retryOnConnectionFailure(true)
            .addInterceptor { chain ->
                chain.proceed(
                    chain.request().newBuilder()
                        .header("User-Agent", "IqraaIPTV/1.0 (Linux;Android) ExoPlayer")
                        .build()
                )
            }
            .build()
    }

    private fun acc() = session.account ?: error("No account")
    private val u get() = acc().username
    private val p get() = acc().password
    val isXtream get() = acc().type == AccountType.XTREAM
    @Volatile private var resolvedBase: String? = null
    private fun rawBase() = acc().server.trimEnd('/')
    private fun base() = resolvedBase ?: rawBase()
    private fun flipScheme(url: String): String = when {
        url.startsWith("https://", ignoreCase = true) -> "http://" + url.substring(8)
        url.startsWith("http://", ignoreCase = true) -> "https://" + url.substring(7)
        else -> "http://$url"
    }
    // Some panels declare https but actually serve plain http on that port
    // (TLS handshake fails with "Unable to parse TLS packet header").
    // On any SSL error, flip the scheme once, remember it, and retry.
    private suspend fun <T> apiCall(block: suspend (XtreamApi) -> T): T =
        try { block(api()) }
        catch (e: javax.net.ssl.SSLException) { resolvedBase = flipScheme(rawBase()); block(api()) }

    private fun api(): XtreamApi = Retrofit.Builder()
        .baseUrl(base() + "/")
        .client(http)
        .addConverterFactory(GsonConverterFactory.create())
        .build()
        .create(XtreamApi::class.java)

    // ---------- stream URLs ----------
    fun liveUrl(id: String) = "${base()}/live/$u/$p/$id.${Graph.session.liveExtension()}"
    fun vodUrl(id: String, ext: String?) = "${base()}/movie/$u/$p/$id.${ext ?: "mp4"}"
    fun seriesUrl(id: String, ext: String?) = "${base()}/series/$u/$p/$id.${ext ?: "mp4"}"
    fun livePlayUrl(ch: LiveChannel) = if (isXtream) liveUrl(ch.id) else ch.id

    suspend fun accountInfo(): AccountInfo? = withContext(Dispatchers.IO) {
        if (!isXtream) return@withContext null
        val ui = runCatching { apiCall { it.accountInfo(u, p) }.userInfo }.getOrNull() ?: return@withContext null
        val exp = ui.expDate?.toLongOrNull()
            ?.let { SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH).format(Date(it * 1000)) } ?: "بدون انتهاء"
        AccountInfo(ui.status ?: "-", exp, ui.activeCons ?: "0", ui.maxConnections ?: "-", ui.isTrial == "1")
    }

    // ---------- M3U cache ----------
    @Volatile private var m3uCache: M3uData? = null
    fun clearCache() { m3uCache = null; resolvedBase = null }
    private fun fetchText(url: String): String {
        fun get(u: String) = http.newCall(Request.Builder().url(u).build()).execute().use { it.body?.string() ?: "" }
        return try { get(url) } catch (e: javax.net.ssl.SSLException) { get(flipScheme(url.trimEnd('/'))) }
    }
    private fun m3u(): M3uData {
        m3uCache?.let { return it }
        val body = fetchText(acc().m3uUrl)
        return M3uParser.parse(body).also { m3uCache = it }
    }

    // ---------- Live ----------
    suspend fun liveCategories(): List<Category> = withContext(Dispatchers.IO) {
        if (!isXtream) m3u().categories
        else apiCall { it.liveCategories(u, p) }.mapNotNull {
            it.categoryId?.let { id -> Category(id, it.categoryName ?: "—") }
        }
    }

    suspend fun liveChannels(categoryId: String?): List<LiveChannel> = withContext(Dispatchers.IO) {
        if (!isXtream) m3u().channels.filter { categoryId == null || it.categoryId == categoryId }
        else apiCall { it.liveStreams(u, p, categoryId) }.map {
            LiveChannel(it.streamId ?: "", it.name ?: "—", it.streamIcon, it.epgChannelId, it.categoryId)
        }
    }

    // ---------- VOD ----------
    suspend fun vodCategories(): List<Category> = withContext(Dispatchers.IO) {
        if (!isXtream) emptyList()
        else apiCall { it.vodCategories(u, p) }.mapNotNull {
            it.categoryId?.let { id -> Category(id, it.categoryName ?: "—") }
        }
    }

    suspend fun vod(categoryId: String?): List<VodItem> = withContext(Dispatchers.IO) {
        if (!isXtream) emptyList()
        else apiCall { it.vodStreams(u, p, categoryId) }.map {
            VodItem(it.streamId ?: "", it.name ?: "—", it.streamIcon, it.categoryId, it.rating, it.containerExtension)
        }
    }

    suspend fun vodInfo(id: String): MovieInfo? = withContext(Dispatchers.IO) {
        if (!isXtream) null
        else runCatching {
            val r = apiCall { it.vodInfo(u, p, id) }.info
            MovieInfo(r?.plot, r?.genre, r?.cast, r?.director, r?.releaseDate, r?.duration, r?.rating, r?.movieImage)
        }.getOrNull()
    }

    // ---------- Series ----------
    suspend fun seriesCategories(): List<Category> = withContext(Dispatchers.IO) {
        if (!isXtream) emptyList()
        else apiCall { it.seriesCategories(u, p) }.mapNotNull {
            it.categoryId?.let { id -> Category(id, it.categoryName ?: "—") }
        }
    }

    suspend fun seriesList(categoryId: String?): List<SeriesItem> = withContext(Dispatchers.IO) {
        if (!isXtream) emptyList()
        else apiCall { it.series(u, p, categoryId) }.map {
            SeriesItem(it.seriesId ?: "", it.name ?: "—", it.cover, it.plot, it.categoryId, it.rating)
        }
    }

    suspend fun seriesInfo(seriesId: String): List<Season> = withContext(Dispatchers.IO) {
        val info = apiCall { it.seriesInfo(u, p, seriesId) }
        val eps = info.episodes ?: emptyMap()
        eps.entries
            .sortedBy { it.key.toIntOrNull() ?: 0 }
            .map { (seasonKey, list) ->
                val sn = seasonKey.toIntOrNull() ?: 0
                Season(sn, "Season $sn", list.map { e ->
                    Episode(
                        id = e.id ?: "",
                        title = e.title ?: "Episode ${e.episodeNum ?: ""}",
                        season = e.season?.toIntOrNull() ?: sn,
                        episodeNum = e.episodeNum?.toIntOrNull() ?: 0,
                        extension = e.containerExtension,
                        cover = e.info?.movieImage,
                        plot = e.info?.plot
                    )
                })
            }
    }

    // ---------- EPG ----------
    suspend fun nowNext(streamId: String): List<EpgEntry> = withContext(Dispatchers.IO) {
        if (!isXtream) return@withContext emptyList()
        runCatching {
            apiCall { it.shortEpg(u, p, streamId) }.listings.orEmpty().map {
                EpgEntry(decode(it.title), decode(it.description))
            }
        }.getOrDefault(emptyList())
    }

    private fun decode(s: String?): String {
        if (s.isNullOrBlank()) return ""
        return try {
            String(Base64.decode(s, Base64.DEFAULT)).trim()
        } catch (e: Exception) { s }
    }
}
