package com.iptv.player.data

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

class IptvRepository(private val session: Session) {

    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    private fun acc() = session.account ?: error("No account")
    private val u get() = acc().username
    private val p get() = acc().password
    val isXtream get() = acc().type == AccountType.XTREAM
    private fun base() = acc().server.trimEnd('/')

    private fun api(): XtreamApi = Retrofit.Builder()
        .baseUrl(base() + "/")
        .client(http)
        .addConverterFactory(GsonConverterFactory.create())
        .build()
        .create(XtreamApi::class.java)

    // ---------- stream URLs ----------
    fun liveUrl(id: String) = "${base()}/live/$u/$p/$id.m3u8"
    fun vodUrl(id: String, ext: String?) = "${base()}/movie/$u/$p/$id.${ext ?: "mp4"}"
    fun seriesUrl(id: String, ext: String?) = "${base()}/series/$u/$p/$id.${ext ?: "mp4"}"
    fun livePlayUrl(ch: LiveChannel) = if (isXtream) liveUrl(ch.id) else ch.id

    // ---------- M3U cache ----------
    @Volatile private var m3uCache: M3uData? = null
    fun clearCache() { m3uCache = null }
    private fun m3u(): M3uData {
        m3uCache?.let { return it }
        val req = Request.Builder().url(acc().m3uUrl).build()
        val body = http.newCall(req).execute().use { it.body?.string() ?: "" }
        return M3uParser.parse(body).also { m3uCache = it }
    }

    // ---------- Live ----------
    suspend fun liveCategories(): List<Category> = withContext(Dispatchers.IO) {
        if (!isXtream) m3u().categories
        else api().liveCategories(u, p).mapNotNull {
            it.categoryId?.let { id -> Category(id, it.categoryName ?: "—") }
        }
    }

    suspend fun liveChannels(categoryId: String?): List<LiveChannel> = withContext(Dispatchers.IO) {
        if (!isXtream) m3u().channels.filter { categoryId == null || it.categoryId == categoryId }
        else api().liveStreams(u, p, categoryId).map {
            LiveChannel(it.streamId ?: "", it.name ?: "—", it.streamIcon, it.epgChannelId, it.categoryId)
        }
    }

    // ---------- VOD ----------
    suspend fun vodCategories(): List<Category> = withContext(Dispatchers.IO) {
        if (!isXtream) emptyList()
        else api().vodCategories(u, p).mapNotNull {
            it.categoryId?.let { id -> Category(id, it.categoryName ?: "—") }
        }
    }

    suspend fun vod(categoryId: String?): List<VodItem> = withContext(Dispatchers.IO) {
        if (!isXtream) emptyList()
        else api().vodStreams(u, p, categoryId).map {
            VodItem(it.streamId ?: "", it.name ?: "—", it.streamIcon, it.categoryId, it.rating, it.containerExtension)
        }
    }

    // ---------- Series ----------
    suspend fun seriesCategories(): List<Category> = withContext(Dispatchers.IO) {
        if (!isXtream) emptyList()
        else api().seriesCategories(u, p).mapNotNull {
            it.categoryId?.let { id -> Category(id, it.categoryName ?: "—") }
        }
    }

    suspend fun seriesList(categoryId: String?): List<SeriesItem> = withContext(Dispatchers.IO) {
        if (!isXtream) emptyList()
        else api().series(u, p, categoryId).map {
            SeriesItem(it.seriesId ?: "", it.name ?: "—", it.cover, it.plot, it.categoryId, it.rating)
        }
    }

    suspend fun seriesInfo(seriesId: String): List<Season> = withContext(Dispatchers.IO) {
        val info = api().seriesInfo(u, p, seriesId)
        val eps = info.episodes ?: emptyMap()
        eps.entries
            .sortedBy { it.key.toIntOrNull() ?: 0 }
            .map { (seasonKey, list) ->
                val sn = seasonKey.toIntOrNull() ?: 0
                Season(sn, "Season $sn", list.map { e ->
                    Episode(
                        id = e.id ?: "",
                        title = e.title ?: "Episode ${e.episodeNum ?: ""}",
                        season = e.season?.toIntOrNull() ?: sn,
                        episodeNum = e.episodeNum?.toIntOrNull() ?: 0,
                        extension = e.containerExtension,
                        cover = e.info?.movieImage,
                        plot = e.info?.plot
                    )
                })
            }
    }

    // ---------- EPG ----------
    suspend fun nowNext(streamId: String): List<EpgEntry> = withContext(Dispatchers.IO) {
        if (!isXtream) return@withContext emptyList()
        runCatching {
            api().shortEpg(u, p, streamId).listings.orEmpty().map {
                EpgEntry(decode(it.title), decode(it.description))
            }
        }.getOrDefault(emptyList())
    }

    private fun decode(s: String?): String {
        if (s.isNullOrBlank()) return ""
        return try {
            String(Base64.decode(s, Base64.DEFAULT)).trim()
        } catch (e: Exception) { s }
    }
}
