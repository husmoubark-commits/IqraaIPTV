package com.iptv.player.data

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import java.io.File

object DownloadHelper {

    fun enqueue(context: Context, url: String, title: String): Long {
        val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val safe = title.replace(Regex("[^a-zA-Z0-9\\u0600-\\u06FF _-]"), "_").trim().take(80).ifBlank { "video" }
        val ext = url.substringBefore('?').substringAfterLast('.', "ts").take(4).ifBlank { "ts" }
        val name = "$safe.$ext"
        val req = DownloadManager.Request(Uri.parse(url))
            .setTitle(title)
            .setDescription("Voltix IPTV Player")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalFilesDir(context, Environment.DIRECTORY_DOWNLOADS, name)
            .setAllowedOverMetered(true)
            .setAllowedOverRoaming(true)
        return dm.enqueue(req)
    }

    fun listFiles(context: Context): List<File> {
        val dir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: return emptyList()
        return dir.listFiles()?.filter { it.isFile }?.sortedByDescending { it.lastModified() } ?: emptyList()
    }
}
