package com.iptv.player.data

import android.content.Context
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory

@UnstableApi
object PlayerFactory {

    private fun mediaSourceFactory(context: Context): DefaultMediaSourceFactory {
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent("IqraaIPTV/1.0 (Linux;Android) ExoPlayer")
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(20000)
            .setReadTimeoutMs(20000)
            .setKeepPostFor302Redirects(true)
        val ds = DefaultDataSource.Factory(context, http)
        return DefaultMediaSourceFactory(ds)
    }

    fun build(context: Context): ExoPlayer =
        ExoPlayer.Builder(context)
            .setMediaSourceFactory(mediaSourceFactory(context))
            .build()
}
