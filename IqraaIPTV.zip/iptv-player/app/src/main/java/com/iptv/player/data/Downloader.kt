package com.iptv.player.data

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import java.io.File

class Downloader(private val context: Context) {
    private val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager

    private fun sanitize(s: String) = s.replace(Regex("[^a-zA-Z0-9\\u0600-\\u06FF _-]"), "").trim().take(60).ifBlank { "video" }

    private fun ext(url: String): String {
        val e = url.substringAfterLast('.', "mp4").substringBefore('?').lowercase()
        return if (e.length in 2..4) e else "mp4"
    }

    fun enqueue(url: String, name: String, type: String, poster: String?): DownloadEntity {
        val fileName = "${sanitize(name)}_${System.currentTimeMillis()}.${ext(url)}"
        val req = DownloadManager.Request(Uri.parse(url))
            .setTitle(name)
            .setDescription("Iqraa IPTV")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalFilesDir(context, Environment.DIRECTORY_MOVIES, fileName)
            .setAllowedOverMetered(true)
            .setAllowedOverRoaming(true)
        val id = dm.enqueue(req)
        val path = File(context.getExternalFilesDir(Environment.DIRECTORY_MOVIES), fileName).absolutePath
        return DownloadEntity(id, name, type, url, path, poster, System.currentTimeMillis())
    }

    // returns Pair(statusCode, progressPercent)
    fun query(id: Long): Pair<Int, Int> {
        val q = DownloadManager.Query().setFilterById(id)
        dm.query(q).use { c ->
            if (c != null && c.moveToFirst()) {
                val status = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                val total = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
                val done = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
                val pct = if (total > 0) ((done * 100) / total).toInt() else 0
                return status to pct
            }
        }
        return DownloadManager.STATUS_FAILED to 0
    }

    fun remove(id: Long) { dm.remove(id) }
}
