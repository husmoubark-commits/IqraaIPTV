package com.iptv.player.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Theaters
import androidx.compose.material.icons.filled.ViewModule
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.iptv.player.data.Graph
import com.iptv.player.ui.theme.*
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HomeScreen(nav: NavHostController) {
    val profile = Graph.session.account?.name ?: "User"
    var now by remember { mutableStateOf(clock()) }
    LaunchedEffect(Unit) { while (true) { now = clock(); delay(15000) } }

    Column(Modifier.fillMaxSize().background(Bg).padding(20.dp)) {
        // top bar
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            BrandLogo(40.dp)
            Spacer(Modifier.width(16.dp))
            Text(now, color = Color.White, fontSize = 15.sp)
            Spacer(Modifier.width(20.dp))
            Icon(Icons.Filled.Search, null, tint = Muted)
            Spacer(Modifier.width(6.dp))
            Text("Master Search", color = Muted)
            Spacer(Modifier.weight(1f))
            Text(profile, color = Color.White)
            Spacer(Modifier.width(8.dp))
            Box(
                Modifier.size(36.dp).clip(RoundedCornerShape(8.dp)).background(BrandPrimary),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Filled.Person, null, tint = Color.White) }
        }

        Spacer(Modifier.height(28.dp))

        // three main cards
        Row(Modifier.fillMaxWidth().height(220.dp)) {
            BigCard("LIVE TV", LiveGradient, Icons.Filled.LiveTv, Modifier.weight(1f)) { nav.navigate("live") }
            Spacer(Modifier.width(14.dp))
            BigCard("MOVIES", MoviesGradient, Icons.Filled.PlayArrow, Modifier.weight(1f)) { nav.navigate("movies") }
            Spacer(Modifier.width(14.dp))
            BigCard("SERIES", SeriesGradient, Icons.Filled.Theaters, Modifier.weight(1f)) { nav.navigate("series") }
        }

        Spacer(Modifier.height(16.dp))

        // bottom chips
        Row(Modifier.fillMaxWidth()) {
            ChipButton("LIVE WITH EPG", Icons.Filled.MenuBook, Modifier.weight(1f)) { nav.navigate("live") }
            Spacer(Modifier.width(12.dp))
            ChipButton("MULTI-SCREEN", Icons.Filled.ViewModule, Modifier.weight(1f)) { nav.navigate("live") }
            Spacer(Modifier.width(12.dp))
            ChipButton("CATCH UP", Icons.Filled.History, Modifier.weight(1f)) { nav.navigate("live") }
        }

        Spacer(Modifier.weight(1f))
        Text("Iqraa IPTV", color = Muted, fontSize = 12.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
    }
}

@Composable
private fun BigCard(title: String, brush: Brush, icon: ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier
            .fillMaxHeight()
            .clip(RoundedCornerShape(18.dp))
            .background(brush)
            .clickable { onClick() }
    ) {
        Column(
            Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(icon, null, tint = Color.White, modifier = Modifier.size(64.dp))
            Spacer(Modifier.height(12.dp))
            Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        }
        Text(
            "Last updated: now",
            color = Color(0xCCFFFFFF),
            fontSize = 11.sp,
            modifier = Modifier.align(Alignment.BottomStart).padding(12.dp)
        )
    }
}

@Composable
private fun ChipButton(title: String, icon: ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Row(
        modifier
            .clip(RoundedCornerShape(12.dp))
            .background(Surface2)
            .clickable { onClick() }
            .padding(vertical = 16.dp, horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = BrandBright, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(8.dp))
        Text(title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

private fun clock(): String =
    SimpleDateFormat("hh:mm a   •   MMM dd, yyyy", Locale.ENGLISH).format(Date())
