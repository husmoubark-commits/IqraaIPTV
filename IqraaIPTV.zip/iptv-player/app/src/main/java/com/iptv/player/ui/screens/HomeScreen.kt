package com.iptv.player.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Theaters
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.iptv.player.data.Graph
import com.iptv.player.ui.Refresh
import com.iptv.player.ui.theme.*
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HomeScreen(nav: NavHostController) {
    val context = LocalContext.current
    val profile = Graph.session.account?.name ?: "User"
    var now by remember { mutableStateOf(clock()) }
    LaunchedEffect(Unit) { while (true) { now = clock(); delay(15000) } }

    fun refresh() {
        Graph.repo.clearCache(); Graph.session.markRefreshed(); Refresh.tick++
        Toast.makeText(context, "تم التحديث", Toast.LENGTH_SHORT).show()
    }

    Column(Modifier.fillMaxSize().background(Bg).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            BrandLogo(36.dp)
            Spacer(Modifier.width(14.dp))
            Text(now, color = Color.White, fontSize = 14.sp)
            Spacer(Modifier.width(16.dp))
            Icon(Icons.Filled.Search, null, tint = Muted)
            Spacer(Modifier.width(6.dp))
            Text("Master Search", color = Muted, fontSize = 13.sp)
            Spacer(Modifier.weight(1f))
            Box(
                Modifier.size(38.dp).clip(RoundedCornerShape(8.dp)).background(Surface2)
                    .clickable { refresh() }.tvFocusBorder(),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Filled.Refresh, "refresh", tint = BrandBright) }
            Spacer(Modifier.width(10.dp))
            Box(
                Modifier.size(38.dp).clip(RoundedCornerShape(8.dp)).background(Surface2)
                    .clickable { nav.navigate("settings") }.tvFocusBorder(),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Filled.Settings, "settings", tint = BrandBright) }
            Spacer(Modifier.width(12.dp))
            Row(
                Modifier.clip(RoundedCornerShape(10.dp)).background(Surface2)
                    .clickable { nav.navigate("profiles") }.tvFocusBorder()
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(profile, color = Color.White, fontSize = 13.sp)
                Spacer(Modifier.width(8.dp))
                Box(Modifier.size(30.dp).clip(RoundedCornerShape(7.dp)).background(BrandPrimary), contentAlignment = Alignment.Center) {
                    Icon(Icons.Filled.Person, null, tint = Color.White, modifier = Modifier.size(18.dp))
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        // main cards take remaining space (so bottom chips always fit, esp. in landscape)
        Row(Modifier.fillMaxWidth().weight(1f)) {
            BigCard("LIVE TV", LiveGradient, Icons.Filled.LiveTv, Modifier.weight(1f)) { nav.navigate("live") }
            Spacer(Modifier.width(14.dp))
            BigCard("MOVIES", MoviesGradient, Icons.Filled.PlayArrow, Modifier.weight(1f)) { nav.navigate("movies") }
            Spacer(Modifier.width(14.dp))
            BigCard("SERIES", SeriesGradient, Icons.Filled.Theaters, Modifier.weight(1f)) { nav.navigate("series") }
        }

        Spacer(Modifier.height(14.dp))

        Row(Modifier.fillMaxWidth().height(74.dp)) {
            ChipButton("القنوات والدليل", Icons.Filled.MenuBook, Modifier.weight(1f)) { nav.navigate("live") }
            Spacer(Modifier.width(12.dp))
            ChipButton("التحميلات", Icons.Filled.Download, Modifier.weight(1f)) { nav.navigate("downloads") }
            Spacer(Modifier.width(12.dp))
            ChipButton("تحديث", Icons.Filled.Refresh, Modifier.weight(1f)) { refresh() }
        }
    }
}

@Composable
private fun BigCard(title: String, brush: Brush, icon: ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Box(modifier.fillMaxHeight().clip(RoundedCornerShape(18.dp)).background(brush).clickable { onClick() }.tvFocusBorder(RoundedCornerShape(18.dp))) {
        Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Icon(icon, null, tint = Color.White, modifier = Modifier.size(52.dp))
            Spacer(Modifier.height(10.dp))
            Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
    }
}

@Composable
private fun ChipButton(title: String, icon: ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.fillMaxHeight().clip(RoundedCornerShape(12.dp)).background(Surface2).clickable { onClick() }.tvFocusBorder()
            .padding(vertical = 10.dp, horizontal = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(icon, null, tint = BrandBright, modifier = Modifier.size(22.dp))
        Spacer(Modifier.height(6.dp))
        Text(title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center, maxLines = 1)
    }
}

private fun clock(): String = SimpleDateFormat("hh:mm a   •   MMM dd", Locale.ENGLISH).format(Date())
