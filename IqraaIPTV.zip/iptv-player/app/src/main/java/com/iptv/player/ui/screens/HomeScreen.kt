package com.iptv.player.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Theaters
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.iptv.player.data.Graph
import com.iptv.player.ui.Refresh
import com.iptv.player.ui.theme.*
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HomeScreen(nav: NavHostController) {
    val context = LocalContext.current
    val profile = Graph.session.account?.name ?: "User"
    val firstFocus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { firstFocus.requestFocus() } }
    var now by remember { mutableStateOf(clock(Graph.session.timeFormat)) }
    LaunchedEffect(Unit) { while (true) { now = clock(Graph.session.timeFormat); delay(15000) } }

    fun refresh() {
        Graph.repo.clearCache(); Graph.session.markRefreshed(); Refresh.tick++
        Toast.makeText(context, "تم التحديث", Toast.LENGTH_SHORT).show()
    }

    Column(Modifier.fillMaxSize().background(Bg).padding(horizontal = 16.dp, vertical = 12.dp)) {

        // ===== TOP BAR (bigger) =====
        Row(Modifier.fillMaxWidth().weight(0.17f), verticalAlignment = Alignment.CenterVertically) {
            BrandLogo(46.dp)
            Spacer(Modifier.width(16.dp))
            Text(now, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.width(20.dp))
            Icon(Icons.Filled.Search, null, tint = Muted, modifier = Modifier.size(26.dp))
            Spacer(Modifier.width(8.dp))
            Text("Master Search", color = Muted, fontSize = 15.sp)
            Spacer(Modifier.weight(1f))
            Box(
                Modifier.size(48.dp).clip(RoundedCornerShape(10.dp)).background(Surface2)
                    .clickable { refresh() }.tvFocusBorder(),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Filled.Refresh, "refresh", tint = BrandBright, modifier = Modifier.size(26.dp)) }
            Spacer(Modifier.width(12.dp))
            Box(
                Modifier.size(48.dp).clip(RoundedCornerShape(10.dp)).background(Surface2)
                    .clickable { nav.navigate("settings") }.tvFocusBorder(),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Filled.Settings, "settings", tint = BrandBright, modifier = Modifier.size(26.dp)) }
            Spacer(Modifier.width(12.dp))
            Row(
                Modifier.clip(RoundedCornerShape(12.dp)).background(Surface2)
                    .clickable { nav.navigate("profiles") }.tvFocusBorder()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(profile, color = Color.White, fontSize = 15.sp)
                Spacer(Modifier.width(8.dp))
                Box(Modifier.size(36.dp).clip(RoundedCornerShape(9.dp)).background(BrandPrimary), contentAlignment = Alignment.Center) {
                    Icon(Icons.Filled.Person, null, tint = Color.White, modifier = Modifier.size(22.dp))
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        // ===== MAIN CARDS (smaller share) =====
        Row(Modifier.fillMaxWidth().weight(0.6f)) {
            BigCard("LIVE TV", LiveGradient, Icons.Filled.LiveTv, Modifier.weight(1f).focusRequester(firstFocus)) { nav.navigate("live") }
            Spacer(Modifier.width(14.dp))
            BigCard("MOVIES", MoviesGradient, Icons.Filled.PlayArrow, Modifier.weight(1f)) { nav.navigate("movies") }
            Spacer(Modifier.width(14.dp))
            BigCard("SERIES", SeriesGradient, Icons.Filled.Theaters, Modifier.weight(1f)) { nav.navigate("series") }
        }

        Spacer(Modifier.height(12.dp))

        // ===== BOTTOM CHIPS (bigger) =====
        Row(Modifier.fillMaxWidth().weight(0.23f)) {
            ChipButton("القنوات والدليل", Icons.Filled.MenuBook, Modifier.weight(1f)) { nav.navigate("live") }
            Spacer(Modifier.width(12.dp))
            ChipButton("التحميلات", Icons.Filled.Download, Modifier.weight(1f)) { nav.navigate("downloads") }
            Spacer(Modifier.width(12.dp))
            ChipButton("تحديث", Icons.Filled.Refresh, Modifier.weight(1f)) { refresh() }
        }
    }
}

@Composable
private fun BigCard(title: String, brush: Brush, icon: ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Box(modifier.fillMaxHeight().clickable { onClick() }.tvFocusBorder(RoundedCornerShape(18.dp))) {
        Box(Modifier.fillMaxSize().clip(RoundedCornerShape(18.dp)).background(brush)) {
            Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Icon(icon, null, tint = Color.White, modifier = Modifier.size(50.dp))
                Spacer(Modifier.height(10.dp))
                Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            }
        }
    }
}

@Composable
private fun ChipButton(title: String, icon: ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Box(modifier.fillMaxHeight().clickable { onClick() }.tvFocusBorder(RoundedCornerShape(14.dp))) {
        Column(
            Modifier.fillMaxSize().clip(RoundedCornerShape(14.dp)).background(Surface2)
                .padding(vertical = 10.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(icon, null, tint = BrandBright, modifier = Modifier.size(30.dp))
            Spacer(Modifier.height(8.dp))
            Text(title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center, maxLines = 1)
        }
    }
}

private fun clock(fmt: String): String {
    val pattern = if (fmt == "24") "HH:mm   •   MMM dd" else "hh:mm a   •   MMM dd"
    return SimpleDateFormat(pattern, Locale.ENGLISH).format(Date())
}
