package com.iptv.player.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Theaters
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.iptv.player.data.Graph
import com.iptv.player.ui.Refresh
import com.iptv.player.ui.theme.*
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HomeScreen(nav: NavHostController) {
    val context = LocalContext.current
    val profile = Graph.session.account?.name ?: "User"
    var now by remember { mutableStateOf(clock()) }
    LaunchedEffect(Unit) { while (true) { now = clock(); delay(15000) } }

    Column(Modifier.fillMaxSize().background(Bg).padding(18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            BrandLogo(38.dp)
            Spacer(Modifier.width(14.dp))
            Text(now, color = Color.White, fontSize = 14.sp)
            Spacer(Modifier.width(16.dp))
            Icon(Icons.Filled.Search, null, tint = Muted)
            Spacer(Modifier.width(6.dp))
            Text("Master Search", color = Muted, fontSize = 13.sp)
            Spacer(Modifier.weight(1f))

            // force refresh
            Box(
                Modifier.size(38.dp).clip(RoundedCornerShape(8.dp)).background(Surface2)
                    .clickable {
                        Graph.repo.clearCache(); Graph.session.markRefreshed(); Refresh.tick++
                        Toast.makeText(context, "تم التحديث", Toast.LENGTH_SHORT).show()
                    }.tvFocusBorder(),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Filled.Refresh, "refresh", tint = BrandBright) }

            Spacer(Modifier.width(12.dp))
            // profile -> profiles screen
            Row(
                Modifier.clip(RoundedCornerShape(10.dp)).background(Surface2)
                    .clickable { nav.navigate("profiles") }.tvFocusBorder()
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(profile, color = Color.White, fontSize = 13.sp)
                Spacer(Modifier.width(8.dp))
                Box(Modifier.size(30.dp).clip(RoundedCornerShape(7.dp)).background(BrandPrimary), contentAlignment = Alignment.Center) {
                    Icon(Icons.Filled.Person, null, tint = Color.White, modifier = Modifier.size(18.dp))
                }
            }
        }

        Spacer(Modifier.height(24.dp))

        Row(Modifier.fillMaxWidth().height(200.dp)) {
            BigCard("LIVE TV", LiveGradient, Icons.Filled.LiveTv, Modifier.weight(1f)) { nav.navigate("live") }
            Spacer(Modifier.width(14.dp))
            BigCard("MOVIES", MoviesGradient, Icons.Filled.PlayArrow, Modifier.weight(1f)) { nav.navigate("movies") }
            Spacer(Modifier.width(14.dp))
            BigCard("SERIES", SeriesGradient, Icons.Filled.Theaters, Modifier.weight(1f)) { nav.navigate("series") }
        }

        Spacer(Modifier.height(16.dp))

        Row(Modifier.fillMaxWidth()) {
            ChipButton("LIVE WITH EPG", Icons.Filled.MenuBook, Modifier.weight(1f)) { nav.navigate("live") }
            Spacer(Modifier.width(12.dp))
            ChipButton("التحميلات", Icons.Filled.Download, Modifier.weight(1f)) { nav.navigate("downloads") }
            Spacer(Modifier.width(12.dp))
            ChipButton("FORCE REFRESH", Icons.Filled.Refresh, Modifier.weight(1f)) {
                Graph.repo.clearCache(); Graph.session.markRefreshed(); Refresh.tick++
                Toast.makeText(context, "تم التحديث", Toast.LENGTH_SHORT).show()
            }
        }

        Spacer(Modifier.weight(1f))
        Text("Iqraa IPTV", color = Muted, fontSize = 12.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
    }
}

@Composable
private fun BigCard(title: String, brush: Brush, icon: ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Box(modifier.fillMaxHeight().clip(RoundedCornerShape(18.dp)).background(brush).clickable { onClick() }.tvFocusBorder(RoundedCornerShape(18.dp))) {
        Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Icon(icon, null, tint = Color.White, modifier = Modifier.size(58.dp))
            Spacer(Modifier.height(12.dp))
            Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 19.sp)
        }
    }
}

@Composable
private fun ChipButton(title: String, icon: ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Row(
        modifier.clip(RoundedCornerShape(12.dp)).background(Surface2).clickable { onClick() }.tvFocusBorder()
            .padding(vertical = 15.dp, horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = BrandBright, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(8.dp))
        Text(title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

private fun clock(): String = SimpleDateFormat("hh:mm a   •   MMM dd", Locale.ENGLISH).format(Date())
