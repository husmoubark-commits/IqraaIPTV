package com.iptv.player.ui.screens

import kotlinx.coroutines.launch
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SportsSoccer
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Theaters
import androidx.compose.material3.Icon
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.iptv.player.data.Graph
import com.iptv.player.ui.Refresh
import com.iptv.player.ui.theme.*
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HomeScreen(nav: NavHostController) {
    val context = LocalContext.current
    val profile = Graph.session.account?.name ?: "User"
    val firstFocus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { firstFocus.requestFocus() } }
    var now by remember { mutableStateOf(clock(Graph.session.timeFormat)) }
    LaunchedEffect(Unit) { while (true) { now = clock(Graph.session.timeFormat); delay(15000) } }

    val scope = rememberCoroutineScope()
    var refreshing by remember { mutableStateOf(false) }
    fun refresh() {
        if (refreshing) return
        refreshing = true
        Refresh.begin()
        Graph.repo.clearCache(); Graph.session.markRefreshed(); Refresh.tick++
        Toast.makeText(context, tr("جاري التحديث..."), Toast.LENGTH_SHORT).show()
        scope.launch {
            val repo = Graph.repo
            runCatching {
                repo.liveCategories(); Refresh.step(15)
                repo.liveChannels(null); Refresh.step(30)
                repo.vodCategories(); Refresh.step(45)
                repo.vod(null); Refresh.step(60)
                repo.seriesCategories(); Refresh.step(75)
                repo.seriesList(null); Refresh.step(90)
            }
            Graph.session.markSection("live"); Graph.session.markSection("vod"); Graph.session.markSection("series")
            Refresh.tick++
            Refresh.finish()
            refreshing = false
            Toast.makeText(context, tr("تم التحديث"), Toast.LENGTH_SHORT).show()
        }
    }

    fun refreshSection(section: String) {
        if (refreshing) return
        refreshing = true
        Refresh.begin()
        Graph.repo.clearCache(); Refresh.tick++
        Toast.makeText(context, tr("جاري التحديث..."), Toast.LENGTH_SHORT).show()
        scope.launch {
            val repo = Graph.repo
            runCatching {
                when (section) {
                    "live" -> { repo.liveCategories(); Refresh.step(50); repo.liveChannels(null); Refresh.step(90) }
                    "vod" -> { repo.vodCategories(); Refresh.step(50); repo.vod(null); Refresh.step(90) }
                    "series" -> { repo.seriesCategories(); Refresh.step(50); repo.seriesList(null); Refresh.step(90) }
                }
            }
            Graph.session.markSection(section)
            Refresh.tick++
            Refresh.finish()
            refreshing = false
            Toast.makeText(context, tr("تم التحديث"), Toast.LENGTH_SHORT).show()
        }
    }

    Column(Modifier.fillMaxSize().background(Bg).padding(horizontal = 16.dp, vertical = 12.dp)) {

        // ===== TOP BAR (bigger) =====
        Row(Modifier.fillMaxWidth().weight(0.17f), verticalAlignment = Alignment.CenterVertically) {
            BrandLogo(46.dp)
            Spacer(Modifier.width(16.dp))
            Text(now, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.width(20.dp))
            Icon(Icons.Filled.Search, null, tint = Muted, modifier = Modifier.size(26.dp))
            Spacer(Modifier.width(8.dp))
            Text("Master Search", color = Muted, fontSize = 15.sp)
            Spacer(Modifier.weight(1f))
            Box(
                Modifier.size(48.dp).clip(RoundedCornerShape(10.dp)).background(Surface2)
                    .tvFocusBorder().clickable { refresh() },
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    if (refreshing) CircularProgressIndicator(color = Color.White, trackColor = Color.White.copy(alpha = 0.25f), strokeWidth = 3.dp, modifier = Modifier.size(26.dp))
                    else Icon(Icons.Filled.Refresh, "refresh", tint = BrandBright, modifier = Modifier.size(26.dp))
                    if (refreshing) Text("${Refresh.percent}%", color = Color.White, fontSize = 8.sp)
                }
            }
            Spacer(Modifier.width(12.dp))
            Box(
                Modifier.size(48.dp).clip(RoundedCornerShape(10.dp)).background(Surface2)
                    .tvFocusBorder().clickable { nav.navigate("settings") },
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Filled.Settings, "settings", tint = BrandBright, modifier = Modifier.size(26.dp)) }
            Spacer(Modifier.width(12.dp))
            Row(
                Modifier.clip(RoundedCornerShape(12.dp)).background(Surface2)
                    .tvFocusBorder().clickable { nav.navigate("profiles") }
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(profile, color = Color.White, fontSize = 15.sp)
                Spacer(Modifier.width(8.dp))
                Box(Modifier.size(36.dp).clip(RoundedCornerShape(9.dp)).background(BrandPrimary), contentAlignment = Alignment.Center) {
                    Icon(Icons.Filled.Person, null, tint = Color.White, modifier = Modifier.size(22.dp))
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        // ===== MAIN CARDS (smaller share) =====
        @Suppress("UNUSED_VARIABLE") val tick = Refresh.tick   // subscribe: recompose on refresh
        val liveT = fmtTime(Graph.session.sectionTime("live"))
        val vodT = fmtTime(Graph.session.sectionTime("vod"))
        val seriesT = fmtTime(Graph.session.sectionTime("series"))
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Row(Modifier.fillMaxWidth().weight(0.6f)) {
                BigCard("LIVE TV", LiveGradient, Icons.Filled.LiveTv, Modifier.weight(1f).focusRequester(firstFocus), liveT, refreshing, { refreshSection("live") }) { nav.navigate("live") }
                Spacer(Modifier.width(14.dp))
                BigCard("MOVIES", MoviesGradient, Icons.Filled.PlayArrow, Modifier.weight(1f), vodT, refreshing, { refreshSection("vod") }) { nav.navigate("movies") }
                Spacer(Modifier.width(14.dp))
                BigCard("SERIES", SeriesGradient, Icons.Filled.Theaters, Modifier.weight(1f), seriesT, refreshing, { refreshSection("series") }) { nav.navigate("series") }
            }
        }

        Spacer(Modifier.height(12.dp))

        // ===== BOTTOM CHIPS (bigger) =====
        Row(Modifier.fillMaxWidth().weight(0.23f)) {
            ChipButton(tr("مواعيد المباريات"), Icons.Filled.SportsSoccer, Modifier.weight(1f)) { nav.navigate("matches") }
            Spacer(Modifier.width(12.dp))
            ChipButton(tr("التحميلات"), Icons.Filled.Download, Modifier.weight(1f)) { nav.navigate("downloads") }
            Spacer(Modifier.width(12.dp))
            ChipButton(tr("تحديث"), Icons.Filled.Refresh, Modifier.weight(1f)) { refresh() }
        }
    }
}

@Composable
private fun BigCard(
    title: String, brush: Brush, icon: ImageVector, modifier: Modifier,
    lastUpdate: String, isRefreshing: Boolean, onRefresh: () -> Unit, onClick: () -> Unit
) {
    Box(modifier.fillMaxHeight().tvFocusBorder(RoundedCornerShape(18.dp)).clickable { onClick() }) {
        Box(Modifier.fillMaxSize().clip(RoundedCornerShape(18.dp)).background(brush)) {
            Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Icon(icon, null, tint = Color.White, modifier = Modifier.size(50.dp))
                Spacer(Modifier.height(10.dp))
                Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            }
            Row(
                Modifier.align(Alignment.BottomStart).fillMaxWidth().padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "${tr("آخر تحديث")}: $lastUpdate",
                    color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp,
                    maxLines = 1, modifier = Modifier.weight(1f)
                )
                Box(
                    Modifier.size(34.dp).clip(RoundedCornerShape(9.dp))
                        .background(Color.White.copy(alpha = 0.18f))
                        .tvFocusBorder(RoundedCornerShape(9.dp)).clickable { onRefresh() },
                    contentAlignment = Alignment.Center
                ) {
                    if (isRefreshing) CircularProgressIndicator(color = Color.White, trackColor = Color.White.copy(alpha = 0.25f), strokeWidth = 2.5.dp, modifier = Modifier.size(20.dp))
                    else Icon(Icons.Filled.Refresh, "refresh", tint = Color.White, modifier = Modifier.size(20.dp))
                }
            }
        }
    }
}

@Composable
private fun ChipButton(title: String, icon: ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Box(modifier.fillMaxHeight().tvFocusBorder(RoundedCornerShape(14.dp)).clickable { onClick() }) {
        Column(
            Modifier.fillMaxSize().clip(RoundedCornerShape(14.dp)).background(Surface2)
                .padding(vertical = 10.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(icon, null, tint = BrandBright, modifier = Modifier.size(30.dp))
            Spacer(Modifier.height(8.dp))
            Text(title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.Center, maxLines = 1)
        }
    }
}

private fun fmtTime(ts: Long): String =
    if (ts <= 0L) "—"
    else SimpleDateFormat(if (Graph.session.timeFormat == "24") "HH:mm" else "hh:mm a", Locale.ENGLISH).format(Date(ts))

private fun clock(fmt: String): String {
    val pattern = if (fmt == "24") "HH:mm   •   MMM dd" else "hh:mm a   •   MMM dd"
    return SimpleDateFormat(pattern, Locale.ENGLISH).format(Date())
}
