package com.iptv.player.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "favorites", primaryKeys = ["type", "itemId"])
data class FavoriteEntity(val type: String, val itemId: String, val name: String, val logo: String?)

@Entity(tableName = "resume", primaryKeys = ["type", "itemId"])
data class ResumeEntity(
    val type: String, val itemId: String, val name: String, val logo: String?,
    val url: String, val position: Long, val duration: Long, val updatedAt: Long
)

@Entity(tableName = "downloads")
data class DownloadEntity(
    @PrimaryKey val dmId: Long, val name: String, val type: String,
    val url: String, val localPath: String, val poster: String?, val createdAt: Long
)

@Dao
interface AppDao {
    @Query("SELECT * FROM favorites WHERE type = :type ORDER BY name")
    fun favorites(type: String): Flow<List<FavoriteEntity>>
    @Query("SELECT EXISTS(SELECT 1 FROM favorites WHERE type = :type AND itemId = :id)")
    suspend fun isFav(type: String, id: String): Boolean
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun addFav(f: FavoriteEntity)
    @Query("DELETE FROM favorites WHERE type = :type AND itemId = :id") suspend fun removeFav(type: String, id: String)

    @Query("SELECT position FROM resume WHERE type = :type AND itemId = :id")
    suspend fun resumePos(type: String, id: String): Long?
    @Query("SELECT * FROM resume WHERE type = :type ORDER BY updatedAt DESC")
    suspend fun resumeList(type: String): List<ResumeEntity>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun saveResume(r: ResumeEntity)

    @Query("SELECT * FROM downloads ORDER BY createdAt DESC") fun downloads(): Flow<List<DownloadEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun addDownload(d: DownloadEntity)
    @Query("DELETE FROM downloads WHERE dmId = :id") suspend fun removeDownload(id: Long)
}

@Database(entities = [FavoriteEntity::class, ResumeEntity::class, DownloadEntity::class], version = 3, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): AppDao
}
