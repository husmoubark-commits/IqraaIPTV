package com.iptv.player.data

import androidx.room.*
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.flow.Flow
import java.io.File
import java.lang.reflect.Type
import java.security.MessageDigest

@Entity(tableName = "favorites", primaryKeys = ["type", "itemId"])
data class FavoriteEntity(val type: String, val itemId: String, val name: String, val logo: String?)

@Entity(tableName = "resume", primaryKeys = ["type", "itemId"])
data class ResumeEntity(
    val type: String, val itemId: String, val name: String, val logo: String?,
    val url: String, val position: Long, val duration: Long, val updatedAt: Long,
    val seriesId: String? = null
)

@Entity(tableName = "downloads")
data class DownloadEntity(
    @PrimaryKey val dmId: Long, val name: String, val type: String,
    val url: String, val localPath: String, val poster: String?, val createdAt: Long
)

@Entity(tableName = "catalog_cache", primaryKeys = ["accountKey", "cacheKey"])
data class CatalogCacheEntity(
    val accountKey: String,
    val cacheKey: String,
    val json: String,
    val updatedAt: Long
)

@Dao
interface AppDao {
    @Query("SELECT * FROM favorites WHERE type = :type ORDER BY name")
    fun favorites(type: String): Flow<List<FavoriteEntity>>
    @Query("SELECT EXISTS(SELECT 1 FROM favorites WHERE type = :type AND itemId = :id)")
    suspend fun isFav(type: String, id: String): Boolean
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun addFav(f: FavoriteEntity)
    @Query("DELETE FROM favorites WHERE type = :type AND itemId = :id") suspend fun removeFav(type: String, id: String)

    @Query("SELECT position FROM resume WHERE type = :type AND itemId = :id")
    suspend fun resumePos(type: String, id: String): Long?
    @Query("SELECT * FROM resume WHERE type = :type ORDER BY updatedAt DESC")
    suspend fun resumeList(type: String): List<ResumeEntity>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun saveResume(r: ResumeEntity)

    @Query("SELECT * FROM downloads ORDER BY createdAt DESC") fun downloads(): Flow<List<DownloadEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun addDownload(d: DownloadEntity)
    @Query("DELETE FROM downloads WHERE dmId = :id") suspend fun removeDownload(id: Long)

    @Query("SELECT * FROM catalog_cache WHERE accountKey = :account AND cacheKey = :key LIMIT 1")
    suspend fun catalogCache(account: String, key: String): CatalogCacheEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun saveCatalogCache(value: CatalogCacheEntity)
}

@Database(entities = [FavoriteEntity::class, ResumeEntity::class, DownloadEntity::class, CatalogCacheEntity::class], version = 5, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): AppDao
}

class RoomContentCache(private val session: Session, private val dao: AppDao) {
    private val gson = Gson()

    private fun accountKey(): String {
        val a = session.account ?: return "default"
        return "${a.type}|${a.server.trimEnd('/')}|${a.username}|${a.m3uUrl}"
    }

    suspend fun read(kind: String, id: String, type: Type): Any? = runCatching {
        dao.catalogCache(accountKey(), "$kind|$id")?.let { gson.fromJson(it.json, type) }
    }.getOrNull()

    suspend fun write(kind: String, id: String, value: Any) {
        runCatching {
            dao.saveCatalogCache(CatalogCacheEntity(accountKey(), "$kind|$id", gson.toJson(value), System.currentTimeMillis()))
        }
    }
}

/** Persistent catalog cache used when the IPTV server is temporarily offline. */
class ContentCache(private val session: Session) {
    private val gson = Gson()
    private val root = session.contentCacheDir.apply { mkdirs() }

    private fun accountNamespace(): String {
        val a = session.account ?: return "default"
        val raw = "${a.type}|${a.server.trimEnd('/')}|${a.username}|${a.m3uUrl}"
        return digest(raw)
    }

    private fun digest(value: String): String = MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray())
        .joinToString("") { "%02x".format(it) }

    private fun file(kind: String, id: String = "all"): File =
        File(root, "${accountNamespace()}_${digest("$kind|$id")}.json")

    private fun readFile(kind: String, id: String, type: Type): Any? = runCatching {
        val f = file(kind, id)
        if (!f.exists()) null else gson.fromJson(f.readText(), type)
    }.getOrNull()

    private fun writeFile(kind: String, id: String, value: Any) {
        runCatching {
            val target = file(kind, id)
            val temp = File(target.parentFile, "${target.name}.tmp")
            temp.writeText(gson.toJson(value))
            if (!temp.renameTo(target)) {
                target.writeText(temp.readText())
                temp.delete()
            }
        }
    }

    @Suppress("UNCHECKED_CAST")
    fun readM3u(): M3uData? = readFile("m3u", "all", object : TypeToken<M3uData>() {}.type) as? M3uData
    fun writeM3u(value: M3uData) = writeFile("m3u", "all", value)

    @Suppress("UNCHECKED_CAST")
    fun readCategories(kind: String): List<Category>? =
        readFile("categories", kind, object : TypeToken<List<Category>>() {}.type) as? List<Category>
    fun writeCategories(kind: String, value: List<Category>) = writeFile("categories", kind, value)

    @Suppress("UNCHECKED_CAST")
    fun readLiveChannels(category: String): List<LiveChannel>? =
        readFile("live_channels", category, object : TypeToken<List<LiveChannel>>() {}.type) as? List<LiveChannel>
    fun writeLiveChannels(category: String, value: List<LiveChannel>) = writeFile("live_channels", category, value)

    @Suppress("UNCHECKED_CAST")
    fun readVodItems(category: String): List<VodItem>? =
        readFile("vod_items", category, object : TypeToken<List<VodItem>>() {}.type) as? List<VodItem>
    fun writeVodItems(category: String, value: List<VodItem>) = writeFile("vod_items", category, value)

    @Suppress("UNCHECKED_CAST")
    fun readSeriesItems(category: String): List<SeriesItem>? =
        readFile("series_items", category, object : TypeToken<List<SeriesItem>>() {}.type) as? List<SeriesItem>
    fun writeSeriesItems(category: String, value: List<SeriesItem>) = writeFile("series_items", category, value)

    @Suppress("UNCHECKED_CAST")
    fun readSeasons(seriesId: String): List<Season>? =
        readFile("series_info", seriesId, object : TypeToken<List<Season>>() {}.type) as? List<Season>
    fun writeSeasons(seriesId: String, value: List<Season>) = writeFile("series_info", seriesId, value)

    fun readMovieInfo(movieId: String): MovieInfo? =
        readFile("movie_info", movieId, object : TypeToken<MovieInfo>() {}.type) as? MovieInfo
    fun writeMovieInfo(movieId: String, value: MovieInfo) = writeFile("movie_info", movieId, value)
}
