package com.iptv.player.ui.screens

import android.app.DownloadManager
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import coil.compose.AsyncImage
import com.iptv.player.data.DownloadEntity
import com.iptv.player.data.Graph
import com.iptv.player.ui.PlayInfo
import com.iptv.player.ui.Selection
import com.iptv.player.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File

@Composable
fun DownloadsScreen(nav: NavHostController) {
    val dao = Graph.db.dao()
    val scope = rememberCoroutineScope()
    val downloads by dao.downloads().collectAsState(initial = emptyList())
    var progress by remember { mutableStateOf<Map<Long, Pair<Int, Int>>>(emptyMap()) }

    LaunchedEffect(downloads) {
        while (true) {
            progress = downloads.associate { it.dmId to Graph.downloader.query(it.dmId) }
            delay(2000)
        }
    }

    Column(Modifier.fillMaxSize().background(Bg)) {
        TopBar(nav, tr("التحميلات"))
        if (downloads.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(tr("لا يوجد تحميلات بعد"), color = Muted)
            }
            return@Column
        }
        LazyColumn(Modifier.fillMaxSize().padding(8.dp)) {
            items(downloads) { d ->
                val st = progress[d.dmId] ?: (DownloadManager.STATUS_PENDING to 0)
                DownloadRow(d, st.first, st.second,
                    onPlay = {
                        if (st.first == DownloadManager.STATUS_SUCCESSFUL && File(d.localPath).exists()) {
                            val uri = Uri.fromFile(File(d.localPath)).toString()
                            Selection.playlist = listOf(PlayInfo(uri, d.name, d.type, d.dmId.toString(), d.poster))
                            Selection.index = 0
                            Selection.play = Selection.playlist[0]
                            nav.navigate("player")
                        }
                    },
                    onDelete = {
                        Graph.downloader.remove(d.dmId)
                        scope.launch { runCatching { dao.removeDownload(d.dmId) } }
                    }
                )
            }
        }
    }
}

@Composable
private fun DownloadRow(d: DownloadEntity, status: Int, pct: Int, onPlay: () -> Unit, onDelete: () -> Unit) {
    val done = status == DownloadManager.STATUS_SUCCESSFUL
    val failed = status == DownloadManager.STATUS_FAILED
    val label = when {
        done -> tr("جاهز")
        failed -> tr("فشل")
        status == DownloadManager.STATUS_PAUSED -> tr("متوقف")
        else -> "${tr("جارٍ التحميل")} %$pct"
    }
    Row(
        Modifier.fillMaxWidth().padding(vertical = 5.dp)
            .clip(RoundedCornerShape(12.dp)).background(Surface1)
            .tvFocusBorder(RoundedCornerShape(12.dp)).clickable(enabled = done) { onPlay() }
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(54.dp).clip(RoundedCornerShape(8.dp)).background(Surface2)) {
            AsyncImage(d.poster, d.name, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(d.name, color = Color.White, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(4.dp))
            Text(label, color = if (done) BrandBright else Muted, fontSize = 12.sp)
            if (!done && !failed) {
                Spacer(Modifier.height(6.dp))
                LinearProgressIndicator(
                    progress = { (pct.coerceIn(0, 100)) / 100f },
                    modifier = Modifier.fillMaxWidth().height(4.dp),
                    color = BrandPrimary, trackColor = Surface2
                )
            }
        }
        if (done) {
            Box(Modifier.size(40.dp).clip(RoundedCornerShape(10.dp)).background(BrandPrimary).clickable { onPlay() }, contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.PlayArrow, "play", tint = Color.White)
            }
            Spacer(Modifier.width(8.dp))
        }
        IconButton(onClick = onDelete) { Icon(Icons.Filled.Delete, "delete", tint = Muted) }
    }
}
