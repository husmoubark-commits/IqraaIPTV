package com.iptv.player.data

import android.content.Context
import androidx.room.Room

object Graph {
    lateinit var session: Session; private set
    lateinit var repo: IptvRepository; private set
    lateinit var db: AppDb; private set
    lateinit var downloader: Downloader; private set

    fun init(context: Context) {
        val app = context.applicationContext
        session = Session(app)
        db = Room.databaseBuilder(app, AppDb::class.java, "iqraa_iptv.db")
            .fallbackToDestructiveMigration()
            .build()
        repo = IptvRepository(session)
        downloader = Downloader(app)
    }
}
