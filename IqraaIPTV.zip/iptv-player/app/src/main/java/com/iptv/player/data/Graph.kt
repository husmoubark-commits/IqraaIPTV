package com.iptv.player.data

import android.content.Context
import androidx.room.Room
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

object Graph {
    lateinit var session: Session; private set
    lateinit var repo: IptvRepository; private set
    lateinit var db: AppDb; private set
    lateinit var downloader: Downloader; private set

    fun init(context: Context) {
        val app = context.applicationContext
        session = Session(app)
        db = Room.databaseBuilder(app, AppDb::class.java, "iqraa_iptv.db")
            .addMigrations(object : Migration(4, 5) {
                override fun migrate(database: SupportSQLiteDatabase) {
                    database.execSQL("CREATE TABLE IF NOT EXISTS catalog_cache (accountKey TEXT NOT NULL, cacheKey TEXT NOT NULL, json TEXT NOT NULL, updatedAt INTEGER NOT NULL, PRIMARY KEY(accountKey, cacheKey))")
                }
            })
            .fallbackToDestructiveMigration()
            .build()
        repo = IptvRepository(session, db.dao())
        downloader = Downloader(app)
    }
}
