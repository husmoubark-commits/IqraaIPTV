package com.iptv.player.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import coil.compose.AsyncImage
import com.iptv.player.data.Graph
import com.iptv.player.data.MovieInfo
import com.iptv.player.ui.PlayInfo
import com.iptv.player.ui.Selection
import com.iptv.player.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun MovieDetailScreen(nav: NavHostController) {
    val repo = Graph.repo
    val dao = Graph.db.dao()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val movie = Selection.movie

    if (movie == null) { nav.popBackStack(); return }

    var info by remember { mutableStateOf<MovieInfo?>(null) }
    var loadingInfo by remember { mutableStateOf(true) }
    val playFocus = remember { FocusRequester() }

    LaunchedEffect(movie.id) {
        loadingInfo = true
        info = runCatching { repo.vodInfo(movie.id) }.getOrNull()
        loadingInfo = false
    }
    LaunchedEffect(Unit) { runCatching { playFocus.requestFocus() } }

    val poster = info?.poster?.takeIf { it.isNotBlank() } ?: movie.poster

    Column(Modifier.fillMaxSize().background(Bg)) {
        TopBar(nav, movie.name)
        Row(Modifier.fillMaxSize().padding(20.dp)) {
            // ---- LEFT: poster + actions ----
            Column(Modifier.width(280.dp)) {
                Box(
                    Modifier.fillMaxWidth().height(340.dp)
                        .clip(RoundedCornerShape(16.dp)).background(Surface2),
                    contentAlignment = Alignment.Center
                ) {
                    if (!poster.isNullOrBlank())
                        AsyncImage(poster, movie.name, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    else
                        Icon(Icons.Filled.PlayArrow, null, tint = Muted, modifier = Modifier.size(56.dp))
                }
                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    ActionButton(Icons.Filled.PlayArrow, tr("تشغيل"), true, Modifier.weight(1f).focusRequester(playFocus)) {
                        val url = repo.vodUrl(movie.id, movie.extension)
                        Selection.playlist = listOf(PlayInfo(url, movie.name, "vod", movie.id, poster))
                        Selection.index = 0
                        Selection.play = Selection.playlist[0]
                        nav.navigate("player")
                    }
                    ActionButton(Icons.Filled.Download, tr("تحميل"), false, Modifier.weight(1f)) {
                        val d = Graph.downloader.enqueue(repo.vodUrl(movie.id, movie.extension), movie.name, "vod", poster)
                        scope.launch { dao.addDownload(d) }
                        Toast.makeText(context, "${tr("بدأ تحميل")}: ${movie.name}", Toast.LENGTH_SHORT).show()
                    }
                }
            }

            Spacer(Modifier.width(24.dp))

            // ---- RIGHT: info ----
            Column(Modifier.weight(1f).fillMaxHeight().verticalScroll(rememberScrollState())) {
                Text(movie.name, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(10.dp))

                val meta = listOfNotNull(
                    info?.releaseDate?.takeIf { it.isNotBlank() }?.take(10),
                    info?.duration?.takeIf { it.isNotBlank() },
                    (info?.rating ?: movie.rating)?.takeIf { it.isNotBlank() }?.let { "★ $it" },
                    info?.genre?.takeIf { it.isNotBlank() }
                )
                if (meta.isNotEmpty()) {
                    Text(meta.joinToString("  •  "), color = BrandBright, fontSize = 13.sp)
                    Spacer(Modifier.height(14.dp))
                }

                when {
                    loadingInfo -> Text(tr("جارٍ التحميل..."), color = Muted, fontSize = 13.sp)
                    else -> {
                        if (!info?.plot.isNullOrBlank()) {
                            Text(info!!.plot!!, color = Color(0xFFD8CFE6), fontSize = 14.sp, lineHeight = 21.sp)
                            Spacer(Modifier.height(14.dp))
                        }
                        if (!info?.cast.isNullOrBlank()) InfoLine(tr("البطولة"), info!!.cast!!)
                        if (!info?.director.isNullOrBlank()) InfoLine(tr("المخرج"), info!!.director!!)
                        if (info?.plot.isNullOrBlank() && info?.cast.isNullOrBlank() && info?.director.isNullOrBlank())
                            Text(tr("لا توجد معلومات إضافية"), color = Muted, fontSize = 13.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun ActionButton(icon: ImageVector, label: String, primary: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Box(modifier.height(50.dp).tvFocusBorder(RoundedCornerShape(12.dp)).clickable { onClick() }) {
        Row(
            Modifier.fillMaxSize().clip(RoundedCornerShape(12.dp))
                .background(if (primary) BrandPrimary else Surface2),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(icon, null, tint = Color.White, modifier = Modifier.size(22.dp))
            Spacer(Modifier.width(8.dp))
            Text(label, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun InfoLine(label: String, value: String) {
    Row(Modifier.padding(vertical = 3.dp)) {
        Text("$label: ", color = Muted, fontSize = 13.sp, fontWeight = FontWeight.Medium)
        Text(value, color = Color.White, fontSize = 13.sp)
    }
}
