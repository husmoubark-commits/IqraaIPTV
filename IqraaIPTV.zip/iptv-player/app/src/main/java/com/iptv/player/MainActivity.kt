package com.iptv.player

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.compose.rememberNavController
import com.iptv.player.data.Graph
import com.iptv.player.ui.AppNav
import com.iptv.player.ui.theme.Bg
import com.iptv.player.ui.theme.IqraaTheme
import androidx.compose.foundation.layout.Box

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            IqraaTheme {
                Box(Modifier.fillMaxSize().background(Bg)) {
                    val nav = rememberNavController()
                    val start = if (Graph.session.account == null) "login" else "home"
                    AppNav(nav, start)
                }
            }
        }
    }
}
