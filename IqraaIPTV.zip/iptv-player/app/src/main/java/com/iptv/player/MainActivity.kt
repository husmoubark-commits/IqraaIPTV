package com.iptv.player

import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Modifier
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.navigation.compose.rememberNavController
import com.iptv.player.data.Graph
import com.iptv.player.ui.AppMode
import com.iptv.player.ui.AppNav
import com.iptv.player.ui.theme.Bg
import com.iptv.player.ui.theme.IqraaTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        hideSystemBars()

        val s = Graph.session
        val leanback = packageManager.hasSystemFeature(PackageManager.FEATURE_LEANBACK) ||
            (resources.configuration.uiMode and Configuration.UI_MODE_TYPE_MASK) == Configuration.UI_MODE_TYPE_TELEVISION
        AppMode.isTv = when (s.displayMode) { "tv" -> true; "phone" -> false; else -> leanback }

        if (s.autoClearCache) Graph.repo.clearCache()

        val interval = s.refreshInterval
        if (interval > 0 && System.currentTimeMillis() - s.lastRefresh > interval * 60_000L) {
            Graph.repo.clearCache(); s.markRefreshed()
        }

        setContent {
            IqraaTheme {
                val dir = if (Graph.session.language == "en") LayoutDirection.Ltr else LayoutDirection.Rtl
                CompositionLocalProvider(LocalLayoutDirection provides dir) {
                    Box(Modifier.fillMaxSize().background(Bg)) {
                        val nav = rememberNavController()
                        val start = if (Graph.session.account == null) "login" else "home"
                        AppNav(nav, start)
                    }
                }
            }
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    private fun hideSystemBars() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.hide(WindowInsetsCompat.Type.systemBars())
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    }
}
