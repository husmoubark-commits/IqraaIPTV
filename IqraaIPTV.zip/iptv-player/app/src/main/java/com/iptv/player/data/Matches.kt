package com.iptv.player.data

import com.google.gson.Gson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

data class MatchItem(
    val id: String = "",
    val date: String = "",
    val time: String = "",
    val status: String = "",
    val statusEn: String = "",
    val competition: String = "",
    val competitionEn: String = "",
    val compLogo: String = "",
    val teamA: String = "",
    val teamB: String = "",
    val teamAEn: String = "",
    val teamBEn: String = "",
    val logoA: String = "",
    val logoB: String = "",
    val scoreA: String = "",
    val scoreB: String = "",
    val channel: String = ""
)

data class MatchesResponse(
    val ok: Boolean = false,
    val count: Int = 0,
    val matches: List<MatchItem> = emptyList(),
    val error: String? = null
)

object MatchesApi {
    // endpoint البلَجن على سيرفرك
    const val URL = "https://iqraagift.shop/wp-json/voltix/v1/matches"

    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()
    private val gson = Gson()

    suspend fun fetch(): MatchesResponse = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder().url(URL).header("User-Agent", "Voltix/1.0").build()
            http.newCall(req).execute().use { resp ->
                val body = resp.body?.string().orEmpty()
                gson.fromJson(body, MatchesResponse::class.java) ?: MatchesResponse(error = "empty")
            }
        } catch (e: Throwable) {
            MatchesResponse(ok = false, error = e.message ?: "error")
        }
    }
}
