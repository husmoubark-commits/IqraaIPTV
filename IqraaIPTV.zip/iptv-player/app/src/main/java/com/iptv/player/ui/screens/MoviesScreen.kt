package com.iptv.player.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.iptv.player.data.Category
import com.iptv.player.data.Graph
import com.iptv.player.data.VodItem
import com.iptv.player.ui.PlayInfo
import com.iptv.player.ui.Refresh
import com.iptv.player.ui.Selection
import com.iptv.player.ui.theme.Bg
import kotlinx.coroutines.launch

private const val ALL = "__all__"
private const val CONT = "__continue__"

private data class GridCard(val name: String, val poster: String?, val onPlay: () -> Unit, val onDownload: (() -> Unit)?)

@Composable
fun MoviesScreen(nav: NavHostController) {
    val repo = Graph.repo
    val dao = Graph.db.dao()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var categories by remember { mutableStateOf<List<Category>>(emptyList()) }
    var selectedCat by remember { mutableStateOf(ALL) }
    var cards by remember { mutableStateOf<List<GridCard>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var search by remember { mutableStateOf("") }

    LaunchedEffect(Refresh.tick) {
        categories = listOf(Category(ALL, "ALL"), Category(CONT, "استئناف المشاهدة")) +
            runCatching { repo.vodCategories() }.getOrDefault(emptyList())
    }
    LaunchedEffect(selectedCat, Refresh.tick) {
        loading = true; search = ""
        cards = if (selectedCat == CONT) {
            runCatching { dao.resumeList("vod") }.getOrDefault(emptyList()).map { r ->
                GridCard(r.name, r.logo, {
                    Selection.playlist = listOf(PlayInfo(r.url, r.name, "vod", r.itemId, r.logo))
                    Selection.index = 0; Selection.play = Selection.playlist[0]; nav.navigate("player")
                }, null)
            }
        } else {
            runCatching { repo.vod(if (selectedCat == ALL) null else selectedCat) }.getOrDefault(emptyList()).map { m: VodItem ->
                GridCard(m.name, m.poster, {
                    Selection.playlist = listOf(PlayInfo(repo.vodUrl(m.id, m.extension), m.name, "vod", m.id, m.poster))
                    Selection.index = 0; Selection.play = Selection.playlist[0]; nav.navigate("player")
                }, {
                    val d = Graph.downloader.enqueue(repo.vodUrl(m.id, m.extension), m.name, "vod", m.poster)
                    scope.launch { dao.addDownload(d) }
                    Toast.makeText(context, "بدأ تحميل: ${m.name}", Toast.LENGTH_SHORT).show()
                })
            }
        }
        loading = false
    }

    val shown = if (search.isBlank()) cards else cards.filter { it.name.contains(search, true) }

    Column(Modifier.fillMaxSize().background(Bg)) {
        TopBar(nav, "Movies")
        Row(Modifier.fillMaxSize()) {
            CategorySidebar(categories, selectedCat, { selectedCat = it.id }, Modifier.weight(0.28f).fillMaxHeight())
            Column(Modifier.weight(0.72f).fillMaxHeight().background(Color(0xFF0F0820))) {
                ItemSearchBar(search, { search = it }, "ابحث باسم الفيلم")
                if (loading) LoadingBox()
                else LazyVerticalGrid(columns = GridCells.Adaptive(132.dp), contentPadding = PaddingValues(8.dp), modifier = Modifier.fillMaxSize()) {
                    items(shown) { c -> PosterCard(c.name, c.poster, onDownload = c.onDownload) { c.onPlay() } }
                }
            }
        }
    }
}
