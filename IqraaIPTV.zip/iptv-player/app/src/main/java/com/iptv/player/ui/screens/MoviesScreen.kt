package com.iptv.player.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.iptv.player.data.Category
import com.iptv.player.data.Graph
import com.iptv.player.data.VodItem
import com.iptv.player.ui.PlayInfo
import com.iptv.player.ui.Selection
import com.iptv.player.ui.theme.Bg

private const val ALL = "__all__"

@Composable
fun MoviesScreen(nav: NavHostController) {
    val repo = Graph.repo
    var categories by remember { mutableStateOf<List<Category>>(emptyList()) }
    var selectedCat by remember { mutableStateOf(ALL) }
    var items by remember { mutableStateOf<List<VodItem>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        val cats = runCatching { repo.vodCategories() }.getOrDefault(emptyList())
        categories = listOf(Category(ALL, "ALL")) + cats
    }
    LaunchedEffect(selectedCat) {
        loading = true
        items = runCatching { repo.vod(if (selectedCat == ALL) null else selectedCat) }.getOrDefault(emptyList())
        loading = false
    }

    Column(Modifier.fillMaxSize().background(Bg)) {
        TopBar(nav, "Movies")
        Row(Modifier.fillMaxSize()) {
            CategorySidebar(categories, selectedCat, { selectedCat = it.id }, Modifier.weight(0.30f).fillMaxHeight())
            Box(Modifier.weight(0.70f).fillMaxHeight().background(Color(0xFF0F0820))) {
                if (loading) LoadingBox()
                else LazyVerticalGrid(
                    columns = GridCells.Adaptive(132.dp),
                    contentPadding = PaddingValues(8.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(items) { m ->
                        PosterCard(m.name, m.poster) {
                            Selection.play = PlayInfo(repo.vodUrl(m.id, m.extension), m.name, "vod", m.id, m.poster)
                            nav.navigate("player")
                        }
                    }
                }
            }
        }
    }
}
