package com.iptv.player.ui.screens

import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.launch
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.material3.Text
import com.iptv.player.ui.theme.Muted
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.iptv.player.data.Category
import com.iptv.player.data.Graph
import com.iptv.player.data.SeriesItem
import com.iptv.player.ui.PlayInfo
import com.iptv.player.ui.Refresh
import com.iptv.player.ui.Selection
import com.iptv.player.ui.theme.Bg

private const val ALL = "__all__"
private const val CONT = "__continue__"

private data class SCard(val id: String, val name: String, val poster: String?, val onClick: () -> Unit)

@Composable
fun SeriesScreen(nav: NavHostController) {
    val repo = Graph.repo
    val dao = Graph.db.dao()
    var categories by remember { mutableStateOf<List<Category>>(emptyList()) }
    var selectedCat by remember { mutableStateOf(ALL) }
    var cards by remember { mutableStateOf<List<SCard>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var search by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val gridState = androidx.compose.foundation.lazy.grid.rememberLazyGridState()
    val cardFocus = remember { androidx.compose.ui.focus.FocusRequester() }
    var openedId by remember { mutableStateOf<String?>(null) }
    var restoreFocus by remember { mutableStateOf(false) }
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME && openedId != null) restoreFocus = true
        }
        lifecycleOwner.lifecycle.addObserver(obs)
        onDispose { lifecycleOwner.lifecycle.removeObserver(obs) }
    }

    LaunchedEffect(Refresh.tick) {
        categories = listOf(Category(ALL, "ALL"), Category(CONT, "Continue Watching")) +
            runCatching { repo.seriesCategories() }.getOrDefault(emptyList())
    }
    LaunchedEffect(selectedCat, Refresh.tick) {
        loading = true; search = ""
        cards = if (selectedCat == CONT) {
            val raw = runCatching { dao.resumeList("series") }.getOrDefault(emptyList())
            raw.groupBy { it.name.replace(Regex("\\s+S\\d+E\\d+.*$"), "").trim() }
                .map { (_, list) -> list.maxByOrNull { it.updatedAt }!! }
                .sortedByDescending { it.updatedAt }
                .map { r ->
                    val clean = r.name.replace(Regex("\\s+S\\d+E\\d+.*$"), "").trim()
                    SCard(r.seriesId ?: r.itemId, r.name, r.logo, {
                        openedId = r.seriesId ?: r.itemId
                        val sid = r.seriesId
                        if (sid.isNullOrBlank()) {
                            Selection.playlist = listOf(PlayInfo(r.url, r.name, "series", r.itemId, r.logo))
                            Selection.index = 0; Selection.play = Selection.playlist[0]; nav.navigate("player")
                        } else {
                            scope.launch {
                                val eps = runCatching { repo.seriesInfo(sid) }.getOrDefault(emptyList())
                                    .flatMap { it.episodes }
                                if (eps.isEmpty()) {
                                    Selection.playlist = listOf(PlayInfo(r.url, r.name, "series", r.itemId, r.logo))
                                    Selection.index = 0
                                } else {
                                    Selection.playlist = eps.map {
                                        PlayInfo(repo.seriesUrl(it.id, it.extension),
                                            "$clean S%02dE%02d".format(it.season, it.episodeNum),
                                            "series", it.id, it.cover ?: r.logo, sid)
                                    }
                                    Selection.index = eps.indexOfFirst { it.id == r.itemId }.coerceAtLeast(0)
                                }
                                Selection.series = SeriesItem(sid, clean, r.logo, null, null, null)
                                Selection.play = Selection.playlist[Selection.index]
                                nav.navigate("player")
                            }
                        }
                    })
                }
        } else {
            runCatching { repo.seriesList(if (selectedCat == ALL) null else selectedCat) }.getOrDefault(emptyList()).map { s: SeriesItem ->
                SCard(s.id, s.name, s.cover, { openedId = s.id; Selection.series = s; nav.navigate("seriesDetail") })
            }
        }
        loading = false
    }

    val shown = if (search.isBlank()) cards else cards.filter { it.name.contains(search, true) }

    LaunchedEffect(restoreFocus, shown.size) {
        if (restoreFocus && openedId != null) {
            val idx = shown.indexOfFirst { it.id == openedId }
            if (idx >= 0) {
                runCatching { gridState.scrollToItem(idx) }
                kotlinx.coroutines.delay(120)
                runCatching { cardFocus.requestFocus() }
            }
            restoreFocus = false
        }
    }

    Column(Modifier.fillMaxSize().background(Bg)) {
        TopBar(nav, "Series")
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Row(Modifier.fillMaxSize()) {
                CategorySidebar(categories, selectedCat, { selectedCat = it.id }, Modifier.weight(0.28f).fillMaxHeight())
                CompositionLocalProvider(LocalLayoutDirection provides (if (Graph.session.language == "en") LayoutDirection.Ltr else LayoutDirection.Rtl)) {
                    Column(Modifier.weight(0.72f).fillMaxHeight().background(Color(0xFF0F0820))) {
                        ItemSearchBar(search, { search = it }, tr("ابحث باسم المسلسل"))
                        if (loading) LoadingBox()
                        else if (shown.isEmpty()) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text(tr("لا يوجد محتوى"), color = Muted, fontSize = 14.sp) }
                        else LazyVerticalGrid(state = gridState, columns = GridCells.Adaptive(132.dp), contentPadding = PaddingValues(8.dp), modifier = Modifier.fillMaxSize()) {
                            items(shown) { c -> PosterCard(c.name, c.poster, modifier = if (c.id == openedId) Modifier.focusRequester(cardFocus) else Modifier) { c.onClick() } }
                        }
                    }
                }
            }
        }
    }
}
