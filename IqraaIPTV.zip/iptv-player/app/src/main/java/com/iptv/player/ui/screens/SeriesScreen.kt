package com.iptv.player.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.iptv.player.data.Category
import com.iptv.player.data.Graph
import com.iptv.player.data.SeriesItem
import com.iptv.player.ui.PlayInfo
import com.iptv.player.ui.Refresh
import com.iptv.player.ui.Selection
import com.iptv.player.ui.theme.Bg

private const val ALL = "__all__"
private const val CONT = "__continue__"

private data class SCard(val name: String, val poster: String?, val onClick: () -> Unit)

@Composable
fun SeriesScreen(nav: NavHostController) {
    val repo = Graph.repo
    val dao = Graph.db.dao()
    var categories by remember { mutableStateOf<List<Category>>(emptyList()) }
    var selectedCat by remember { mutableStateOf(ALL) }
    var cards by remember { mutableStateOf<List<SCard>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var search by remember { mutableStateOf("") }

    LaunchedEffect(Refresh.tick) {
        categories = listOf(Category(ALL, "ALL"), Category(CONT, "Continue Watching")) +
            runCatching { repo.seriesCategories() }.getOrDefault(emptyList())
    }
    LaunchedEffect(selectedCat, Refresh.tick) {
        loading = true; search = ""
        cards = if (selectedCat == CONT) {
            val raw = runCatching { dao.resumeList("series") }.getOrDefault(emptyList())
            raw.groupBy { it.name.replace(Regex("\\s+S\\d+E\\d+.*$"), "").trim() }
                .map { (_, list) -> list.maxByOrNull { it.updatedAt }!! }
                .sortedByDescending { it.updatedAt }
                .map { r ->
                    SCard(r.name, r.logo, {
                        Selection.playlist = listOf(PlayInfo(r.url, r.name, "series", r.itemId, r.logo))
                        Selection.index = 0; Selection.play = Selection.playlist[0]; nav.navigate("player")
                    })
                }
        } else {
            runCatching { repo.seriesList(if (selectedCat == ALL) null else selectedCat) }.getOrDefault(emptyList()).map { s: SeriesItem ->
                SCard(s.name, s.cover, { Selection.series = s; nav.navigate("seriesDetail") })
            }
        }
        loading = false
    }

    val shown = if (search.isBlank()) cards else cards.filter { it.name.contains(search, true) }

    Column(Modifier.fillMaxSize().background(Bg)) {
        TopBar(nav, "Series")
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Row(Modifier.fillMaxSize()) {
                CategorySidebar(categories, selectedCat, { selectedCat = it.id }, Modifier.weight(0.28f).fillMaxHeight())
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Column(Modifier.weight(0.72f).fillMaxHeight().background(Color(0xFF0F0820))) {
                        ItemSearchBar(search, { search = it }, "ابحث باسم المسلسل")
                        if (loading) LoadingBox()
                        else LazyVerticalGrid(columns = GridCells.Adaptive(132.dp), contentPadding = PaddingValues(8.dp), modifier = Modifier.fillMaxSize()) {
                            items(shown) { c -> PosterCard(c.name, c.poster) { c.onClick() } }
                        }
                    }
                }
            }
        }
    }
}
