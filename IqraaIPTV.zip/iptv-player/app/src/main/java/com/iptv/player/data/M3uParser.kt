package com.iptv.player.data

data class M3uData(val categories: List<Category>, val channels: List<LiveChannel>)

object M3uParser {
    private val attr = Regex("([a-zA-Z0-9-]+)=\"([^\"]*)\"")

    fun parse(text: String): M3uData {
        val channels = ArrayList<LiveChannel>()
        val cats = LinkedHashMap<String, Int>()
        val lines = text.lines()
        var i = 0
        while (i < lines.size) {
            val line = lines[i].trim()
            if (line.startsWith("#EXTINF", ignoreCase = true)) {
                val attrs = attr.findAll(line).associate { it.groupValues[1] to it.groupValues[2] }
                val name = line.substringAfterLast(',').trim()
                val group = (attrs["group-title"]?.takeIf { it.isNotBlank() }) ?: "Other"
                val logo = attrs["tvg-logo"]
                val epg = attrs["tvg-id"]
                var j = i + 1
                while (j < lines.size && (lines[j].isBlank() || lines[j].trimStart().startsWith("#"))) j++
                val url = if (j < lines.size) lines[j].trim() else ""
                if (url.isNotEmpty()) {
                    channels.add(LiveChannel(url, name.ifBlank { "—" }, logo, epg, group))
                    cats[group] = (cats[group] ?: 0) + 1
                }
                i = j + 1
            } else i++
        }
        val categories = cats.entries.map { Category(it.key, it.key, it.value) }
        return M3uData(categories, channels)
    }
}
