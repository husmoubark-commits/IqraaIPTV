package com.iptv.player.ui

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.iptv.player.data.SeriesItem
import com.iptv.player.ui.screens.*

// Simple in-memory selection holder (avoids encoding long URLs in nav routes)
data class PlayInfo(
    val url: String = "",
    val title: String = "",
    val type: String = "live",   // live | vod | series
    val itemId: String = "",
    val logo: String? = null
)

object Selection {
    var play: PlayInfo = PlayInfo()
    var series: SeriesItem? = null
}

@Composable
fun AppNav(nav: NavHostController, start: String) {
    NavHost(navController = nav, startDestination = start) {
        composable("login") { LoginScreen(nav) }
        composable("home") { HomeScreen(nav) }
        composable("live") { LiveScreen(nav) }
        composable("movies") { MoviesScreen(nav) }
        composable("series") { SeriesScreen(nav) }
        composable("seriesDetail") { SeriesDetailScreen(nav) }
        composable("player") { PlayerScreen(nav) }
    }
}
