package com.iptv.player.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.iptv.player.data.Account
import com.iptv.player.data.SeriesItem
import com.iptv.player.data.VodItem
import com.iptv.player.ui.screens.*

data class PlayInfo(
    val url: String = "",
    val title: String = "",
    val type: String = "live",   // live | vod | series
    val itemId: String = "",
    val logo: String? = null,
    val seriesId: String? = null
)

object Selection {
    var play: PlayInfo = PlayInfo()
    var playlist: List<PlayInfo> = emptyList()
    var index: Int = 0
    var series: SeriesItem? = null
    var movie: VodItem? = null
    var editProfile: Account? = null
    var editIndex: Int? = null
}

object AppMode { var isTv: Boolean = false }

object Refresh { var tick by mutableStateOf(0) }

@Composable
fun AppNav(nav: NavHostController, start: String) {
    NavHost(navController = nav, startDestination = start) {
        composable("login") { LoginScreen(nav) }
        composable("home") { HomeScreen(nav) }
        composable("profiles") { ProfilesScreen(nav) }
        composable("settings") { SettingsScreen(nav) }
        composable("downloads") { DownloadsScreen(nav) }
        composable("live") { LiveScreen(nav) }
        composable("movies") { MoviesScreen(nav) }
        composable("series") { SeriesScreen(nav) }
        composable("seriesDetail") { SeriesDetailScreen(nav) }
        composable("movieDetail") { MovieDetailScreen(nav) }
        composable("player") { PlayerScreen(nav) }
    }
}
