package com.iptv.player.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.ui.focus.focusRequester
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.PlayerView
import androidx.navigation.NavHostController
import coil.compose.AsyncImage
import com.iptv.player.data.*
import com.iptv.player.ui.PlayInfo
import com.iptv.player.ui.NetDiag
import com.iptv.player.ui.Refresh
import com.iptv.player.ui.Selection
import com.iptv.player.ui.theme.*
import kotlinx.coroutines.launch

private const val ALL = "__all__"
private const val FAV = "__fav__"
private const val CONT = "__continue__"

@OptIn(UnstableApi::class)
@Composable
fun LiveScreen(nav: NavHostController) {
    val repo = Graph.repo
    val dao = Graph.db.dao()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var categories by remember { mutableStateOf<List<Category>>(emptyList()) }
    var selectedCat by remember { mutableStateOf(Graph.session.lastCat("live")) }
    var channels by remember { mutableStateOf<List<LiveChannel>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var selected by remember { mutableStateOf<LiveChannel?>(null) }
    var epg by remember { mutableStateOf<List<EpgEntry>>(emptyList()) }
    var search by remember { mutableStateOf("") }
    val favs by dao.favorites("live").collectAsState(initial = emptyList())
    val favIds = favs.map { it.itemId }.toSet()
    val listState = androidx.compose.foundation.lazy.rememberLazyListState()
    val chFocus = remember { androidx.compose.ui.focus.FocusRequester() }
    var restoreFocus by remember { mutableStateOf(false) }

    val miniPlayer = remember { PlayerFactory.build(context) }
    DisposableEffect(Unit) { onDispose { miniPlayer.release() } }
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_PAUSE || e == Lifecycle.Event.ON_STOP) miniPlayer.pause()
            if (e == Lifecycle.Event.ON_RESUME && selected != null) restoreFocus = true
        }
        lifecycleOwner.lifecycle.addObserver(obs)
        onDispose { lifecycleOwner.lifecycle.removeObserver(obs) }
    }

    LaunchedEffect(Refresh.tick) {
        Refresh.step(20)
        val cats = runCatching { repo.liveCategories() }.getOrDefault(emptyList())
        categories = listOf(Category(ALL, "ALL"), Category(FAV, "FAVOURITES"), Category(CONT, "Continue Watching")) + cats
        if (cats.isNotEmpty() && categories.none { it.id == selectedCat }) { selectedCat = ALL; Graph.session.setCat("live", ALL) }
    }
    LaunchedEffect(selectedCat, Refresh.tick) {
        Refresh.step(45)
        loading = true; search = ""
        NetDiag.lastError = null
        channels = when (selectedCat) {
            FAV -> favs.map { LiveChannel(it.itemId, it.name, it.logo, null, FAV) }
            CONT -> runCatching { dao.resumeList("live") }.getOrDefault(emptyList())
                .take(Graph.session.channelsHistoryLimit)
                .map { LiveChannel(it.itemId, it.name, it.logo, null, CONT) }
            ALL -> runCatching { repo.liveChannels(null) }.onFailure { NetDiag.lastError = friendlyNetworkError(it) }.getOrDefault(emptyList())
            else -> runCatching { repo.liveChannels(selectedCat) }.onFailure { NetDiag.lastError = friendlyNetworkError(it) }.getOrDefault(emptyList())
        }
        loading = false
        Refresh.finish()
        if (selectedCat != FAV && selectedCat != CONT && NetDiag.lastError == null) Graph.session.markSection("live")
    }

    val shown = if (search.isBlank()) channels else channels.filter { it.name.contains(search, true) }

    LaunchedEffect(restoreFocus, shown.size) {
        if (restoreFocus && selected != null) {
            val idx = shown.indexOfFirst { it.id == selected!!.id }
            if (idx >= 0) {
                runCatching { listState.scrollToItem(idx) }
                kotlinx.coroutines.delay(120)
                runCatching { chFocus.requestFocus() }
            }
            restoreFocus = false
        }
    }

    fun playMini(ch: LiveChannel) {
        selected = ch
        miniPlayer.setMediaItem(MediaItem.fromUri(repo.livePlayUrl(ch)))
        miniPlayer.prepare(); miniPlayer.playWhenReady = true
        if (Graph.session.showEpg) scope.launch { epg = runCatching { repo.nowNext(ch.id) }.getOrDefault(emptyList()) } else epg = emptyList()
    }

    fun expand(ch: LiveChannel) {
        val list = shown.map { PlayInfo(repo.livePlayUrl(it), it.name, "live", it.id, it.logo) }
        Selection.playlist = list
        Selection.index = shown.indexOfFirst { it.id == ch.id }.coerceAtLeast(0)
        Selection.play = list.getOrElse(Selection.index) { PlayInfo(repo.livePlayUrl(ch), ch.name, "live", ch.id, ch.logo) }
        miniPlayer.pause()
        nav.navigate("player")
    }

    Column(Modifier.fillMaxSize().background(Bg)) {
        TopBar(nav, "Live", onDownloads = { nav.navigate("downloads") }, onRefresh = { Refresh.tick++ }, isLoading = loading)
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Row(Modifier.fillMaxSize()) {
                CategorySidebar(categories, selectedCat, { selectedCat = it.id; Graph.session.setCat("live", it.id) }, Modifier.weight(0.30f).fillMaxHeight())
    
                CompositionLocalProvider(LocalLayoutDirection provides (if (Graph.session.language == "en") LayoutDirection.Ltr else LayoutDirection.Rtl)) {
                    Column(Modifier.weight(0.40f).fillMaxHeight().background(Color(0xFF0F0820))) {
                        ItemSearchBar(search, { search = it }, tr("ابحث عن قناة"))
                        if (loading) LoadingBox()
                        else if (shown.isEmpty()) Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) { Text(NetDiag.lastError ?: tr("لا يوجد محتوى"), color = Muted, fontSize = 13.sp) }
                        else LazyColumn(state = listState, modifier = Modifier.fillMaxSize()) {
                            items(shown) { ch ->
                                val isFav = favIds.contains(ch.id)
                                Row(
                                    Modifier.fillMaxWidth()
                                        .then(if (selected?.id == ch.id) Modifier.focusRequester(chFocus) else Modifier)
                                        .background(if (selected?.id == ch.id) Surface2 else Color.Transparent)
                                        .tvFocusBorder()
                                        .clickable { if (selected?.id == ch.id) expand(ch) else playMini(ch) }
                                        .padding(horizontal = 12.dp, vertical = 11.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(Modifier.size(44.dp).clip(RoundedCornerShape(8.dp)).background(Surface1), contentAlignment = Alignment.Center) {
                                        Icon(Icons.Filled.LiveTv, null, tint = Muted, modifier = Modifier.size(22.dp))
                                        if (!ch.logo.isNullOrBlank())
                                            AsyncImage(ch.logo, ch.name, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                                    }
                                    Spacer(Modifier.width(10.dp))
                                    Text(ch.name, color = Color.White, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                                    IconButton(onClick = {
                                        scope.launch {
                                            if (isFav) dao.removeFav("live", ch.id)
                                            else dao.addFav(FavoriteEntity("live", ch.id, ch.name, ch.logo))
                                        }
                                    }) { Icon(if (isFav) Icons.Filled.Star else Icons.Outlined.StarBorder, null, tint = if (isFav) BrandBright else Muted) }
                                }
                                HorizontalDivider(color = Color(0x14FFFFFF))
                            }
                        }
                    }
                }
    
                CompositionLocalProvider(LocalLayoutDirection provides (if (Graph.session.language == "en") LayoutDirection.Ltr else LayoutDirection.Rtl)) {
                    Column(
                        Modifier.weight(0.30f).fillMaxHeight().background(Color(0xFF160C28)).padding(12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        val ch = selected
                        Box(
                            Modifier.fillMaxWidth().aspectRatio(16f / 9f).clip(RoundedCornerShape(10.dp)).background(Color.Black)
                                .clickable(enabled = ch != null) { ch?.let { expand(it) } }
                        ) {
                            if (ch == null) {
                                Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                                    BrandLogo(40.dp)
                                    Spacer(Modifier.height(6.dp))
                                    Text(tr("اضغط على قناة لتشغيلها"), color = Muted, fontSize = 11.sp)
                                }
                            } else {
                                AndroidView(factory = { c -> PlayerView(c).apply { useController = false; setErrorMessageProvider { Pair(0, tr("التشغيل يحتاج اتصالًا بالإنترنت")) }; this.player = miniPlayer } }, modifier = Modifier.fillMaxSize())
                            }
                        }
                        if (ch != null) {
                            Spacer(Modifier.height(10.dp))
                            Text(ch.name, color = Color.White, fontSize = 14.sp, maxLines = 2)
                            Spacer(Modifier.height(8.dp))
                            if (Graph.session.showEpg) epg.take(2).forEachIndexed { i, e ->
                                Text(if (i == 0) "${tr("الآن")}: ${e.title}" else "${tr("التالي")}: ${e.title}", color = Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Spacer(Modifier.height(3.dp))
                            }
                            Text(tr("اضغط على الشاشة للتكبير"), color = Color(0x88FFFFFF), fontSize = 10.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TopBar(
    nav: NavHostController,
    label: String,
    onDownloads: (() -> Unit)? = null,
    onRefresh: (() -> Unit)? = null,
    isLoading: Boolean = false
) {
    val downloadsAction: () -> Unit = onDownloads ?: { nav.navigate("downloads") }
    val refreshAction: () -> Unit = onRefresh ?: { Refresh.tick++ }
    Row(
        Modifier.fillMaxWidth().background(Color(0xFF1A0F30)).padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color.White) }
        BrandLogo(28.dp)
        Spacer(Modifier.width(10.dp))
        Text(label, color = Color.White, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.weight(1f))
        IconButton(onClick = downloadsAction) {
            Icon(Icons.Filled.Download, tr("التحميلات"), tint = Color.White)
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            IconButton(onClick = { Refresh.begin(); refreshAction() }, enabled = !isLoading) {
                if (isLoading || Refresh.active) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(22.dp),
                        color = Color.White,
                        trackColor = Color.White.copy(alpha = 0.25f),
                        strokeWidth = 2.5.dp
                    )
                } else {
                    Icon(Icons.Filled.Refresh, tr("تحديث"), tint = Color.White)
                }
            }
            if (isLoading || Refresh.active) {
                Text("${Refresh.percent}%", color = Color.White, fontSize = 9.sp)
            }
        }
    }
}
