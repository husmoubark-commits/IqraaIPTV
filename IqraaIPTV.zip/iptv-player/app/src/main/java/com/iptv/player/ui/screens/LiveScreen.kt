package com.iptv.player.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import coil.compose.AsyncImage
import com.iptv.player.data.*
import com.iptv.player.ui.PlayInfo
import com.iptv.player.ui.Selection
import com.iptv.player.ui.theme.*
import kotlinx.coroutines.launch

private const val ALL = "__all__"
private const val FAV = "__fav__"

@Composable
fun LiveScreen(nav: NavHostController) {
    val repo = Graph.repo
    val dao = Graph.db.dao()
    val scope = rememberCoroutineScope()

    var categories by remember { mutableStateOf<List<Category>>(emptyList()) }
    var selectedCat by remember { mutableStateOf(ALL) }
    var channels by remember { mutableStateOf<List<LiveChannel>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var selected by remember { mutableStateOf<LiveChannel?>(null) }
    var epg by remember { mutableStateOf<List<EpgEntry>>(emptyList()) }
    val favs by dao.favorites("live").collectAsState(initial = emptyList())
    val favIds = favs.map { it.itemId }.toSet()

    LaunchedEffect(Unit) {
        val cats = runCatching { repo.liveCategories() }.getOrDefault(emptyList())
        categories = listOf(Category(ALL, "ALL"), Category(FAV, "FAVOURITES")) + cats
    }

    LaunchedEffect(selectedCat) {
        loading = true
        channels = when (selectedCat) {
            FAV -> favs.map { LiveChannel(it.itemId, it.name, it.logo, null, FAV) }
            ALL -> runCatching { repo.liveChannels(null) }.getOrDefault(emptyList())
            else -> runCatching { repo.liveChannels(selectedCat) }.getOrDefault(emptyList())
        }
        loading = false
    }

    Column(Modifier.fillMaxSize().background(Bg)) {
        TopBar(nav, "Live")
        Row(Modifier.fillMaxSize()) {
            CategorySidebar(categories, selectedCat, { selectedCat = it.id }, Modifier.weight(0.32f).fillMaxHeight())

            Box(Modifier.weight(0.42f).fillMaxHeight().background(Color(0xFF0F0820))) {
                if (loading) LoadingBox()
                else LazyColumn(Modifier.fillMaxSize()) {
                    items(channels) { ch ->
                        val isFav = favIds.contains(ch.id)
                        Row(
                            Modifier.fillMaxWidth()
                                .background(if (selected?.id == ch.id) Surface2 else Color.Transparent)
                                .clickable {
                                    selected = ch
                                    scope.launch { epg = runCatching { repo.nowNext(ch.id) }.getOrDefault(emptyList()) }
                                }
                                .padding(horizontal = 12.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(Modifier.size(40.dp).clip(RoundedCornerShape(6.dp)).background(Surface1)) {
                                AsyncImage(ch.logo, ch.name, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                            }
                            Spacer(Modifier.width(10.dp))
                            Text(ch.name, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                            IconButton(onClick = {
                                scope.launch {
                                    if (isFav) dao.removeFav("live", ch.id)
                                    else dao.addFav(FavoriteEntity("live", ch.id, ch.name, ch.logo))
                                }
                            }) {
                                Icon(
                                    if (isFav) Icons.Filled.Star else Icons.Outlined.StarBorder,
                                    null, tint = if (isFav) BrandBright else Muted
                                )
                            }
                        }
                        HorizontalDivider(color = Color(0x14FFFFFF))
                    }
                }
            }

            // preview pane
            Column(
                Modifier.weight(0.26f).fillMaxHeight().background(Color(0xFF160C28)).padding(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                val ch = selected
                if (ch == null) {
                    Spacer(Modifier.weight(1f))
                    BrandLogo(54.dp)
                    Spacer(Modifier.height(12.dp))
                    Text("اختر قناة لعرض التفاصيل", color = Muted, fontSize = 13.sp)
                    Spacer(Modifier.weight(1f))
                } else {
                    Spacer(Modifier.height(8.dp))
                    Box(Modifier.size(80.dp).clip(RoundedCornerShape(10.dp)).background(Surface1)) {
                        AsyncImage(ch.logo, ch.name, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                    }
                    Spacer(Modifier.height(10.dp))
                    Text(ch.name, color = Color.White, fontSize = 15.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(12.dp))
                    epg.take(2).forEachIndexed { i, e ->
                        Text(if (i == 0) "الآن: ${e.title}" else "التالي: ${e.title}", color = Muted, fontSize = 12.sp)
                        Spacer(Modifier.height(4.dp))
                    }
                    Spacer(Modifier.height(16.dp))
                    Button(
                        onClick = {
                            Selection.play = PlayInfo(repo.livePlayUrl(ch), ch.name, "live", ch.id, ch.logo)
                            nav.navigate("player")
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = BrandPrimary),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Filled.PlayArrow, null, tint = Color.White)
                        Spacer(Modifier.width(6.dp))
                        Text("تشغيل", color = Color.White)
                    }
                }
            }
        }
    }
}

@Composable
fun TopBar(nav: NavHostController, label: String) {
    Row(
        Modifier.fillMaxWidth().background(Color(0xFF1A0F30)).padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = { nav.popBackStack() }) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color.White)
        }
        BrandLogo(30.dp)
        Spacer(Modifier.width(10.dp))
        Text(label, color = Color.White, fontSize = 16.sp)
    }
}
